# `We the People` — where the five-week push fell short

The window closed on the release's fifth week and the single came back a long way behind
what the plan promised the artist. The register beside this note splits every channel's
shortfall into the three parts the attribution note fixes, in the order it fixes them:
the placements we did not deliver, the rate at which the reach we did deliver turned
into streams, and the reach left over once those two have been taken off.

Bookings are barely any of it. We ran close to the schedule everywhere and several
channels ran ahead of it or exactly to plan. Counted placements: 96. That is
every placement the note lets us count, each one counted in the week it actually went
out, and it is what the per-channel numbers should be read against.

The damage is conversion, and it is not close. Conversion effect: 127928.
Reach came in broadly where the plan expected it to; what did not arrive was the streams
per thousand of reach the plan assumed, which is a creative and call-to-action problem
rather than a booking one.

CH-41 is the channel to walk the artist through first because it is the clean case where every placement ran inside the window and its reach landed exactly where the plan put it, so the method leaves the whole of that channel's gap in the conversion part and nothing in the other two.

Anything we take back to the artist should be read off the register rather than off this
page, which is a summary of the split and nothing more.
