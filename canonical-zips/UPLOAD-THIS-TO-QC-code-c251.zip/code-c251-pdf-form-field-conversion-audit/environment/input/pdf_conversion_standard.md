# Fillable-PDF conversion standard (FORMS-OPS-5)

This decides which converted PDF form fields are ready to send out for digital signing.
Where a converted form disagrees with this standard, this standard decides.

## 0. Field hygiene

Trim leading and trailing ASCII whitespace on `field_id`, `field_name`, `field_type`,
`required_flag`, `tab_index`, and every source-inventory field before any lookup, match,
or comparison. A whitespace-only `field_name` is treated as blank (no accessible name).

If more than one row in the converted inventory shares the same `field_id`, the **last
row in the file wins** for every field; do not merge fields across duplicate rows.

A `required_flag` is treated as "flagged required" only when its trimmed value is exactly
`True`, `true`, or `TRUE`. Tokens such as `yes`, `1`, `Y`, or blank are **not** a required
flag.

## 1. Accessible field names

Every converted field must carry an accessible tab name a screen reader can announce. A
field whose trimmed `field_name` is blank or whitespace-only is `MISSING_ACCESSIBLE_NAME`.

## 2. Required flag must mirror the source form

If the source form inventory marks a field mandatory, the converted field must be flagged
required — **except** signature-type fields, which are exempt from this rule, because
e-signature capture enforces completion outside the form's own required-field validation.
A converted field that the source form marks mandatory, that is not itself a signature
field and whose `required_flag` is not exactly `True`/`true`/`TRUE`, is
`MISSING_REQUIRED_FLAG`.

Over-flagging a non-mandatory field (setting `required_flag` on a field the source form
does not mark mandatory) is not a violation; the finding is `none`.

## 3. No duplicate tab order

Two or more converted fields must never share the same `tab_index`. Every field that
shares its `tab_index` with at least one other field is `DUPLICATE_TAB_INDEX`.

## 4. Every source field must convert

Every field on the source form's field inventory must appear in the converted PDF. Match
source fields to converted fields by trimmed `field_name`. A source field whose trimmed
name does not appear among the converted field names is `MISSING_FIELD`.

## 5. Finding priority

When a single converted field trips more than one rule, exactly one finding is reported,
in this precedence order:

`MISSING_ACCESSIBLE_NAME` > `MISSING_REQUIRED_FLAG` > `DUPLICATE_TAB_INDEX` > `none`

`MISSING_FIELD` applies only to source fields that never made it into the conversion; it
is reported as a separate row in the audit, not as a finding on a converted field.

## Finding names

`MISSING_ACCESSIBLE_NAME`, `MISSING_REQUIRED_FLAG`, `DUPLICATE_TAB_INDEX`, `MISSING_FIELD`,
or `none` where the field is conversion-ready.
