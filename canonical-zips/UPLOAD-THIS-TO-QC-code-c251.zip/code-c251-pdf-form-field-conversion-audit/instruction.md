# Task

Audit this converted fillable PDF's form fields against our conversion standard. For every converted field, apply the accessible-name rule, the required-flag rule and the duplicate-tab-index rule, and separately confirm every field on the source form's inventory actually made it into the conversion — the required-flag rule works differently for signature fields, so check each field's own type rather than assuming every source-mandatory field needs the flag. Match converted fields to source fields by trimmed `field_name`. Save `pdf_form_audit.csv` with columns `field_id,field_name,field_type,required_flag,tab_index,finding` — one row per converted field starting with the converted field's `field_id` (e.g. FIELD-01) and ending with the `finding` column, plus one row per source field that is missing from the conversion (using `MISSING-<FIELD_NAME_UPPER_WITH_UNDERSCORES>` as the `field_id`, the source field's name in the `field_name` column, empty values for `field_type`, `required_flag`, and `tab_index`, and `MISSING_FIELD` in the `finding` column). The `required_flag` field accepts only the exact values `True`, `true`, or `TRUE` (case-sensitive) as a valid required flag; tokens such as `yes`, `1`, `Y`, or blank are not valid required flags.. Use the standard's finding names, `none` where conversion-ready. Then write `pdf_form_memo.md` explaining every finding and why the signature field's missing required flag is not a violation. Save `results.json` with keys `flagged_count` (number of rows whose finding is not `none`), `missing_accessible_name_count` (number of rows with `MISSING_ACCESSIBLE_NAME`), `missing_required_flag_count` (number of rows with `MISSING_REQUIRED_FLAG`), `duplicate_tab_index_count` (number of rows with `DUPLICATE_TAB_INDEX`), `missing_field_count` (number of rows with `MISSING_FIELD`).

---

## Working environment

- Your current working directory is `/app`, and it is writable.
- The read-only attachments referred to as `input/` are at `/app/input`.
- Write every deliverable into `/app`, at the exact filenames listed above.
