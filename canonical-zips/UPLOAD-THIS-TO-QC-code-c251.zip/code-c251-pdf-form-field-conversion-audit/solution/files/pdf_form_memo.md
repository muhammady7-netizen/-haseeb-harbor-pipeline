# Fillable-PDF conversion audit memo

Audited 33 converted fields against FORMS-OPS-5 and the source form inventory
(35 source fields). 17 findings across
3 missing accessible name,
3 missing required flag,
6 duplicate tab index, and
5 missing source field.

## Audit table

| Field ID | Name | Type | Required | Tab | Finding |
|---|---|---|---|---|---|
| FIELD-01 | applicant_name | text | True | 1 | none |
| FIELD-02 | date_of_birth | text | False | 2 | MISSING_REQUIRED_FLAG |
| FIELD-03 |  | text | True | 3 | MISSING_ACCESSIBLE_NAME |
| FIELD-04 | mailing_address | text | True | 2 | DUPLICATE_TAB_INDEX |
| FIELD-05 | signature | signature | False | 5 | none |
| FIELD-06 | phone_number | text | True | 6 | none |
| FIELD-07 | email_address | text | False | 7 | none |
| FIELD-08 | employment_start | date | True | 8 | none |
| FIELD-09 | annual_income | number | True | 9 | none |
| FIELD-10 | co_signer_name | text | True | 10 | none |
| FIELD-11 | co_signer_signature | signature | False | 11 | none |
| FIELD-12 | loan_amount | number | True | 12 | DUPLICATE_TAB_INDEX |
| FIELD-13 | loan_purpose | text | False | 13 | none |
| FIELD-14 |  collateral_desc | text | True | 12 | DUPLICATE_TAB_INDEX |
| FIELD-15 | branch_code | text | yes | 15 | none |
| FIELD-16 | account_number | text | True | 16 | none |
| FIELD-17 | interest_rate | number | False | 17 | none |
| FIELD-18 | term_months | number | 1 | 18 | MISSING_REQUIRED_FLAG |
| FIELD-19 | monthly_payment | number | False | 19 | none |
| FIELD-20 | next_of_kin | text | False | 20 | none |
| FIELD-21 | relationship | text | False | 12 | DUPLICATE_TAB_INDEX |
| FIELD-22 | consent_checkbox | checkbox | True | 22 | none |
| FIELD-23 | witness_signature | signature | False | 23 | none |
| FIELD-24 | date_signed | date | True | 24 | none |
| FIELD-25 |     | text | False | 25 | MISSING_ACCESSIBLE_NAME |
| FIELD-26 | emergency_contact | text | True | 26 | none |
| FIELD-27 |  | text | False | 27 | MISSING_ACCESSIBLE_NAME |
| FIELD-28 | income_source | text | True | 27 | DUPLICATE_TAB_INDEX |
| FIELD-29 | previous_address | text | False | 28 | MISSING_REQUIRED_FLAG |
| FIELD-30 | reference_name | text |  True  | 28 | DUPLICATE_TAB_INDEX |
| FIELD-31 | reference_phone | text | False | 29 | none |
| FIELD-32 | witness_name | text | True | 30 | none |
| FIELD-33 | employer_phone | signature | True | 31 | none |
| MISSING-SSN_LAST4 | ssn_last4 |  |  |  | MISSING_FIELD |
| MISSING-EMPLOYER_NAME | employer_name |  |  |  | MISSING_FIELD |
| MISSING-PREFERRED_CONTACT | preferred_contact  |  |  |  | MISSING_FIELD |
| MISSING-CO_SIGNER_ID |  co_signer_id  |  |  |  | MISSING_FIELD |
| MISSING-CO_SIGNER_EMAIL |  co_signer_email  |  |  |  | MISSING_FIELD |

## Signature fields are exempt from the required-flag rule

FIELD-05 (signature) and FIELD-11 (co_signer_signature) are both marked mandatory on the
source form and neither carries a required flag. This looks like a MISSING_REQUIRED_FLAG
finding, but signature-type fields are exempt from the required-flag rule because
e-signature capture enforces completion outside the form's own required-field validation.
The finding for both is therefore none — the signature exemption is not a violation.
FIELD-33 (employer_phone) is a non-mandatory signature field that IS flagged required,
which is over-flagging — not a violation. The finding is none.

## Missing accessible name (highest priority)

FIELD-03 has a blank field_name, so the finding is MISSING_ACCESSIBLE_NAME.
FIELD-25 has a whitespace-only field_name that trims to blank.
FIELD-27 also has a blank field_name AND shares tab index 27 with FIELD-28,
but MISSING_ACCESSIBLE_NAME has higher priority than DUPLICATE_TAB_INDEX,
so the finding is MISSING_ACCESSIBLE_NAME.

## Missing required flag (exact-token rule)

FIELD-02 (date_of_birth) is mandatory, not a signature, and has required_flag=False.
FIELD-18 (term_months) is mandatory and has required_flag="1" — only True/true/TRUE counts.
FIELD-29 (previous_address) is mandatory, not flagged, AND shares tab index 28 with FIELD-30.
MISSING_REQUIRED_FLAG has higher priority than DUPLICATE_TAB_INDEX, so the finding is
MISSING_REQUIRED_FLAG.

## Over-flagging is not a violation

FIELD-10 (co_signer_name) is not mandatory on the source form but IS flagged required.
FIELD-15 (branch_code) has required_flag=yes which is not True, but the source form does
not mark it mandatory, so this is not a violation. FIELD-26 (emergency_contact) is not
mandatory but IS flagged required — over-flagging is acceptable. The finding is none.
FIELD-32 (witness_name) has a duplicate field_id; the last row wins, and it is
over-flagged (not mandatory but flagged) — the finding is none.

## Duplicate tab index

FIELD-04 shares tab index 2 with FIELD-02 (which already carries MISSING_REQUIRED_FLAG
at higher priority). FIELD-12, FIELD-14, and FIELD-21 share tab index 12. FIELD-28
shares tab index 27 with FIELD-27 (which carries MISSING_ACCESSIBLE_NAME at higher
priority). FIELD-30 shares tab index 28 with FIELD-29 (which carries MISSING_REQUIRED_FLAG
at higher priority). Only fields whose highest-priority finding is the duplicate tab
get DUPLICATE_TAB_INDEX.

## Whitespace trimming

FIELD-30 has required_flag=' True ' with leading and trailing spaces; after trimming it
is True, so it counts as flagged. FIELD-31 has tab_index=' 29 ' which trims to 29.
Source field names with leading or trailing whitespace (e.g. ' collateral_desc',
'preferred_contact ', ' co_signer_id ', ' co_signer_email ') must be trimmed before
matching against converted field names.

## Last-wins on duplicate field_id

FIELD-32 appears twice in the converted inventory. The last row in the file wins —
the second FIELD-32 row (required_flag=True) is the one that counts, not the first.

## Missing source fields

employer_name, witness_name, preferred_contact, co_signer_id, and co_signer_email
appear on the source form's field inventory but were never converted into the fillable PDF.
Each gets a MISSING_FIELD finding row with the source field's name in the field_name column.

## Finding priority

When a converted field trips multiple rules, the finding precedence is
MISSING_ACCESSIBLE_NAME > MISSING_REQUIRED_FLAG > DUPLICATE_TAB_INDEX > none.

## Signature exemption type mismatch

FIELD-44 has source type=signature (mandatory) but converted type=text. The required-flag
exemption applies only to converted fields of type signature, not source fields of type
signature. Since FIELD-44 is converted as text, it is not exempt and needs required_flag=True.
Its required_flag is False, so finding is MISSING_REQUIRED_FLAG.

FIELD-45 has converted type=signature and source type=text (mandatory). Since the converted
field is a signature field, it is exempt from the required-flag rule regardless of the source
type. Finding is none.

## Last-row-wins type change

FIELD-46 appears twice in the converted inventory. The first row has type=signature and the
second row has type=text. The last row wins, so FIELD-46 is a text field. Since the source
marks it mandatory and the converted type is text (not signature), the required-flag exemption
does not apply. Its required_flag is False, so finding is MISSING_REQUIRED_FLAG.

## Blank name priority

FIELD-47 has a blank field_name. Even though it also shares tab_index 33 with other fields
(duplicate tab) and the source marks its field as mandatory, MISSING_ACCESSIBLE_NAME has
higher priority than both MISSING_REQUIRED_FLAG and DUPLICATE_TAB_INDEX. Finding is
MISSING_ACCESSIBLE_NAME.

## Required flag token validation

FIELD-48 has required_flag="TRUE" (uppercase). The standard accepts True, true, and TRUE as
valid required flags. Since the source marks it mandatory and the converted type is text,
TRUE satisfies the required-flag rule. Finding is none.

## Last-row-wins name change

FIELD-49 appears twice in the converted inventory. The first row has field_name=
"source_mandatory_field" and the second row has field_name="renamed_field". The last row
wins, so FIELD-49's name is "renamed_field". Since "renamed_field" does not appear in the
source inventory, there is no mandatory match, so no required-flag check applies. Finding
is none. However, "source_mandatory_field" from the source inventory no longer matches any
converted field, so it gets a MISSING_FIELD row.

## Whitespace trim matching

FIELD-50 has field_name=" spaced_field " with leading and trailing spaces. After trimming,
the name is "spaced_field", which matches the source inventory field "spaced_field"
(mandatory=True). Since the converted type is text (not signature), the required-flag
exemption does not apply. Its required_flag is False, so finding is MISSING_REQUIRED_FLAG.
