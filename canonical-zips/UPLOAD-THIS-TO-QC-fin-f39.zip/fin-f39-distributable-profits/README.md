# fin-f39-distributable-profits

Non-connector Harbor task. Compute distributable profits and assess dividend lawfulness from reserves, movements, and dividend records.
