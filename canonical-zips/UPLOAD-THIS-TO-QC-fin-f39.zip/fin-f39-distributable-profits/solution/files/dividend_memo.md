# The proposed final dividend

Profits available for distribution are **2,280,000**. Interim dividends of
750,000 have already been paid since the last annual accounts, so the maximum
further distribution is **1,530,000**. The final dividend the board has proposed is
larger than that, so **it may not lawfully be paid** — it exceeds the profits available by
170,000, and paying it in full would be unlawful to that extent.

| Item | Amount |
|---|---|
| Retained earnings per the last annual accounts | 2,455,000 |
| Revaluation surplus on the property disposed of in the year | 320,000 |
| Fair value gain on the investment property | -180,000 |
| Fair value gain on listed equity investments | 0 |
| Development costs carried as an intangible asset | -260,000 |
| Provision for the Denby litigation | 0 |
| **Profits available for distribution** | **2,280,000** |
| Interim dividends already paid | (750,000) |
| **Maximum further distribution** | **1,530,000** |

## The revaluation surplus that has become realised

320,000 of the revaluation reserve relates to the Fairhurst Road property,
which was **sold during the year**. On disposal that surplus became a **realised** profit and
is available for distribution, whether or not the bookkeeping has moved it out of the
revaluation reserve — and it has not been moved. The reserve heading does not decide the
question. What remains genuinely unrealised in the revaluation reserve is
580,000, and it is that figure, not the full 900,000,
which joins the share capital, the share premium account and the capital redemption reserve in
the 2,430,000 that is not available.

## Two fair value gains, treated differently

Both gains were credited to profit or loss and both sit inside retained earnings. The test is
what the asset is, not where the gain was booked.

The gain on the **listed equity investments** is **realised**: the shares are quoted, the
holding is small against daily volume, and it could be sold at the quoted price without
negotiation and without moving that price. **No adjustment** — it is already in retained
earnings and it belongs there.

The gain on the **investment property** is **unrealised**: its value rests on a valuer's
opinion and selling it would need marketing and negotiation. It is **deducted** in full.

## Development costs

260,000 of development costs has been capitalised and carried as an intangible
asset. That is treated as a **realised loss** and deducted. The exception — directors
justifying special circumstances and saying so in the notes — has not been taken here, so the
whole amount comes out.

## The litigation provision stays where it is

The provision of 140,000 was charged in accordance with accounting standards
and is a **realised loss**. It is not added back because nothing has been paid yet and it is
not added back because the claim may settle for less. It has already reduced retained earnings
and it stays reduced.

## Conclusion for the board

The interim dividends of 750,000 were within the profits available and stand. The
proposed final dividend cannot be paid in full: the most that may lawfully be distributed now
is 1,530,000. Either the final dividend is reduced to that amount or below, or
interim accounts showing sufficient realised profits are prepared to support a larger one.


## Unquoted equity investments

A fair value gain of 55,000 on unquoted equity investments was credited to profit or loss and
sits in retained earnings. The shares are in a private company with no public market — they
cannot be sold without negotiation, so the gain is **unrealised** and must be **deducted**.
This is different from the listed equity gain, which is realised because the shares are quoted
and readily convertible to cash.

## Development costs with special circumstances

Development costs of 100,000 were capitalised as an intangible asset. Unlike the 260,000
development costs (where no special circumstances were identified), the directors **have**
identified special circumstances and stated them in Note 7 to the accounts. The exception
applies, so these costs are **not deducted** from distributable profits.

## Mill Lane property under sale contract

A revaluation surplus of 200,000 on the Mill Lane property sits in the revaluation reserve.
The property is under a **binding sale agreement**, but **completion has not yet occurred**.
Until completion, the asset is still held and the surplus is **unrealised** — it is not
available for distribution. This is different from the Fairhurst Road property, which was
**sold** during the year (completion occurred), making its surplus realised. The
non-distributable capital increases by 200,000 to 2,630,000.
