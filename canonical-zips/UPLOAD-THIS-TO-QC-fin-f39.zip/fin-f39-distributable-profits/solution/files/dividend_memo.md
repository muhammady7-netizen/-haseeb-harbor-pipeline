# The proposed final dividend

Profits available for distribution are **2,152,000**. Interim dividends of
**750,000** have already been **paid** since the last annual accounts, so the maximum
further distribution is **1,402,000**. A third interim of 200,000 has been
**declared but not yet paid**; a fourth interim of 100,000 has status **PAID** which
is not the same as **Paid** — the policy says only the exact token Paid (case-sensitive)
counts as paid. A special dividend of 50,000 has status **paid** (lowercase) which
is also not Paid — case matters. None of these reduce the profits available. The final
dividend the board has proposed is **1,405,000**, which **exceeds** the maximum, so
**it may not lawfully be paid**.

## Revaluation surpluses

**Revaluation reserve A** holds 900,000: 580,000 for Willowbrook House (still held,
unrealised) and 320,000 for Fairhurst Road (disposed, realised). The Grangeford warehouse
surplus of 175,000 was transferred out of this reserve to retained earnings during the year
— it is realised on disposal and already included in the retained earnings starting point,
so there is **no separate adjustment**.

**Revaluation reserve B** holds 600,000: 200,000 Treetop (held, unrealised), 300,000
Maple Court (disposed, realised), 50,000 Oak Plaza disposed (realised), 50,000 Oak Plaza
held (unrealised).

Only the disposed portions that have NOT been transferred are added: 320,000 + 300,000 + 50,000 = 670,000.

## Fair value gains

**Listed equity** (95,000): realised — quoted, small holding. No adjustment.

**UK government bonds** (60,000): realised — deep market, screen price. No adjustment.

**Brookvale investment property** (180,000): unrealised — valuer's opinion. Deducted.

**Helmsley private equity** (85,000): unrealised — unquoted, negotiation needed. Deducted.

**Meridian plc block holding** (110,000): unrealised — oversized listed holding, block trade
would move the price. Deducted.

**Oakridge forestry plantation** (42,000): unrealised — biological asset, specialist valuation
requires negotiation. Deducted.

**Quantex ETF** (33,000): unrealised — although the ETF units are quoted, the holding is an
**oversized block** relative to average volume; a sale would require a negotiated block trade
and would move the screen price. Being quoted is not enough. Deducted.

**Northcliffe corporate bonds** (48,000): unrealised — thin-market single-issuer corporate
debt, negotiation required, not equivalent to UK gilts. Deducted.

**Dividend received from minority investment** (28,000): realised — cash dividend is a realised
profit regardless of whether the investment is quoted. No adjustment.

## Development costs

**Project A** (260,000): FD email is NOT notes to the accounts. Realised loss. Deducted.

**Project B** (120,000): Note 17 in the accounts. Exception applies. No adjustment.

**Project C** (90,000): Strategic Report is NOT notes to the accounts. Realised loss. Deducted.

**Project D** (75,000): Directors' Report is NOT notes to the accounts. Realised loss. Deducted.

## Provisions

**Denby litigation** (140,000): IAS 37 compliant. Realised loss. No adjustment.

**Elmwood restructuring** (80,000): NOT IAS 37 compliant. Not a realised loss. Added back.

**Westfield warranty** (65,000 net): IAS 37 compliant. Partial reversal (20,000) does not
change the treatment — it is still a realised loss. No adjustment / not added back.

## Capitalisation

Bonus issue capitalising 250,000 of realised profits into share capital. Reduces the pool
pound for pound. Not a dividend — does not appear on the dividend record. Deducted.

## Case sensitivity

- Paid counts (first and second interims: 750,000 total)
- PAID does not count (fourth interim: 0)
- paid (lowercase) does not count (special dividend: 0)
- Declared but not yet paid does not count (third interim: 0)
- Proposed does not count (final dividend: 0)

## Conclusion for the board

Maximum further distribution is **1,402,000**. The proposed final dividend of
**1,405,000** exceeds that maximum, so **it may not lawfully be paid**.
