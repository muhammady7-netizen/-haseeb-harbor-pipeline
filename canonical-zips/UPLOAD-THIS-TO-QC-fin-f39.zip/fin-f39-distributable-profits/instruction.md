# Task

The board meets next week to declare the final dividend and I need the distributable profits paper. From the attached reserves, the movements in the year and the dividend record, work out the profits available for distribution and whether the proposed final dividend can lawfully be paid. The attached policy is authoritative on what counts as a realised profit, on revaluation surpluses, on fair value gains, on capitalised development costs, on provisions, and on the accounts by reference to which a distribution is justified. Save `distributable_profits.csv` with the columns `item,amount_gbp,treatment`, showing the build from retained earnings and including any item you considered and decided needed no adjustment. Then write `dividend_memo.md` explaining each adjustment, each item you deliberately left alone, and what the board can and cannot declare.

---
Delivery conventions for this run (added by the eval harness; the request above is unchanged):
- The attachments are provided read-only at: `input/distribution_policy.md`; `input/reserves.csv`; `input/movements.csv`; `input/dividends.csv`. Read them there.
- Save your deliverables into your current working directory using exactly these filenames:
    - `distributable_profits.csv` — Build from retained earnings to distributable profits
    - `dividend_memo.md` — Markdown memo for the board
    - `results.json` — a JSON object with the keys `distributable_profits_gbp`, `non_distributable_capital_gbp`, `dividends_paid_gbp`, `maximum_further_dividend_gbp`, `proposed_dividend_is_lawful`
- Writing those files is the required deliverable and must be your final action; confirm each one exists before you answer.

---

## Working environment

- Your current working directory is `/app`, and it is writable.
- The read-only attachments referred to as `input/` are at `/app/input`.
- Write every deliverable into `/app`, at the exact filenames listed above.
