# Task

The board meets next week to declare the final dividend and I need the distributable profits paper. From the attached reserves, the movements in the year and the dividend record, work out the profits available for distribution and whether the proposed final dividend can lawfully be paid. The attached policy is authoritative — read every rule carefully, including when a declared dividend counts as already made, which fair-value gains are realised (including when a listed holding fails the readily-convertible test), what counts as notes to the accounts for the development-cost exception (and what does not), how post-accounts capitalisation of profits affects the pool, and how a mixed revaluation reserve splits between realised and unrealised portions.

Save `distributable_profits.csv` with the columns `item,amount_gbp,treatment`, showing the build from retained earnings to distributable profits and including any item you considered and decided needed no adjustment. The schedule should have one row per item (adjustments, no-adjustment items, the total profits available, distributions paid, the maximum further distribution, and capital and reserves not available). Use these conventions:

- Each adjustment item gets one row. Deductions (unrealised gains removed from retained earnings, development costs treated as a realised loss) must show a **negative** amount_gbp. Items needing no adjustment must show **0** in amount_gbp. A provision that is added back to retained earnings (because it was not charged in accordance with accounting standards) must show a **positive** amount_gbp. Distributions already paid must show a **negative** amount_gbp.
- Include the total profits available for distribution, the distributions already paid, the maximum further distribution, and the total of capital and reserves not available for distribution (share capital, share premium, capital redemption reserve, and the unrealised portion of the revaluation reserves) as separate rows in the CSV. The total profits row must include the words "Profits available for distribution" in the item column. The non-distributable row must include "Capital and reserves not available" in the item column.
- For any dividend whose status in the record is not exactly `Paid` after trimming whitespace (case-sensitive — `PAID` is not `Paid`), include a row showing the dividend description with amount_gbp 0 and the treatment explaining why it does not count as paid. The item column must contain the literal token as it appears in the dividend record (e.g. `PAID` or `Declared but not yet paid`).

Then write `dividend_memo.md` (at least 500 characters) explaining each adjustment, each item you deliberately left alone, and what the board can and cannot declare. The memo must specifically address:
- Each revaluation surplus that was realised on disposal (Fairhurst, Maple Court, Oak Plaza partial disposal)
- Each unrealised surplus still held (Willowbrook, Treetop, Oak Plaza retained portion)
- Each fair-value gain and whether it is realised or unrealised (Brookvale investment property, listed equity, Meridian plc block holding, Helmsley private equity, government bonds)
- Development costs (projects A, B and C — which qualify for the notes exception and which do not; strategic report is not notes)
- Any post-accounts capitalisation of profits (bonus issue) and how it reduces the pool separately from Paid dividends
- Provisions (Denby litigation, Elmwood restructuring — which is properly charged under IAS 37 and which is not)
- The case-sensitivity of `Paid` vs `PAID` in the dividend record
- The declared-but-unpaid third interim dividend
- The maximum further distribution amount and whether the proposed dividend may lawfully be paid

The attachments are provided read-only at `input/distribution_policy.md`, `input/reserves.csv`, `input/movements.csv`, and `input/dividends.csv`. Save your deliverables into your current working directory using exactly these filenames:

- `distributable_profits.csv` — Build from retained earnings to distributable profits
- `dividend_memo.md` — Markdown memo for the board
- `results.json` — a JSON object with the keys `distributable_profits_gbp`, `non_distributable_capital_gbp`, `dividends_paid_gbp`, `maximum_further_dividend_gbp` (all integer numbers of pounds, not arrays or strings), and `proposed_dividend_is_lawful` (a boolean: `true` if the proposed final dividend may lawfully be paid, `false` otherwise)

Writing those files is the required deliverable and must be your final action; confirm each one exists before you answer. The memo should be at least 500 characters and explain the reasoning behind each adjustment decision. The CSV must include rows for: retained earnings (starting point), each revaluation surplus (Fairhurst, Maple Court, Oak Plaza), each fair-value gain (Brookvale, listed equity, Meridian block, Helmsley, government bonds), development costs (projects A, B and C), provisions (Denby and Elmwood), post-accounts capitalisation, the total profits available for distribution, distributions already paid, any unpaid/declared dividends with zero amount, the maximum further distribution, and capital and reserves not available for distribution.

## Working environment

- Your current working directory is `/app`, and it is writable.
- The read-only attachments referred to as `input/` are at `/app/input`.
- Write every deliverable into `/app`, at the exact filenames listed above.
