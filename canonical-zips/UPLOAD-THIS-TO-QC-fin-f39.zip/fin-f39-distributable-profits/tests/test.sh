#!/bin/bash
# Harbor verifier entrypoint. Harbor copies this to /tests/test.sh and runs it
# from the task working directory; reward is read back from
# /logs/verifier/reward.txt.
mkdir -p /logs/verifier

cd /app || exit 1

python3 -m pytest \
    --ctrf /logs/verifier/ctrf.json \
    /tests/test_outputs.py \
    -rA
status=$?

# Fractional reward: passed/total
if [ $status -eq 0 ]; then
    echo 1 > /logs/verifier/reward.txt
else
    python3 -c "
import json
try:
    with open('/logs/verifier/ctrf.json') as f:
        data = json.load(f)
    tests = data.get('results', {}).get('tests', [])
    passed = sum(1 for t in tests if t.get('status') == 'passed')
    total = len(tests)
    reward = passed / total if total > 0 else 0.0
    print(reward)
except:
    print(0.0)
" > /logs/verifier/reward.txt
fi

exit 0
