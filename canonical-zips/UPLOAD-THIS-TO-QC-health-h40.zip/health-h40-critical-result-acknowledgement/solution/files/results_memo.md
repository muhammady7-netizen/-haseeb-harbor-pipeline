# CR-7 critical results audit - 35 results

16 results are clean.

## Late notifications

- **R-02** (tier 1) - notified 45 min after clock start (limit 30 min). Clock started 2026-06-15T22:10.
- **R-09** (tier 2) - notified 300 min after clock start (limit 240 min). Clock started 2026-06-15T08:30.
- **R-13** (tier 1) - notified 50 min after clock start (limit 30 min). Clock started 2026-06-15T21:00.
- **R-16** (tier 2) - notified 931 min after clock start (limit 240 min). Clock started 2026-06-15T17:59.
- **R-21** (tier 1) - notified 36 min after clock start (limit 30 min). Clock started 2026-06-17T23:59.
- **R-26** (tier 1) - notified 31 min after clock start (limit 30 min). Clock started 2026-06-17T16:00.
- **R-31** (tier 1) - notified 35 min after clock start (limit 30 min). Clock started 2026-06-20T23:00.

## Late or absent acknowledgements

- **R-06** - no recognised acknowledgement (unapproved ward_clerk), so the acknowledgement window was missed (window 60 min). Clock started 2026-06-15T16:00.
- **R-22** - no recognised acknowledgement (unapproved nurse_hca), so the acknowledgement window was missed (window 60 min). Clock started 2026-06-17T14:00.
- **R-03** - acknowledged at 80 min after clock start (limit 60 min). Clock started 2026-06-15T14:00.
- **R-04** - acknowledged at 90 min after clock start (limit 60 min). Clock started 2026-06-16T03:00.
- **R-10** - has no recognised acknowledgement (limit 480 min). Clock started 2026-06-15T10:00.
- **R-13** - acknowledged at 90 min after clock start (limit 60 min). Clock started 2026-06-15T21:00.
- **R-15** - acknowledged at 510 min after clock start (limit 480 min). Clock started 2026-06-15T16:00.
- **R-16** - acknowledged at 1081 min after clock start (limit 480 min). Clock started 2026-06-15T17:59.
- **R-21** - acknowledged at 71 min after clock start (limit 60 min). Clock started 2026-06-17T23:59.
- **R-24** - acknowledged at 481 min after clock start (limit 480 min). Clock started 2026-06-17T11:00.
- **R-27** - acknowledged at 481 min after clock start (limit 480 min). Clock started 2026-06-17T17:59.
- **R-30** - acknowledged at 481 min after clock start (limit 480 min). Clock started 2026-06-21T10:00.
- **R-32** - acknowledged at 3841 min after clock start (limit 480 min). Clock started 2026-06-19T17:59.
- **R-33** - acknowledged at 490 min after clock start (limit 480 min). Clock started 2026-06-20T08:00.
- **R-35** - no recognised acknowledgement because the register entry is by an unapproved role (limit 60 min). Clock started 2026-06-22T09:00.

## Unapproved acknowledger

- **R-06** - register shows ward_clerk; that role is unapproved / not on the approved list, so CR-7 treats it as no acknowledgement (acknowledgement_minutes left empty). Because there is no recognised acknowledgement the acknowledgement window was missed; escalation was recorded.
- **R-22** - register shows nurse_hca; that role is unapproved / not on the approved list, so there is no recognised acknowledgement (acknowledgement_minutes left empty). Because there is no recognised acknowledgement the acknowledgement window was missed; escalation was recorded.
- **R-35** - register shows phlebotomist; that role is unapproved / not on the approved list, so acknowledgement_minutes is left empty. The acknowledgement window was missed and no escalation appears on the register.

## Missing escalation

- **R-04** - missed acknowledgement window with no escalation on register.
- **R-13** - missed acknowledgement window with no escalation on register.
- **R-16** - missed acknowledgement window with no escalation on register.
- **R-21** - missed acknowledgement window with no escalation on register.
- **R-30** - missed acknowledgement window with no escalation on register.
- **R-33** - missed acknowledgement window with no escalation on register.
- **R-35** - missed acknowledgement window with no escalation on register (unapproved phlebotomist entry does not close the window).

## What is not a finding

- Weekend results: the charter says core hours are 08:00-18:00 without excluding weekends, so Sunday clocks still run.
- **R-34** - tier 2 on Sunday; notified at exactly 240 min and acknowledged at exactly 480 min after clock start, so both inclusive limits are met and it is compliant.
- R-32 released Friday 17:59: clock starts immediately (within core hours), not Monday.
- R-33 released Friday 18:00: clock starts Saturday 08:00 (next morning), not Monday.
- Out-of-hours tier 2 results with long wall-clock times that are compliant.
- Inclusive boundaries: exactly at the window limit is within it.
- An escalation that was not required is not a finding.
