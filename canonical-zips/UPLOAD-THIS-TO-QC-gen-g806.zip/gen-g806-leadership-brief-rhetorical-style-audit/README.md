﻿# gen-g806-leadership-brief-rhetorical-style-audit

Non-connector Harbor task.
