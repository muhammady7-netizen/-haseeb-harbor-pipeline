# Policy errata v2 (OBSOLETE)

Do **not** use this file.

Superseded in full by `policy_errata_v3.md`.
