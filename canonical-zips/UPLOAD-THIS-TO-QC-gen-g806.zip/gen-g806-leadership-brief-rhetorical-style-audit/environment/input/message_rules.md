# Message rules (AUTHORITATIVE)

## Opening purpose
Every brief must open with purpose `decision`. An opening that is `evidence` or `context` incurs a 15-point penalty.

## Permitted purpose transitions
- `decision` -> `evidence` -> `context` -> `evidence` -> `context` (allowed)
- `decision` -> `context` (allowed)
- `evidence` -> `context` (allowed)
- `context` -> `evidence` (allowed)
- Any transition to `decision` after position 1 is a transition breach (10-point penalty each).
- Repeating the same purpose consecutively is a transition breach (5-point penalty each).

## Answer distance
The answer distance for a question is the position of the earliest sentence that answers it, minus 1 (0 = answered in the first sentence). An unanswered question incurs a 20-point penalty. A question answered at distance > 5 incurs a 5-point penalty.

## Word budget
Each brief has a word budget of 200 words. Exceeding the budget by more than 20 words incurs a 10-point penalty.

## Coherence score
Start from 100. Subtract all penalties. Round to the nearest integer (half-up).

## Passing score
A brief **passes** when its coherence score is **>= 80**. Briefs below 80 are failing briefs for the memo and for `passing_briefs` / `failing_briefs` counts.

## Trace representation
For each question, status is exactly `answered` or `unanswered`. Unanswered questions use an empty `answer_sentence_id` and `answer_distance = -1`.

## Recommended move
Recommend exactly one sentence relocation that produces the largest score improvement without changing question coverage. If ties, use smallest movement distance, then smallest sentence ID. Format: `sentence_id:from_position->to_position`. The move must not lower the score.
