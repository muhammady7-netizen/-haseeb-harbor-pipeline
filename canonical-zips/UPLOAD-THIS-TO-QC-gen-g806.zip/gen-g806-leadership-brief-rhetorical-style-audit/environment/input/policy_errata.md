# Policy errata (OBSOLETE)

Do **not** use this file.

Superseded in full by `policy_errata_v2.md`.
