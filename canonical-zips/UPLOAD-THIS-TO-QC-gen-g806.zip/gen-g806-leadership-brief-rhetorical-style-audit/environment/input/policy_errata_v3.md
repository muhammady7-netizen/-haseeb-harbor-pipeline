# Policy errata v3 (AUTHORITATIVE)

Supersedes the style guide, `policy_errata.md`, `policy_errata_v2.md`, and any informal
ops notes.

1. **One finding only.** No `|` joins. Priority (first match wins):

   `ON_HOLD` > `RETIRED` > `OUT_OF_WINDOW` > `NEGATION_PIVOT_USED` > `RUNTIME_OUT_OF_BAND` > `UNCITED_SCRIPTURE_REF` > `none`

2. **Runtime bands (effective minutes)**
   - `standard` → **4–8** inclusive
   - `extended` → **5–10** inclusive (not 4–10, not 4–12)

3. **Effective runtime** = `timing_log.timed_minutes` + `timing_adjustments.adjustment_minutes`.

4. **Retirement** — if `retirement_register.csv` lists `status=RETIRED`, finding is `RETIRED`
   (unless already `ON_HOLD`).

5. **Air window** — if `air_window.csv` has `in_window=False`, finding is `OUT_OF_WINDOW`
   (unless already `ON_HOLD` or `RETIRED`).

6. **`results.json`**
   - `script_count` = inventory rows with `clearance_status=CLEARED` only (HOLD rows are
     still written in the CSV, but they do **not** count in `script_count`)
   - `flagged_count` = CSV rows whose finding is not `none`
   - `negation_pivot_count` / `uncited_scripture_count` / `runtime_breach_count` = rows whose
     single finding equals that exact code
