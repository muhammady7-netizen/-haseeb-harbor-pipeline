# Leadership brief style audit — 39 scripts

Graded with `policy_errata_v4.md` (v1–v3 errata obsolete). One finding only.

## Errata v4 join / token rules

Trim and case-insensitive `script_id` keys; last-wins per file. Air window is out only for
exact `False`. Retirement requires exact `RETIRED`. Scripture flags accept only exact
`true`. Minutes accept zero-padding, a leading `+`, and decimal values. Effective minutes
= timed + adjustment (adjustment may be negative). Extended band remains **5–10**.
`script_count` counts CLEARED rows only (34).

## Holds / retired / window

- SC-13, SC-15, SC-22, SC-32 → `ON_HOLD` (SC-22 clearance last-wins from CLEARED to hold;
  SC-32 short-circuits before its uncited scripture issue is evaluated)
- SC-09, SC-27, SC-29 → `RETIRED` (SC-27 spaced `retired`; SC-29 also has a negation pivot
  in its body excerpt but RETIRED outranks NEGATION_PIVOT_USED in the priority list)
- SC-19 `RETIRED_PENDING` is not retired and stays on the scripture path instead
- SC-31 register `retire` is not exact `RETIRED` (partial match does not retire)
- SC-04, SC-14, SC-28, SC-33 → `OUT_OF_WINDOW` (SC-28 spaced `False`; SC-17 `0` and
  SC-18 `NO` are not; SC-33 also has a negation pivot but OUT_OF_WINDOW outranks
  NEGATION_PIVOT_USED)

## Negation-pivot

SC-02, SC-06, SC-10, SC-17, SC-26, SC-31 → `NEGATION_PIVOT_USED`. The testimony exemption
applies only to Rule 1 for `third_party_testimony` (see SC-05, SC-08, SC-11, SC-24).
SC-26's inventory `is_verbatim_testimony` flag does not exempt a presenter.

## Runtime

SC-07 (effective 9 after +1), SC-11 (effective 13), SC-12 (11 > 10), SC-18 (12), SC-21
(`08`+`+1` → 9), SC-25 (extended 4 < 5) → `RUNTIME_OUT_OF_BAND`.

SC-30 (timed 9, adjustment −1 → effective 8, standard 4–8 inclusive → in band → none).
SC-34 (timed 8.5, adjustment −1 → effective 7.5, standard 4–8 inclusive → in band → none).

## Uncited scripture

SC-03, SC-08, SC-19, SC-24 → `UNCITED_SCRIPTURE_REF`. SC-20 uses `yes`/`false` tokens and
is not an uncited hit under v4 (only exact `true` counts; `yes` is not true).

## Last-wins conflicts

- SC-35 → `RETIRED` (retirement_register has two rows: first `RETIRED_PENDING`, second `RETIRED`;
  last-wins resolves to `RETIRED`, which outranks the negation pivot in the body excerpt)
- SC-36 → `NEGATION_PIVOT_USED` (recording_clearance has two rows: first `HOLD`, second `CLEARED`;
  last-wins resolves to `CLEARED`, so the script continues to Rule 1 and the pivot flags it)

## Clean

SC-01, SC-05, SC-16, SC-20, SC-23, SC-30, SC-34 → `none` (SC-23 inventory last-wins drops
the draft pivot; SC-30 and SC-34 stay in band after negative adjustments bring effective
minutes back within 4–8).

## Finding classes

Assigned codes include `ON_HOLD`, `RETIRED`, `OUT_OF_WINDOW`, `NEGATION_PIVOT_USED`,
`UNCITED_SCRIPTURE_REF`, and `RUNTIME_OUT_OF_BAND` (plus `none` where the script is clean).


## Scripts SC-37 through SC-39

- **SC-37**: A guest speaker (third-party testimony) uses a negation pivot and references scripture without citing it. The testimony exemption applies to negation only â€” not to scripture citation. So the negation pivot is exempted, but the uncited scripture reference is still flagged. Finding: UNCITED_SCRIPTURE_REF.
- **SC-38**: The inventory `uses_negation_pivot` flag is True, but neither the opening line nor the body excerpt contains a negation-pivot pattern ("That's not X. It's Y." / "It's not X. It's Y."). Per the errata, the inventory flag is ignored â€” the finding depends on the actual text. Finding: none.
- **SC-39**: The recording clearance shows two rows for SC-39 (CLEARED then HOLD). Last-wins gives HOLD, so the finding is ON_HOLD. The retirement register shows RETIRED, but ON_HOLD has priority over RETIRED in the finding chain. Finding: ON_HOLD.


## Additional scripts (SC-40 through SC-54)

The expanded inventory adds 15 scripts that exercise edge cases in the errata v4
rules: token exactness (yes/1/Y/TRUE! are not true), last-wins across multiple
registers, precedence collisions (ON_HOLD vs RETIRED vs OUT_OF_WINDOW), casefold
matching (lowercase hold/Retired/false), and boundary conditions in the runtime
band. Each script follows the same finding priority and token rules stated in
the authoritative errata.


## Hardened scripts (SC-81 through SC-95)

The expanded inventory adds 15 scripts exercising edge cases: negation pivot
text variants, speaker attribution close-but-not-exempt forms, multi-file
last-wins interactions, runtime band arithmetic with adjustments crossing
boundaries, scripture token exactness, and retirement token exactness.


## Band definition parsing

The band bounds are defined in `band_definition.csv`. Only rows with status
exactly `active` (after trim and casefold) apply. Rows with `draft`, `proposed`,
or `Active!` status are excluded. Last-wins applies to duplicate band entries.
The correct bounds are: standard 4-8, extended 5-10.

## Band-boundary trap scripts (SC-96 through SC-100)

Several scripts run at effective minutes that fall outside the correct band
bounds but inside the wrong (draft/proposed) bounds. A solver that uses the
wrong band definition will classify these as `none` instead of
`RUNTIME_OUT_OF_BAND`.
