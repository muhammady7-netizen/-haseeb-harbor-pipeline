# Leadership brief style audit — 73 scripts

84 logged scripts checked against the communications style guide and policy errata v4.
26 rows are compliant, 47 carry a finding.

## ON_HOLD

- SC-13 — Welcome to a quiet housekeeping brief.
- SC-15 — It's not the platform that changed me. It's the people who stayed.
- SC-22 — That's not optional. It's required prep for the vote.
- SC-42 — Quiet pastoral reflection.
- SC-51 — Housekeeping brief with no rhetoric.
- SC-53 — Script with both hold and retired flags.
- SC-59 — Script with hold, retirement, and window issues all at once.
- SC-63 — Volunteer coordination script.
- SC-87 — Volunteer coordination with clearance changes.

## RETIRED

- SC-09 — Friends, we are here to thank the teams who carried this year with quiet faithfulness.
- SC-27 — Quiet pastoral note with no pivot and no cite gap.
- SC-49 — Quiet note before the offering.
- SC-52 — Pastoral note with both retirement and window issues.
- SC-86 — Board vote recap with multiple clearance revisions.

## OUT_OF_WINDOW

- SC-04 — Tonight we walk through three decisions our board will face this quarter.
- SC-14 — Capital Sunday preview for the extended teaching block.
- SC-28 — Procedural board preview without rhetoric risk.
- SC-43 — Procedural update with no pivot.

## NEGATION_PIVOT_USED

- SC-02 — That's not a delay. It's a divine appointment.
- SC-06 — That's not failure. It's formation — and the text we opened still stands.
- SC-10 — Keep your eyes on the next hire and the next campus conversation.
- SC-17 — That's not noise. It's the sound of a room learning to listen.
- SC-26 — That's not branding. It's the sentence we keep mistaking for testimony.
- SC-55 — A calm pastoral opening with no rhetoric in the first line.
- SC-56 — It's not my story. It's what the guest kept saying.
- SC-60 — A measured reflection on the season.
- SC-64 — It's not a program. It's a family that showed up.
- SC-81 — A measured reflection on the season ahead.
- SC-82 — A calm pastoral opening with no rhetoric.
- SC-83 — It's not my story. It's what the community kept saying.
- SC-85 — It's not the end. It's the chapter where mercy showed up.
- SC-95 — It's not a setback. It's a setup for the work ahead.

## UNCITED_SCRIPTURE_REF

- SC-03 — The word reminds us that love is patient and kind when the room gets loud.
- SC-08 — It's not luck that carried me. It's the grace I keep naming out loud.
- SC-19 — We lean on a familiar promise without locking the cite.
- SC-24 — It's not courage I invented. It's what the guest kept repeating.
- SC-54 — Scripture reference with a noisy true token.

## RUNTIME_OUT_OF_BAND

- SC-07 — We hold to the promise written in Romans 8:28 as we plan the next season.
- SC-11 — We open with a guest voice from last month's baptism night.
- SC-12 — Extended format walkthrough of the capital plan milestones.
- SC-18 — Extended capital walkthrough continues without a pivot.
- SC-21 — Board update with a measured closer.
- SC-25 — Extended band cold open that runs short on purpose.
- SC-96 — Standard format that runs at 8 minutes.
- SC-97 — Extended format that runs at 5 minutes.
- SC-98 — Standard format with a timing adjustment.
- SC-99 — Extended format that runs very short.

## none (compliant)

SC-01, SC-05, SC-100, SC-16, SC-20, SC-23, SC-40, SC-41, SC-44, SC-45, SC-46, SC-47, SC-48, SC-50, SC-57, SC-58, SC-61, SC-62, SC-84, SC-88, SC-89, SC-90, SC-91, SC-92, SC-93, SC-94

## Testimony exemption

The negation-pivot rule exempts scripts whose speaker attribution is
third_party_testimony. This exemption applies only to the negation-pivot
rule — not to scripture, runtime, or other rules. Several scripts
have a negation pivot in their text but are exempt because their
attribution is third_party_testimony. Scripts attributed to presenter
are never exempt, regardless of inventory flags.

## Band definition parsing

Band bounds are defined in band_definition.csv. Only rows with status
exactly 'active' (after trim and casefold) apply. Rows with 'draft',
'proposed', or 'Active!' status are excluded. Last-wins applies to
duplicate band entries.

## Errata v4 rules applied

All scripts were graded against policy_errata_v4.md, which supersedes
the style guide and all prior errata versions. The rules include:
trim and case-insensitive matching, last-wins on duplicate rows,
exact-token boolean reads, one finding per script with priority
(ON_HOLD > RETIRED > OUT_OF_WINDOW > NEGATION_PIVOT_USED >
RUNTIME_OUT_OF_BAND > UNCITED_SCRIPTURE_REF > none), and
band_definition.csv parsing for runtime bounds.
