# Task

Read `/app/input/brief_sentences.csv`, `/app/input/executive_questions.csv`, and `/app/input/message_rules.md`. Sentences contain `sentence_id,brief_id,position,purpose,word_count,question_ids`; questions contain `question_id,executive_role,priority`; rules define required opening purpose, permitted purpose transitions, answer-distance limits, and brief word budgets.

Evaluate whether each leadership brief answers executive questions in a usable decision sequence. For every brief, map each question to its earliest answering sentence, calculate answer distance from the opening, and detect unanswered questions. Validate the purpose-transition chain and determine whether the opening states a decision, evidence, or context as defined in the rules. Compute a coherence score by subtracting the specified penalties from 100 (round half-up to the nearest integer). Recommend exactly one sentence relocation that produces the largest score improvement without changing question coverage; ties use smallest movement distance, then smallest sentence ID. Format the move as `sentence_id:from_position->to_position`. This is a structural sequencing analysis, not a review of rhetorical phrases.

## Scoring contract (must match message_rules.md)

- Start at 100. Opening purpose other than `decision`: −15 (this is an opening penalty, not a transition breach).
- After position 1, any transition into `decision`: −10 per event (counts as a transition breach).
- Consecutive identical purposes: −5 per event (counts as a transition breach).
- Unanswered question: −20. Answer distance `position-1` greater than 5: −5.
- Word count greater than 220: −10.
- **Passing score threshold is 80.** Briefs with `coherence_score >= 80` pass; below 80 fail.
- `results.json` `avg_score` is the mean of the eight coherence scores, rounded half-up to **two decimal places**.

## Trace status vocabulary

In `question_trace.csv`, `status` must be exactly `answered` or `unanswered`. For unanswered questions set `answer_sentence_id` empty and `answer_distance` to `-1`.

## Deliverables

Write `/app/brief_coherence.csv` with `brief_id,word_count,question_count,unanswered_questions,transition_breaches,coherence_score,recommended_move,projected_score`. Write `/app/question_trace.csv` with `brief_id,question_id,priority,answer_sentence_id,answer_distance,status`. Write `/app/executive_sequence_memo.md` with one concise subsection **only** for each brief below the passing score (80). Write `/app/results.json` with `brief_count`, `passing_briefs`, `failing_briefs`, `avg_score`, `total_unanswered`, `total_breaches`.

## Verification

Reject malformed headers, repeated sentence positions, duplicate IDs, unknown question references, nonpositive word counts, or missing rules. Sort briefs and questions lexicographically. Recalculate projected scores by applying the proposed move, ensure no recommendation lowers coverage or score, require sorted pipe lists for unanswered question IDs, and confirm all four files exist before completion.

## Working environment

- Your current working directory is `/app`, and it is writable.
- The read-only attachments referred to as `input/` are at `/app/input`.
- Write every deliverable into `/app`, at the exact filenames listed above. All deliverables must be the final action; confirm each one exists before you answer.
