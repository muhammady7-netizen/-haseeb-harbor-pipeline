# Meridian Film Festival — official-selection key-art billing contract rules

Binding for every poster proof logged in `key_art_proof_log.csv` for this slate.
These processing rules are authoritative over informal ops notes.

## 0. Field hygiene (required before any rule)

Before any lookup or compare, **trim** leading/trailing ASCII whitespace on
`poster_id`, `tier`, `co_lead_size_pct`, `billing_block`, and every boolean column.

Match `poster_id` **case-insensitively**. When reporting a `poster_id` in the audit,
use the canonical upper-cased trimmed form (e.g. ` pstr-11 ` → `PSTR-11`).

If the proof log has more than one row for the same `poster_id` (after that keying),
the **last row in the file wins** for every field. Do not merge fields across revisions.

## 1. MFN size parity (per billing block)

Cast members contracted under Most Favored Nations (MFN) billing must be depicted at no
less than **95% of the largest billing-confirmed MFN-tier figure's size within the same
billing block** on the poster (inclusive floor). The `billing_block` column groups posters
into independent billing blocks (e.g. `A`, `B`, `C`). For each billing block separately:

  1. Find the largest parsed `co_lead_size_pct` among MFN-tier surviving proofs in that
     block whose `billing_order_correct` (after trim, lowercased) is **not** exactly
     `false` (a proof with its own billing-order defect is not a valid parity reference)
     and that are not listed in `parity_exemptions.csv`; call this `M_block`.
  2. The parity floor for that block is `0.95 * M_block`.
  3. A non-guest, non-exempt MFN-tier poster in that block **strictly below** its block
     floor is `PARITY_BREACH`.

Parse `co_lead_size_pct` after trim: a leading `+` is allowed; numeric strings such as
`90.25` or `08` are numbers. A **blank or non-numeric** `co_lead_size_pct` (after trim,
leading `+` stripped) is treated as `0`.

**Guest tier** — after trim, lowercased `tier` must equal exactly `guest` — is a separate,
non-MFN tier and is **not subject to this parity clause** at all; a small guest-tier figure
is not a defect, and guest-tier figures are excluded from `M_block`. Values such as `mfn`,
`MFN`, or blank are treated as MFN for parity.

Guest-tier is **not** an exemption from billing-order, baked-text, or credit-block rules.

## 2. Billing order

MFN-tier **and** guest-tier cast must appear in the contractually fixed precedence order.
A reversed order is `BILLING_ORDER_VIOLATION` **only** when, after trim, the lowercased
`billing_order_correct` value equals exactly `false`. Tokens such as `0`, `no`, `N`,
`off`, or blank are **not** order violations.

## 3. No baked-in text or logos

Key art is composited with title treatment and logos after delivery. A proof has
`BAKED_TEXT_PRESENT` **only** when, after trim, the lowercased `baked_text_present`
value equals exactly `true`. Tokens such as `1`, `yes`, `Y`, or blank are **not** baked text.

## 4. Below-the-title credit block

Every proof must carry the complete below-the-title credit block naming all contracted
supporting cast. A block is `CREDIT_BLOCK_INCOMPLETE` **only** when, after trim, the
lowercased `credit_block_complete` value equals exactly `false`. Tokens such as `0`,
`no`, `N`, or blank are **not** incomplete under this clause.

## 5. One finding only (priority)

No `|` joins. Evaluate on the surviving last-wins row. First match wins:

`PARITY_BREACH` > `BILLING_ORDER_VIOLATION` > `BAKED_TEXT_PRESENT` >
`CREDIT_BLOCK_INCOMPLETE` > `none`

## 6. results.json

- `poster_count` = unique posters after last-wins (every surviving row is audited)
- `flagged_count` = audit rows whose finding is not `none`
- `parity_count` / `baked_text_count` = rows whose single finding equals that exact code
- `compliant_count` = rows whose finding is `none`
- `parity_penalty_total` = for every row whose single finding is `PARITY_BREACH`, compute
  that row's penalty = (that row's block floor − that row's parsed `co_lead_size_pct`) × `1.25`;
  **round each row's penalty to 2 decimals (half-up) first**, then sum the rounded per-row
  penalties; round the final total to 2 decimals (half-up).
- `compliant_avg_size` = the arithmetic mean of parsed `co_lead_size_pct` over every row
  whose single finding is `none`; round to 2 decimals (half-up).

## 7. block_summary.csv

Produce `block_summary.csv` with exactly these columns in this order:
`billing_block,poster_count,parity_count,billing_order_count,baked_text_count,credit_count,compliant_count`.
One row per billing block (sorted alphabetically: A, B, C). Each count is derived from
`key_art_audit.csv` by grouping on the poster's `billing_block` (from the proof log, after
trim/last-wins). `poster_count` = posters in that block; the finding columns count rows
whose single finding equals that exact code; `compliant_count` = rows whose finding is
`none`. The sum of the four finding columns plus `compliant_count` must equal
`poster_count` for each block.

## 8. Per-poster parity exemptions

The file `input/parity_exemptions.csv` lists specific poster_ids that are individually
exempt from the MFN size-parity clause (a contractual waiver, separate from the guest-tier
exemption). The file has columns `poster_id,exemption_reason`. Read `poster_id` with the
same trim + case-insensitive keying as the proof log; match it against the surviving
last-wins poster_ids. A poster listed in the exemptions file is exempt from the parity
clause only — it is **not** exempt from billing-order, baked-text, or credit-block rules,
and it is excluded from `M_block` (like guest-tier). Poster_ids in the exemptions file that
do not appear in the proof log are ignored.

## Finding names

`PARITY_BREACH`, `BILLING_ORDER_VIOLATION`, `BAKED_TEXT_PRESENT`,
`CREDIT_BLOCK_INCOMPLETE`, `none`.
