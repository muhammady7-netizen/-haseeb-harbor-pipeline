# gen-g986-festival-key-art-billing-parity-audit

Non-connector Harbor task. Offline festival key-art billing parity audit.

## Deliverables

- `key_art_audit.csv` — poster_id,finding (54 unique posters after last-wins)
- `key_art_memo.md` — explains finding classes, per-block parity floor, guest-tier and per-poster exemptions, last-wins, token traps
- `block_summary.csv` — per-block statistics (billing_block,poster_count,parity_count,billing_order_count,baked_text_count,credit_count,compliant_count)
- `results.json` — poster_count, flagged_count, parity_count, baked_text_count, compliant_count, parity_penalty_total, compliant_avg_size

## Inputs

- `billing_contract_rules.md` — processing rules (7 sections)
- `key_art_proof_log.csv` — 54 posters across 3 billing blocks (A/B/C)
- `parity_exemptions.csv` — per-poster parity waivers

## Verifier

77 deterministic checks + recompute + block_summary consistency test. Fractional reward.
Neutral verifier names (pstrNN). End-anchored per-poster regexes. Concept-based memo anchors.
Dockerfile base image pinned by @sha256 digest.

## Change summary

v14: Added block_summary.csv deliverable + per-block row count check. Fixed Dockerfile sha256 pin.
Fixed review.csv PASS rows (blank change_made). Broadened memo_explains_guest_exemption to
independent lookaheads. Per-block parity floors + multi-file exemptions + per-term-rounded penalty.
