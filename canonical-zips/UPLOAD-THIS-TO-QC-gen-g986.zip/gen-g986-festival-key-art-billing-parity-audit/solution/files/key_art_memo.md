# Meridian Film Festival key-art billing parity audit

17 of 54 unique poster proofs flagged against the
MFN billing contract; 37 are compliant or token-exempt.

Rules applied from `billing_contract_rules.md`: trim/last-wins, the 95% MFN parity floor
measured **per billing block** against the largest billing-confirmed MFN-tier figure in
that block (inclusive), guest-tier and per-poster parity exemptions, exact `true`/`false`
boolean tokens, and single-finding priority (`PARITY_BREACH` > `BILLING_ORDER_VIOLATION` >
`BAKED_TEXT_PRESENT` > `CREDIT_BLOCK_INCOMPLETE` > `none`).

## Per-block parity floors

The parity floor is computed independently for each billing block from the largest
billing-confirmed MFN figure in that block (excluding guest, exempt, and order-defective
posters):
- **Block A**: largest = 95 → floor = `0.95 × 95 = 90.25`. Posters at 91–94 clear the
  block floor (e.g. PSTR-02 91, PSTR-08 92, PSTR-11 93, PSTR-12 94 → `none`). A model
  using the global max (100 → floor 95) would wrongly flag these as PARITY.
- **Block B**: largest = 80 → floor = `0.95 × 80 = 76.0`. Posters at 76–79 clear the
  block floor (e.g. PSTR-19 78, PSTR-20 76, PSTR-23 77, PSTR-28 79 → `none`). A model
  using the global floor 95 would wrongly flag these as PARITY.
- **Block C**: largest = 100 → floor = `0.95 × 100 = 95.0`. Same as the global floor, so
  no block-specific trap. Posters at 95 clear (inclusive); 94 and below breach.

## PARITY_BREACH

Block A: PSTR-07 (90 < 90.25), PSTR-16 (70 < 90.25, multi-defect — parity wins).
Block B: PSTR-29 (`guests` is not `guest`, so parity applies at 50 < 76).
Block C: PSTR-38 (94 < 95), PSTR-50 (`94.99` < 95).
PSTR-13 (85.5 < 90.25), PSTR-21 (75 < 76), and PSTR-48 (93 < 95) would have been PARITY
but are exempt per `parity_exemptions.csv` → `none`.

## BILLING_ORDER_VIOLATION

Exact `false` on `billing_order_correct` after trim: PSTR-03 (Block A, 95 clears floor),
PSTR-10 (guest, Block A), PSTR-24 (Block B, 80 clears floor), PSTR-44 (Block C, 100 clears
floor). Tokens such as `0` / `no` on PSTR-15 / PSTR-30 are not order violations.

## BAKED_TEXT_PRESENT

Exact `true` on `baked_text_present`: PSTR-04 (A), PSTR-25 (B), PSTR-31 (B, guest),
PSTR-40 (C), PSTR-51 (C, guest — baked beats credit). Token `yes` / `1` on PSTR-14 /
PSTR-30 do not count.

## CREDIT_BLOCK_INCOMPLETE

Exact `false` on `credit_block_complete`: PSTR-05 (A), PSTR-26 (B), PSTR-41 (C).

## Guest-tier parity exemption

PSTR-06 (A, 55), PSTR-10 (A, 40), PSTR-22 (B, 30), PSTR-31 (B, 42), PSTR-42 (C, 50), and
PSTR-51 (C, 30) are guest-tier, so the parity clause does not reach their smaller figures.
Guest is not an exemption from order, baked, or credit findings. Exact token `guest` is
required — `guests` on PSTR-29 is not guest-tier.

## Per-poster parity exemptions

`parity_exemptions.csv` lists PSTR-13 (Block A, 85.5 — would breach 90.25), PSTR-21
(Block B, 75 — would breach 76), and PSTR-48 (Block C, 93 — would breach 95) as exempt
from parity → `none`. The file also has ` pstr-21 ` (whitespace + lowercase, requires
trim + case-insensitive matching), PSTR-99 (distractor), and PSTR-37 (moot — already
clears the Block C floor).

## Computed aggregates (results.json)

`parity_penalty_total` sums each PARITY_BREACH row's penalty `(block_floor − size) × 1.25`
**rounded to 2 decimals per poster first, then summed**. `compliant_avg_size` is the mean
`co_lead_size_pct` over the 37 `none` rows =
`85.91` (round 2, half-up).

## Last-wins duplicate

PSTR-17 (Block A): first revision multi-defect, last-wins clean → `none`. PSTR-52 (Block
C): first revision order false, last-wins order true → `none`. PSTR-53 (Block C): first
revision baked true, last-wins not baked → `none`. Do not merge fields across revisions.
