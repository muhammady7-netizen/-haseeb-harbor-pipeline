"""Replays the harness `file_check` spec against the task workspace.

One pytest per graded assertion, so Harbor's per-test grid (and the CTRF report)
names exactly which deliverable check failed. The spec in `verifier.json` and the
engine in `rl_world_verifiers/` are copies of what the task harness runs, so a
result here means the same thing it means there.
"""

import os
import sys
from pathlib import Path

import pytest

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR))

from rl_world_verifiers.models import VerifierSpec, effective_weights  # noqa: E402
from rl_world_verifiers.sources.registry import SourceRegistry  # noqa: E402
from rl_world_verifiers.verifiers import verify_definition  # noqa: E402

WORKSPACE = Path(os.environ.get("HARBOR_TASK_WORKSPACE", "/app"))
SPEC = VerifierSpec.model_validate_json(
    (TESTS_DIR / "verifier.json").read_text(encoding="utf-8")
)
WEIGHTS = effective_weights(SPEC.verifiers)
REGISTRY = SourceRegistry(WORKSPACE)


@pytest.mark.parametrize(
    "definition",
    SPEC.verifiers,
    ids=[definition.name for definition in SPEC.verifiers],
)
def test_deliverable(definition):
    outcome = verify_definition(
        definition,
        REGISTRY,
        WEIGHTS[definition.name],
        config=SPEC.config,
        completion_fn=None,
    )["result"]
    detail = outcome.get("error") or outcome.get("reason") or "assertion failed"
    assert outcome["success"], f"{definition.name}: {detail}"


def _recompute_totals(workspace: Path) -> dict:
    """Recompute results.json from key_art_audit.csv + proof log + exemptions."""
    import csv
    from decimal import Decimal, ROUND_HALF_UP

    def _round(x):
        return float(Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))

    def _parse_size(raw):
        s = (raw or "").strip()
        if s.startswith("+"):
            s = s[1:]
        try:
            return float(s)
        except ValueError:
            return 0.0

    audit_path = workspace / "key_art_audit.csv"
    assert audit_path.is_file(), "key_art_audit.csv missing"
    findings = {}
    with audit_path.open(encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            pid = (row.get("poster_id") or "").strip().upper()
            if pid:
                findings[pid] = (row.get("finding") or "").strip()

    proof_path = workspace / "input" / "key_art_proof_log.csv"
    assert proof_path.is_file(), "key_art_proof_log.csv missing"
    by_id = {}
    with proof_path.open(encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            pid = (row.get("poster_id") or "").strip().upper()
            by_id[pid] = row

    exempt_ids = set()
    exemptions_path = workspace / "input" / "parity_exemptions.csv"
    if exemptions_path.is_file():
        with exemptions_path.open(encoding="utf-8", newline="") as f:
            for row in csv.DictReader(f):
                pid = (row.get("poster_id") or "").strip().upper()
                if pid:
                    exempt_ids.add(pid)

    block_max = {}
    for pid, row in by_id.items():
        if (row.get("tier") or "").strip().lower() == "guest":
            continue
        if pid in exempt_ids:
            continue
        if (row.get("billing_order_correct") or "").strip().lower() == "false":
            continue
        block = (row.get("billing_block") or "").strip()
        block_max[block] = max(block_max.get(block, 0.0), _parse_size(row.get("co_lead_size_pct")))
    block_floors = {b: 0.95 * m for b, m in block_max.items()}

    vals = list(findings.values())
    penalty_total = 0.0
    compliant_sizes = []
    for pid, finding in findings.items():
        size = _parse_size(by_id[pid].get("co_lead_size_pct"))
        if finding == "PARITY_BREACH":
            block = (by_id[pid].get("billing_block") or "").strip()
            floor = block_floors.get(block, 0.0)
            penalty_total += _round((floor - size) * 1.25)
        elif finding == "none":
            compliant_sizes.append(size)
    compliant_avg = sum(compliant_sizes) / len(compliant_sizes) if compliant_sizes else 0.0
    return {
        "poster_count": len(vals),
        "flagged_count": sum(1 for f in vals if f and f != "none"),
        "parity_count": sum(1 for f in vals if f == "PARITY_BREACH"),
        "baked_text_count": sum(1 for f in vals if f == "BAKED_TEXT_PRESENT"),
        "compliant_count": sum(1 for f in vals if f == "none"),
        "parity_penalty_total": _round(penalty_total),
        "compliant_avg_size": _round(compliant_avg),
    }


def test_results_recomputed_from_audit():
    import json
    totals = _recompute_totals(WORKSPACE)
    path = WORKSPACE / "results.json"
    assert path.is_file(), "results.json missing"
    data = json.loads(path.read_text(encoding="utf-8"))
    for key, expected in totals.items():
        got = data.get(key)
        assert got == expected, f"results.json {key}={got!r} != recomputed {expected!r}"


def test_block_summary_consistency():
    import csv as _csv
    audit_path = WORKSPACE / "key_art_audit.csv"
    proof_path = WORKSPACE / "input" / "key_art_proof_log.csv"
    summary_path = WORKSPACE / "block_summary.csv"
    assert audit_path.is_file(), "key_art_audit.csv missing"
    assert proof_path.is_file(), "key_art_proof_log.csv missing"
    assert summary_path.is_file(), "block_summary.csv missing"
    findings = {}
    with audit_path.open(encoding="utf-8", newline="") as f:
        for row in _csv.DictReader(f):
            pid = (row.get("poster_id") or "").strip().upper()
            if pid:
                findings[pid] = (row.get("finding") or "").strip()
    by_id = {}
    with proof_path.open(encoding="utf-8", newline="") as f:
        for row in _csv.DictReader(f):
            pid = (row.get("poster_id") or "").strip().upper()
            by_id[pid] = row
    expected = {}
    for pid, finding in findings.items():
        block = (by_id[pid].get("billing_block") or "").strip()
        if block not in expected:
            expected[block] = {"poster_count": 0, "parity_count": 0, "billing_order_count": 0,
                               "baked_text_count": 0, "credit_count": 0, "compliant_count": 0}
        expected[block]["poster_count"] += 1
        if finding == "PARITY_BREACH":
            expected[block]["parity_count"] += 1
        elif finding == "BILLING_ORDER_VIOLATION":
            expected[block]["billing_order_count"] += 1
        elif finding == "BAKED_TEXT_PRESENT":
            expected[block]["baked_text_count"] += 1
        elif finding == "CREDIT_BLOCK_INCOMPLETE":
            expected[block]["credit_count"] += 1
        elif finding == "none":
            expected[block]["compliant_count"] += 1
    actual = {}
    with summary_path.open(encoding="utf-8", newline="") as f:
        for row in _csv.DictReader(f):
            block = (row.get("billing_block") or "").strip()
            actual[block] = {k: int(row.get(k, 0)) for k in
                             ("poster_count", "parity_count", "billing_order_count",
                              "baked_text_count", "credit_count", "compliant_count")}
    assert set(expected.keys()) == set(actual.keys()), f"blocks differ: expected {sorted(expected)} got {sorted(actual)}"
    for block in sorted(expected):
        for key, val in expected[block].items():
            assert actual[block].get(key) == val, f"block {block} {key}: expected {val} got {actual[block].get(key)}"
