# Task

Audit the attached Meridian Film Festival key-art proof log against
`input/billing_contract_rules.md` — apply every processing rule there (trim, case-insensitive
`poster_id`, last-wins duplicates, the 95% MFN parity floor measured per billing block
against the largest billing-confirmed MFN-tier figure in that block with guest-tier and
per-poster parity exemptions from `input/parity_exemptions.csv`, exact-token boolean reads
for order/baked/credit, and single-finding priority). Check MFN size parity between
co-leads, billing order, whether text or logos were baked into the artwork, and
below-the-title credit-block completeness. Save `key_art_audit.csv` with **exactly two
columns** — `poster_id,finding` — one row per unique poster (canonical `PSTR-##` ids). Do
not copy proof-log columns into the audit. Allowed `finding` values:
`PARITY_BREACH`, `BILLING_ORDER_VIOLATION`, `BAKED_TEXT_PRESENT`, `CREDIT_BLOCK_INCOMPLETE`,
`none`. Then write `key_art_memo.md` explaining each finding class you used, the guest-tier
parity exemption (including why non-`false`/`true` tokens do not fire), how the 95% parity
floor is measured per billing block against the largest billing-confirmed MFN-tier figure,
the per-poster parity exemptions from `input/parity_exemptions.csv`, last-wins on duplicate
proofs, and which proof's smaller figure the parity clause does not reach.

---
Save your deliverables into your current working directory using exactly these filenames:
    - `key_art_audit.csv` — Per-poster audit
    - `key_art_memo.md` — Markdown memo
    - `block_summary.csv` — Per-block summary (columns: billing_block,poster_count,parity_count,billing_order_count,baked_text_count,credit_count,compliant_count; one row per block, sorted A/B/C; counts derived from the audit grouped by block)
    - `results.json` — a JSON object with the keys `poster_count`, `flagged_count`, `parity_count`, `baked_text_count`, `compliant_count`, `parity_penalty_total`, `compliant_avg_size` (the last two are computed aggregates defined in section 6 of the rules; for `parity_penalty_total` you must round each poster's penalty to 2 decimals before summing; write them as JSON numbers, not strings)
- Writing those files is the required deliverable and must be your final action; confirm each one exists before you answer.

---

## Working environment

- Your current working directory is `/app`, and it is writable.
- The read-only attachments referred to as `input/` are at `/app/input`.
- Write every deliverable into `/app`, at the exact filenames listed above.
