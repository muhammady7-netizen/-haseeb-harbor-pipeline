# Table maintenance audit ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â 44 tables

44 tables checked against DBOPS-31. 17 are compliant and 35 carry a
finding.

| Table | Size class | Bloat ratio | Finding |
|---|---|---|---|
| T-13 | large | 0.5 | AUTOVACUUM_DISABLED |
| T-17 | large | 0.4 | AUTOVACUUM_DISABLED |
| T-27 | large | 0.38 | BLOAT_THRESHOLD_EXCEEDED |
| T-04 | large | 0.1 | STALE_STATISTICS |
| T-21 | large | 0.2 | AUTOVACUUM_DISABLED |
| T-26 | large | 0.18 | BLOAT_THRESHOLD_EXCEEDED |
| T-30 | large | 0.2 | BLOAT_THRESHOLD_EXCEEDED |
| T-10 | large | 0.21 | STALE_STATISTICS |
| T-16 | large | 0.2 | BLOAT_THRESHOLD_EXCEEDED |
| T-09 | large | 0.19 | none |
| T-07 | large | 0.12 | none |
| T-15 | large | 0.2 | none |
| T-12 | large | 0.2 | none |
| T-19 | large | 0.41 | BLOAT_THRESHOLD_EXCEEDED |
| T-01 | large | 0.1 | none |
| T-06 | large | 0.25 | BLOAT_THRESHOLD_EXCEEDED |
| T-14 | large | 0.4 | BLOAT_THRESHOLD_EXCEEDED |
| T-18 | large | 0.21 | BLOAT_THRESHOLD_EXCEEDED |
| T-20 | large | 0.1 | AUTOVACUUM_DISABLED |
| T-28 | large | 0.25 | none |
| T-29 | large | 0.25 | BLOAT_THRESHOLD_EXCEEDED |
| T-31 | small | 0.3 | none |
| T-31 | small | 0.3 | none |
| T-32 | small | 0.4 | none |
| T-32 | small | 0.4 | none |
| T-08 | large | 0.45 | BLOAT_THRESHOLD_EXCEEDED |
| T-02 | large | 0.35 | BLOAT_THRESHOLD_EXCEEDED |
| T-03 | large | 0.15 | AUTOVACUUM_DISABLED |
| T-05 | large | 0.55 | BLOAT_THRESHOLD_EXCEEDED |
| T-11 | large | 0.41 | AUTOVACUUM_DISABLED |


## T-05 is a bloat finding (unapproved reindex)

T-05's bloat ratio of 0.55 is far over the large-table cap of 0.2. Although
maintenance_active=True, the reindex is NOT approved ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â reindex_approvals.csv has
approved=False for T-05. The exemption only applies when both maintenance_active=True
AND approved=True in reindex_approvals.csv. Since the reindex is unapproved, the
bloat check applies normally. Finding: BLOAT_THRESHOLD_EXCEEDED.

## Other findings

T-02's bloat ratio of 0.35 is over the large-table cap with no maintenance flag:
`BLOAT_THRESHOLD_EXCEEDED`. T-03 has autovacuum disabled: `AUTOVACUUM_DISABLED`, checked
before its bloat ratio is even considered. T-04's statistics are 45 days stale, over the
30-day limit: `STALE_STATISTICS`. T-08 is judged against the small size class
cap rather than the large one, and its bloat ratio of 0.45 is over that cap:
`BLOAT_THRESHOLD_EXCEEDED`.


## Tables T-09 through T-11

- **T-09**: A large table with bloat ratio 0.19 (under the 0.20 cap) and statistics last refreshed 30 days ago. The policy says "more than 30 days ago" ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â 30 is not more than 30. Finding: none.
- **T-10**: A large table with bloat ratio 0.21 (over the 0.20 cap), under an active reindex operation, with statistics 31 days old. The reindex exemption applies only to the bloat check ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â not to statistics staleness. Finding: STALE_STATISTICS.
- **T-11**: A small table with bloat ratio 0.41 (over the 0.40 cap) and autovacuum disabled. Autovacuum is checked first and overrides every other check. Finding: AUTOVACUUM_DISABLED.

## Boundary equality

- **T-12**: A large table with bloat ratio exactly 0.20 ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â equal to the large-table cap.
  The policy says a table *over* its cap is BLOAT_THRESHOLD_EXCEEDED; 0.20 is not over 0.20,
  it is exactly at the cap. The table is within its allowance. Finding: none.
- **T-14**: A small table with bloat ratio exactly 0.40 ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â equal to the small-table cap.
  0.40 is not over 0.40. Finding: none.
- **T-15**: A large table with bloat ratio 0.200 ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â numerically equal to the large-table
  cap of 0.2. 0.200 is not over 0.2; it is the same value. Finding: none.

## Multi-rule interaction cases

- **T-16**: A large table with bloat ratio 0.20 (at the large cap, not over it ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â so bloat is
  not exceeded), under active reindex (which would exempt bloat, but bloat is already not
  exceeded so the exemption is irrelevant), with statistics 31 days stale. The reindex
  exemption applies only to the bloat check, not to statistics staleness. Finding:
  STALE_STATISTICS.
- **T-17**: A small table with bloat ratio 0.40 (at the small cap, not over it), autovacuum
  disabled, and statistics 50 days stale. Autovacuum is checked first and overrides every
  other check. Finding: AUTOVACUUM_DISABLED.

## Round-half-up traps

- **T-18**: A large table with 205 dead pages out of 1000 total. The raw ratio is 0.205,
  which rounds to 0.21 under round-half-up (the policy's rounding mode). 0.21 is over the
  large-table cap of 0.2. Python's default round() uses round-half-even and would produce
  0.20 (at the cap, not over) ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â this is incorrect. Finding: BLOAT_THRESHOLD_EXCEEDED.
- **T-19**: A small table with 405 dead pages out of 1000 total. The raw ratio is 0.405,
  which rounds to 0.41 under round-half-up. 0.41 is over the small-table cap of 0.4.
  Python's default round() would produce 0.40 (at the cap) ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â this is incorrect.
  Finding: BLOAT_THRESHOLD_EXCEEDED.

## Manual vacuum override

- **T-20**: A large table with autovacuum_enabled=True, but vacuum_type=manual. A manual
  vacuum overrides and supersedes the automatic schedule ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â the table no longer has
  automatic autovacuum protection. Despite autovacuum_enabled being True, the finding is
  AUTOVACUUM_DISABLED.
- **T-21**: A large table with autovacuum_enabled=True and vacuum_type=manual, bloat
  ratio 0.20 (at the large cap, not over), and statistics 45 days stale. The manual vacuum
  override means autovacuum is considered disabled, which is checked first and overrides
  every other check. Finding: AUTOVACUUM_DISABLED.

## Stale-stats cap tightening

- **T-26**: A large table with bloat ratio 0.18 (under the normal 0.20 cap) and statistics
  35 days stale. When stats are stale, the bloat cap is tightened by 0.05: 0.20 - 0.05 =
  0.15. The ratio 0.18 is over the tightened cap 0.15. Because bloat is checked before
  staleness in the finding precedence, the finding is BLOAT_THRESHOLD_EXCEEDED (not
  STALE_STATISTICS).
- **T-27**: A small table with bloat ratio 0.38 (under the normal 0.40 cap) and statistics
  45 days stale. Tightened cap: 0.40 - 0.05 = 0.35. The ratio 0.38 is over 0.35.
  Finding: BLOAT_THRESHOLD_EXCEEDED.

## Legacy days_since_analyze field

The `days_since_analyze` field in the export is a legacy estimate and is NOT reliable.
Staleness must be computed from the `audit_date` and `last_analyzed` date fields. Several
tables have `days_since_analyze` values that differ from the actual date-based computation
by 5 days. Using the legacy field instead of computing from dates will produce incorrect
findings for those tables.

## Reindex approval expiry

- **T-28**: A large table with bloat ratio 0.25 (over the 0.20 cap), maintenance_active=True,
  and reindex_log shows approved=True with valid_until=2026-09-15. Since valid_until
  (2026-09-15) is after audit_date (2026-09-01), the approval is valid and the table is
  exempt from the bloat check. Finding: none.
- **T-29**: A large table with the same bloat ratio 0.25 and maintenance_active=True, and
  reindex_log shows approved=True, BUT valid_until=2026-08-25. Since valid_until
  (2026-08-25) is BEFORE audit_date (2026-09-01), the approval has expired. The table is
  NOT exempt ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â the bloat check applies normally. Finding: BLOAT_THRESHOLD_EXCEEDED.

## At-cap with stale stats

- **T-30**: A large table with bloat ratio 0.20 ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â exactly equal to the original large-table
  cap of 0.2. However, statistics are 36 days stale (more than 30), so the stale-stats cap
  tightening rule reduces the effective cap to 0.15. The ratio 0.20 is over the effective
  cap 0.15. The "at-cap = compliant" rule applies to the effective cap, not the original
  cap ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â a table whose ratio equals the original cap but exceeds the effective (tightened)
  cap is BLOAT_THRESHOLD_EXCEEDED. Finding: BLOAT_THRESHOLD_EXCEEDED.

## bloat_ratio field is unreliable

The `bloat_ratio` field in the export is computed with Python's default rounding
(round-half-even) and gives incorrect results for rounding-boundary cases. The correct
ratio must be computed from `dead_pages / total_pages` using round-half-up. For example,
T-18 has 205 dead pages out of 1000 total: the correct ratio is 0.21 (round-half-up),
but the `bloat_ratio` field shows 0.2 (Python's round-half-even).

## Computed size class

The `size_class` column in the export is a legacy field and is NOT reliable. Size class
must be computed from `total_pages`: >= 500 is large (cap 0.2), < 500 is small (cap 0.4).

- **T-31**: total_pages=400 (< 500), so computed size class is small (cap 0.4). The
  `size_class` column says "large" (WRONG). Bloat ratio 0.30 is under the small cap 0.4.
  Finding: none. If the column's "large" were used (cap 0.2), 0.30 > 0.2 would give
  BLOAT_THRESHOLD_EXCEEDED (incorrect).
- **T-32**: total_pages=400 (< 500), computed size class is small (cap 0.4). The column
  says "large" (WRONG). Bloat ratio 0.40 equals the small cap 0.4 ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â at the cap, not over.
  Finding: none. If "large" were used (cap 0.2), 0.40 > 0.2 would give BLOAT (incorrect).

Several other tables (T-03, T-04, T-06, T-08, T-11, T-13, T-14, T-17, T-19, T-27) have
incorrect `size_class` column values. The audit uses the computed size class from
`total_pages` in all cases.

## Additional tables (T-33 through T-43)

**T-33** has total_pages=500, which meets the >= 500 threshold for `large`. Its computed bloat ratio is 100/500 = 0.20, exactly at the large cap. A ratio equal to the cap is not over the cap, so the finding is `none`. The table is not stale (20 days since last analyzed).

**T-34** has total_pages=499, which is below the 500 threshold, so the computed size class is `small` (cap 0.40). Its computed bloat ratio is 200/499 = 0.4008, which rounds to 0.40. This equals the small cap, so the finding is `none`. The `size_class` column says `large`, which is incorrect.

**T-35** has maintenance_active=True but does not appear in reindex_log.csv at all. Without an approved reindex entry, the table is NOT exempt from the bloat check. Its bloat ratio of 0.25 exceeds the large cap of 0.20, so the finding is `BLOAT_THRESHOLD_EXCEEDED`.

**T-36** appears in reindex_log.csv with approved=True and valid_until=2026-09-15, but its maintenance_active field is False. The exemption requires maintenance_active=True AND approved=True AND valid_until >= audit_date. Since maintenance_active is False, the table is NOT exempt. Its bloat ratio of 0.25 exceeds the cap, so the finding is `BLOAT_THRESHOLD_EXCEEDED`.

**T-37** has maintenance_active=True, appears in reindex_log.csv with approved=True, and valid_until=2026-09-01, which equals the audit_date. Since valid_until >= audit_date (equal counts as valid), the table IS exempt from the bloat check. Its bloat ratio of 0.25 would exceed the cap, but the exemption applies, so the finding is `none`. The table is not stale (15 days).

**T-38** has stale statistics (36 days since last analyzed, which is more than 30). The stale-stats cap tightening reduces the large cap from 0.20 to 0.15. Its computed bloat ratio is 150/1000 = 0.15, which equals the tightened cap. A ratio equal to the cap is NOT over the cap, so the bloat check does not flag it. The finding is `STALE_STATISTICS` because the table is stale but not bloat-exceeded.

**T-39** has dead_pages=145 and total_pages=1000. The correct bloat ratio computed with round-half-up is 0.145 -> 0.15 (not 0.14 from round-half-even). The `bloat_ratio` field in the export says 0.14, which is incorrect. The `size_class` column says `medium`, but the computed size class from total_pages=1000 is `large` (cap 0.20). The ratio 0.15 is under the cap, so the finding is `none`.

**T-40** has dead_pages=125 and total_pages=1000. The correct bloat ratio computed with round-half-up is 0.125 -> 0.13 (not 0.12 from round-half-even). The `bloat_ratio` field says 0.12, which is incorrect. The `size_class` column says `medium`, but computed from total_pages=1000 it is `large`. The table is stale (36 days), so the cap is tightened to 0.15. The ratio 0.13 is under the tightened cap, so the finding is `STALE_STATISTICS`.

**T-41** has `size_class=medium` in the export, but total_pages=1000 means the computed size class is `large` (cap 0.20). Its bloat ratio of 0.25 exceeds the cap, so the finding is `BLOAT_THRESHOLD_EXCEEDED`. A size class not listed in the policy table (like `medium`) has no cap defined, but the computed size class (large) does, and the bloat check uses the computed class.

**T-42** has exactly 30 days since last_analyzed (2026-08-02 to 2026-09-01 = 30 days). The policy says "more than 30 days" is stale, so exactly 30 days is NOT stale. The `days_since_analyze` field says 31, which is incorrect. Since the table is not stale, the cap is not tightened (remains 0.20). The bloat ratio of 0.18 is under 0.20, so the finding is `none`.

**T-43** has 31 days since last_analyzed (2026-08-01 to 2026-09-01 = 31 days), which IS stale (more than 30). The `days_since_analyze` field says 30, which is incorrect. The stale-stats cap tightening reduces the large cap from 0.20 to 0.15. The bloat ratio of 0.18 exceeds the tightened cap of 0.15, so the finding is `BLOAT_THRESHOLD_EXCEEDED`.
## Partial reindex exemption tables (T-44 through T-48)

**T-44** has maintenance_active=True and appears in reindex_log.csv with approved=True and valid_until=2026-09-05. The valid_until date is 4 days after the audit_date (2026-09-01), which is within 7 days, so the exemption is **partial** â€” the bloat cap is doubled from 0.20 to 0.40. The computed bloat ratio is 250/1000 = 0.25, which is under the partial-exemption cap of 0.40, so the finding is `none`. Without the partial exemption, 0.25 would exceed the normal cap of 0.20.

**T-45** has the same partial exemption (valid_until=2026-09-07, 6 days after audit_date, within 7 days). The bloat cap is doubled to 0.40. However, its bloat ratio of 0.45 exceeds even the doubled cap, so the finding is `BLOAT_THRESHOLD_EXCEEDED`.

**T-46** has a full exemption (valid_until=2026-09-15, 14 days after audit_date, more than 7 days). The bloat check is skipped entirely. The bloat ratio of 0.25 would normally exceed the cap, but the full exemption means the finding is `none`.

**T-47** has a partial exemption (valid_until=2026-09-05, 4 days after audit_date) AND stale statistics (36 days since last analyzed). The stale-stats tightening first reduces the cap from 0.20 to 0.15, then the partial exemption doubles it to 0.30. The bloat ratio of 0.18 is under the partial-exemption tightened cap of 0.30, so the bloat check does not flag it. The finding is `STALE_STATISTICS` because the table is stale but not bloat-exceeded.

**T-48** has maintenance_active=True and appears in reindex_log.csv with approved=True, but valid_until=2026-08-30 is before the audit_date (2026-09-01). The reindex approval has expired, so there is no exemption. The bloat ratio of 0.25 exceeds the normal cap of 0.20, so the finding is `BLOAT_THRESHOLD_EXCEEDED`.

## Severe staleness and partial exemption traps (T-49 through T-56)

**T-49** has 48 days since last analyzed (46+ tier), so the cap is reduced by 0.10 to 0.10 (not 0.15). The bloat ratio of 0.12 exceeds the severely tightened cap of 0.10, so the finding is `BLOAT_THRESHOLD_EXCEEDED`.

**T-50** has the same severe staleness (48 days, 46+ tier, cap reduced to 0.10). The bloat ratio of 0.11 exceeds 0.10, so the finding is `BLOAT_THRESHOLD_EXCEEDED`.

**T-51** has maintenance_active=True but the reindex log entry has approved=False. Without an approved reindex, the table is NOT exempt. The bloat ratio of 0.25 exceeds the normal cap of 0.20, so the finding is `BLOAT_THRESHOLD_EXCEEDED`.

**T-52** has two entries in reindex_log.csv: the first with approved=True and valid_until=2026-09-15, and the second with approved=False and valid_until=2026-08-25. Using last-wins, the effective entry is approved=False, so the table is NOT exempt. The bloat ratio of 0.25 exceeds the cap, so the finding is `BLOAT_THRESHOLD_EXCEEDED`.

**T-53** is a small table (total_pages=400 < 500) with a partial reindex exemption. For small tables, the partial exemption reduces the cap by 0.05 instead of doubling. The table is also severely stale (48 days, 46+ tier, cap reduced by 0.10 to 0.30). The partial exemption further reduces by 0.05 to 0.25. The bloat ratio of 0.40 exceeds the partial-exemption tightened cap of 0.25, so the finding is `BLOAT_THRESHOLD_EXCEEDED`.

**T-54** has a partial exemption (valid_until=2026-09-05, 4 days after audit_date). The table is not stale (15 days). For a large table, the partial exemption doubles the cap from 0.20 to 0.40. The bloat ratio of 0.15 is under 0.40, so the finding is `none`.

**T-55** has a full exemption (valid_until=2026-09-15, 14 days after audit_date). The bloat check is skipped entirely. The finding is `none`.

**T-56** has a partial exemption (valid_until=2026-09-05, 4 days after audit_date) and is severely stale (48 days, 46+ tier). The cap is first tightened from 0.20 to 0.10 (severe staleness), then doubled for the partial exemption to 0.20. The bloat ratio of 0.10 is under 0.20 (at the original cap, but under the partial-exemption cap), so the bloat check does not flag it. The finding is `STALE_STATISTICS` because the table is stale but not bloat-exceeded.
