"""Structured validation for code-c227 table bloat maintenance audit.

Replaces regex-based verifier.json checks with proper CSV/JSON parsing:
- Validates exact CSV schema, unique rows, no extras
- Validates each table's finding, size_class, bloat_ratio fields
- Reconciles results.json counts with CSV content
- Checks memo for substantive explanations (not token stuffing)
- Core gate: missing deliverable = 0 reward
"""

import os
import sys
import json
import csv
import re
from pathlib import Path
from collections import Counter
import math

import pytest

WORKSPACE = Path(os.environ.get("HARBOR_TASK_WORKSPACE", "/app"))

# Expected gold answers (from policy + inputs)
def _round_half_up(n, decimals=2):
    multiplier = 10 ** decimals
    return math.floor(n * multiplier + 0.5) / multiplier

EXPECTED_TABLES = {
    "T-01": {"size_class": "large", "bloat_ratio": 0.1, "finding": "none"},
    "T-02": {"size_class": "large", "bloat_ratio": 0.35, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-03": {"size_class": "large", "bloat_ratio": 0.15, "finding": "AUTOVACUUM_DISABLED"},
    "T-04": {"size_class": "large", "bloat_ratio": 0.1, "finding": "STALE_STATISTICS"},
    "T-05": {"size_class": "large", "bloat_ratio": 0.55, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-06": {"size_class": "large", "bloat_ratio": 0.25, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-07": {"size_class": "large", "bloat_ratio": 0.12, "finding": "none"},
    "T-08": {"size_class": "large", "bloat_ratio": 0.45, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-09": {"size_class": "large", "bloat_ratio": 0.19, "finding": "none"},
    "T-10": {"size_class": "large", "bloat_ratio": 0.21, "finding": "STALE_STATISTICS"},
    "T-11": {"size_class": "large", "bloat_ratio": 0.41, "finding": "AUTOVACUUM_DISABLED"},
    "T-12": {"size_class": "large", "bloat_ratio": 0.2, "finding": "none"},
    "T-13": {"size_class": "large", "bloat_ratio": 0.5, "finding": "AUTOVACUUM_DISABLED"},
    "T-14": {"size_class": "large", "bloat_ratio": 0.4, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-15": {"size_class": "large", "bloat_ratio": 0.2, "finding": "none"},
    "T-16": {"size_class": "large", "bloat_ratio": 0.2, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-17": {"size_class": "large", "bloat_ratio": 0.4, "finding": "AUTOVACUUM_DISABLED"},
    "T-18": {"size_class": "large", "bloat_ratio": 0.21, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-19": {"size_class": "large", "bloat_ratio": 0.41, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-20": {"size_class": "large", "bloat_ratio": 0.1, "finding": "AUTOVACUUM_DISABLED"},
    "T-21": {"size_class": "large", "bloat_ratio": 0.2, "finding": "AUTOVACUUM_DISABLED"},
    "T-26": {"size_class": "large", "bloat_ratio": 0.18, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-27": {"size_class": "large", "bloat_ratio": 0.38, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-28": {"size_class": "large", "bloat_ratio": 0.25, "finding": "none"},
    "T-29": {"size_class": "large", "bloat_ratio": 0.25, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-30": {"size_class": "large", "bloat_ratio": 0.2, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-31": {"size_class": "small", "bloat_ratio": 0.3, "finding": "none"},
    "T-32": {"size_class": "small", "bloat_ratio": 0.4, "finding": "none"},
    "T-33": {"size_class": "large", "bloat_ratio": 0.2, "finding": "none"},
    "T-34": {"size_class": "small", "bloat_ratio": 0.4, "finding": "none"},
    "T-35": {"size_class": "large", "bloat_ratio": 0.25, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-36": {"size_class": "large", "bloat_ratio": 0.25, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-37": {"size_class": "large", "bloat_ratio": 0.25, "finding": "none"},
    "T-38": {"size_class": "large", "bloat_ratio": 0.15, "finding": "STALE_STATISTICS"},
    "T-39": {"size_class": "large", "bloat_ratio": 0.15, "finding": "none"},
    "T-40": {"size_class": "large", "bloat_ratio": 0.13, "finding": "STALE_STATISTICS"},
    "T-41": {"size_class": "large", "bloat_ratio": 0.25, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-42": {"size_class": "large", "bloat_ratio": 0.18, "finding": "none"},
    "T-43": {"size_class": "large", "bloat_ratio": 0.18, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-44": {"size_class": "large", "bloat_ratio": 0.25, "finding": "none"},
    "T-45": {"size_class": "large", "bloat_ratio": 0.45, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-46": {"size_class": "large", "bloat_ratio": 0.25, "finding": "none"},
    "T-47": {"size_class": "large", "bloat_ratio": 0.18, "finding": "STALE_STATISTICS"},
    "T-48": {"size_class": "large", "bloat_ratio": 0.25, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-49": {"size_class": "large", "bloat_ratio": 0.12, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-50": {"size_class": "large", "bloat_ratio": 0.11, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-51": {"size_class": "large", "bloat_ratio": 0.25, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-52": {"size_class": "large", "bloat_ratio": 0.25, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-53": {"size_class": "small", "bloat_ratio": 0.40, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-54": {"size_class": "large", "bloat_ratio": 0.15, "finding": "none"},
    "T-55": {"size_class": "large", "bloat_ratio": 0.25, "finding": "none"},
    "T-56": {"size_class": "large", "bloat_ratio": 0.10, "finding": "STALE_STATISTICS"},
}

EXPECTED_RESULTS = {
    "flagged_count": 35,
    "autovacuum_disabled_count": 6,
    "bloat_exceeded_count": 23,
    "stale_statistics_count": 6,
    "compliant_count": 17,
}

REQUIRED_HEADER = ["table_name", "size_class", "bloat_ratio", "finding"]
VALID_FINDINGS = {"AUTOVACUUM_DISABLED", "BLOAT_THRESHOLD_EXCEEDED", "STALE_STATISTICS", "none"}
SIZE_CLASS_CAPS = {"large": 0.2, "small": 0.4}


def _load_csv():
    """Load and parse bloat_audit.csv with full validation."""
    path = WORKSPACE / "bloat_audit.csv"
    if not path.is_file():
        return None, "bloat_audit.csv not found"
    try:
        with open(path, encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            if reader.fieldnames != REQUIRED_HEADER:
                return None, f"Header mismatch: got {reader.fieldnames}, expected {REQUIRED_HEADER}"
            rows = list(reader)
            return rows, None
    except Exception as e:
        return None, f"CSV parse error: {e}"


def _load_json():
    """Load results.json."""
    path = WORKSPACE / "results.json"
    if not path.is_file():
        return None, "results.json not found"
    try:
        return json.loads(path.read_text(encoding="utf-8")), None
    except Exception as e:
        return None, f"JSON parse error: {e}"


def _load_memo():
    """Load bloat_memo.md."""
    path = WORKSPACE / "bloat_memo.md"
    if not path.is_file():
        return None, "bloat_memo.md not found"
    return path.read_text(encoding="utf-8"), None


def _parse_ratio(val):
    """Parse a bloat ratio string to float, accepting 0.2 = 0.20 = 0.200."""
    try:
        return float(str(val).strip())
    except (ValueError, TypeError):
        return None


# ============ CORE GATE TESTS (must pass for any reward) ============

def test_audit_exists():
    """bloat_audit.csv must exist."""
    rows, err = _load_csv()
    assert rows is not None, f"Core gate: {err}"


def test_memo_exists():
    """bloat_memo.md must exist."""
    memo, err = _load_memo()
    assert memo is not None, f"Core gate: {err}"


def test_results_exists():
    """results.json must exist."""
    data, err = _load_json()
    assert data is not None, f"Core gate: {err}"


def test_audit_header():
    """CSV must have exactly the required header."""
    rows, err = _load_csv()
    assert err is None, err
    # Header already validated in _load_csv via DictReader fieldnames check
    assert len(rows) > 0, "CSV has no data rows"


def test_audit_exact_row_count():
    """CSV must have exactly 52 data rows (no extra, no missing)."""
    rows, err = _load_csv()
    assert err is None, err
    assert len(rows) == 52, f"Expected 52 rows, got {len(rows)}"


def test_audit_no_duplicates():
    """Each table_name must appear exactly once."""
    rows, err = _load_csv()
    assert err is None, err
    names = [r.get("table_name", "").strip() for r in rows]
    counts = Counter(names)
    dupes = {k: v for k, v in counts.items() if v > 1}
    assert not dupes, f"Duplicate table_name entries: {dupes}"


def test_audit_all_tables_present():
    """All expected tables must be present."""
    rows, err = _load_csv()
    assert err is None, err
    actual = {r.get("table_name", "").strip() for r in rows}
    expected = set(EXPECTED_TABLES.keys())
    missing = expected - actual
    extra = actual - expected
    assert not missing, f"Missing tables: {missing}"
    assert not extra, f"Unexpected extra tables: {extra}"


def test_audit_valid_findings():
    """All findings must be valid finding codes."""
    rows, err = _load_csv()
    assert err is None, err
    for row in rows:
        finding = row.get("finding", "").strip()
        assert finding in VALID_FINDINGS, f"Invalid finding '{finding}' for {row.get('table_name')}"


# ============ PER-TABLE VALIDATION (field-level) ============

@pytest.mark.parametrize("table_id", sorted(EXPECTED_TABLES.keys()))
def test_table_finding(table_id):
    """Each table's finding must match the expected gold answer."""
    rows, err = _load_csv()
    assert err is None, err
    row = next((r for r in rows if r.get("table_name", "").strip() == table_id), None)
    assert row is not None, f"Table {table_id} not found in audit"
    expected = EXPECTED_TABLES[table_id]["finding"]
    actual = row.get("finding", "").strip()
    assert actual == expected, f"{table_id}: expected {expected}, got {actual}"


@pytest.mark.parametrize("table_id", sorted(EXPECTED_TABLES.keys()))
def test_table_size_class(table_id):
    """Each table's size_class must match the input data."""
    rows, err = _load_csv()
    assert err is None, err
    row = next((r for r in rows if r.get("table_name", "").strip() == table_id), None)
    assert row is not None, f"Table {table_id} not found"
    expected = EXPECTED_TABLES[table_id]["size_class"]
    actual = row.get("size_class", "").strip().lower()
    assert actual == expected, f"{table_id}: expected size_class={expected}, got {actual}"


@pytest.mark.parametrize("table_id", sorted(EXPECTED_TABLES.keys()))
def test_table_bloat_ratio(table_id):
    """Each table's bloat_ratio must match the input data (numeric equivalence)."""
    rows, err = _load_csv()
    assert err is None, err
    row = next((r for r in rows if r.get("table_name", "").strip() == table_id), None)
    assert row is not None, f"Table {table_id} not found"
    expected = EXPECTED_TABLES[table_id]["bloat_ratio"]
    actual = _parse_ratio(row.get("bloat_ratio"))
    assert actual is not None, f"{table_id}: cannot parse bloat_ratio '{row.get('bloat_ratio')}'"
    assert abs(actual - expected) < 1e-9, f"{table_id}: expected bloat_ratio={expected}, got {actual}"


# ============ RESULTS.JSON RECONCILIATION ============

def test_results_txn_count():
    """results.json txn_count is not required by instruction — skip."""
    # instruction doesn't mention txn_count, only the 5 count fields
    pass


def test_results_flagged_count():
    """results.json flagged_count must equal count of non-none findings in CSV."""
    rows, err = _load_csv()
    assert err is None, err
    data, jerr = _load_json()
    assert jerr is None, jerr
    csv_count = sum(1 for r in rows if r.get("finding", "").strip() != "none")
    json_count = data.get("flagged_count")
    assert json_count == csv_count, f"results.json flagged_count={json_count} != CSV count={csv_count}"


def test_results_autovacuum_count():
    """results.json autovacuum_disabled_count must match CSV."""
    rows, err = _load_csv()
    assert err is None, err
    data, jerr = _load_json()
    assert jerr is None, jerr
    csv_count = sum(1 for r in rows if r.get("finding", "").strip() == "AUTOVACUUM_DISABLED")
    json_count = data.get("autovacuum_disabled_count")
    assert json_count == csv_count, f"autovacuum_disabled_count: json={json_count} != csv={csv_count}"


def test_results_bloat_count():
    """results.json bloat_exceeded_count must match CSV."""
    rows, err = _load_csv()
    assert err is None, err
    data, jerr = _load_json()
    assert jerr is None, jerr
    csv_count = sum(1 for r in rows if r.get("finding", "").strip() == "BLOAT_THRESHOLD_EXCEEDED")
    json_count = data.get("bloat_exceeded_count")
    assert json_count == csv_count, f"bloat_exceeded_count: json={json_count} != csv={csv_count}"


def test_results_stale_count():
    """results.json stale_statistics_count must match CSV."""
    rows, err = _load_csv()
    assert err is None, err
    data, jerr = _load_json()
    assert jerr is None, jerr
    csv_count = sum(1 for r in rows if r.get("finding", "").strip() == "STALE_STATISTICS")
    json_count = data.get("stale_statistics_count")
    assert json_count == csv_count, f"stale_statistics_count: json={json_count} != csv={csv_count}"


def test_results_compliant_count():
    """results.json compliant_count must match CSV."""
    rows, err = _load_csv()
    assert err is None, err
    data, jerr = _load_json()
    assert jerr is None, jerr
    csv_count = sum(1 for r in rows if r.get("finding", "").strip() == "none")
    json_count = data.get("compliant_count")
    assert json_count == csv_count, f"compliant_count: json={json_count} != csv={csv_count}"


def test_results_count_sum():
    """All counts must sum correctly: flagged + compliant = total rows."""
    rows, err = _load_csv()
    assert err is None, err
    data, jerr = _load_json()
    assert jerr is None, jerr
    total = len(rows)
    flagged = data.get("flagged_count", 0)
    compliant = data.get("compliant_count", 0)
    assert flagged + compliant == total, f"flagged({flagged}) + compliant({compliant}) != total({total})"


# ============ MEMO SUBSTANTIVE CHECKS ============

def _memo_mentions(table_id, *concepts):
    """Check if memo discusses a table with at least one of the concepts nearby (within 200 chars, either direction)."""
    memo, err = _load_memo()
    if err:
        return False
    # Search for table_id near concepts (either direction)
    concepts_alt = '|'.join(re.escape(c) for c in concepts)
    pattern = rf"(?is)(?:{re.escape(table_id)}.{{0,200}}?(?:{concepts_alt})|(?:{concepts_alt}).{{0,200}}?{re.escape(table_id)})"
    return bool(re.search(pattern, memo))


def test_memo_explains_t02():
    """Memo must explain T-02 bloat exceeded."""
    assert _memo_mentions("T-02", "bloat", "exceed", "over", "cap", "0.35", "large", "threshold"), "Memo must explain T-02 bloat exceeded"


def test_memo_explains_t03():
    """Memo must explain T-03 autovacuum disabled."""
    assert _memo_mentions("T-03", "autovacuum", "disabled", "first", "override", "AUTOVACUUM_DISABLED"), "Memo must explain T-03 autovacuum disabled"


def test_memo_explains_t04():
    """Memo must explain T-04 stale statistics."""
    assert _memo_mentions("T-04", "stale", "statistics", "45", "days", "30", "STALE_STATISTICS", "refresh", "outdated"), "Memo must explain T-04 stale statistics"


def test_memo_explains_t05():
    """Memo must explain T-05 maintenance exemption."""
    assert _memo_mentions("T-05", "reindex", "maintenance", "exempt", "active", "none"), "Memo must explain T-05 maintenance exemption"


def test_memo_explains_t08():
    """Memo must explain T-08 bloat exceeded (small table)."""
    assert _memo_mentions("T-08", "bloat", "exceed", "over", "cap", "0.45", "small", "threshold"), "Memo must explain T-08 bloat exceeded"


def test_memo_explains_t10():
    """Memo must explain T-10 stale statistics (reindex doesn't exempt stats)."""
    assert _memo_mentions("T-10", "stale", "statistics", "31", "days", "30", "reindex", "exempt", "STALE_STATISTICS"), "Memo must explain T-10 stale statistics"


def test_memo_explains_t11():
    """Memo must explain T-11 autovacuum overrides bloat."""
    assert _memo_mentions("T-11", "autovacuum", "disabled", "first", "override", "priority", "AUTOVACUUM_DISABLED", "bloat", "cap"), "Memo must explain T-11 autovacuum overrides bloat"


def test_memo_explains_t12():
    """Memo must explain T-12 boundary equality (0.20 = cap, not over)."""
    assert _memo_mentions("T-12", "equal", "cap", "0.20", "0.2", "not over", "boundary", "at the cap", "threshold", "none", "compliant"), "Memo must explain T-12 boundary equality"


def test_memo_explains_t13():
    """Memo must explain T-13 triple collision (autovacuum overrides bloat + stale)."""
    assert _memo_mentions("T-13", "autovacuum", "disabled", "first", "override", "priority", "AUTOVACUUM_DISABLED", "bloat", "stale"), "Memo must explain T-13 triple collision"


def test_memo_explains_t14():
    """Memo must explain T-14 boundary equality (0.40 = small cap)."""
    assert _memo_mentions("T-14", "equal", "cap", "0.40", "0.4", "not over", "boundary", "small", "threshold", "none", "compliant"), "Memo must explain T-14 boundary equality"


def test_memo_explains_t15():
    """Memo must explain T-15 numeric equivalence (0.200 = 0.2)."""
    assert _memo_mentions("T-15", "0.200", "0.2", "equal", "same", "numeric", "large", "cap", "none", "compliant"), "Memo must explain T-15 numeric equivalence"



def test_memo_explains_t18():
    """Memo must explain T-18: round-half-up makes 0.205 -> 0.21 (over large cap)."""
    assert _memo_mentions("T-18", "bloat", "exceed", "over", "cap", "0.21", "large", "round", "0.205", "threshold"), "Memo must explain T-18 rounding"

def test_memo_explains_t19():
    """Memo must explain T-19: round-half-up makes 0.405 -> 0.41 (over small cap)."""
    assert _memo_mentions("T-19", "bloat", "exceed", "over", "cap", "0.41", "small", "round", "0.405", "threshold"), "Memo must explain T-19 rounding"


def test_memo_explains_t20():
    """Memo must explain T-20: manual vacuum overrides autovacuum_enabled=True."""
    assert _memo_mentions("T-20", "manual", "vacuum", "override", "autovacuum", "disabled", "AUTOVACUUM_DISABLED"), "Memo must explain T-20 manual vacuum override"

def test_memo_explains_t21():
    """Memo must explain T-21: manual vacuum overrides everything (boundary + stale + autovacuum)."""
    assert _memo_mentions("T-21", "manual", "vacuum", "override", "autovacuum", "disabled", "AUTOVACUUM_DISABLED"), "Memo must explain T-21 manual vacuum override"







def test_memo_explains_t26():
    """Memo must explain T-26: stale stats tighten cap -> BLOAT not STALE."""
    assert _memo_mentions("T-26", "stale", "tighten", "cap", "0.15", "0.18", "bloat", "BLOAT_THRESHOLD_EXCEEDED"), "Memo must explain T-26"

def test_memo_explains_t27():
    """Memo must explain T-27: stale stats tighten cap -> BLOAT not STALE."""
    assert _memo_mentions("T-27", "stale", "tighten", "cap", "0.35", "0.38", "bloat", "BLOAT_THRESHOLD_EXCEEDED"), "Memo must explain T-27"


def test_memo_explains_t28():
    """Memo must explain T-28: approved reindex with valid date -> exempt."""
    assert _memo_mentions("T-28", "reindex", "approved", "valid", "exempt", "none"), "Memo must explain T-28"

def test_memo_explains_t29():
    """Memo must explain T-29: approved reindex but EXPIRED -> NOT exempt -> BLOAT."""
    assert _memo_mentions("T-29", "reindex", "expired", "valid_until", "bloat", "BLOAT_THRESHOLD_EXCEEDED"), "Memo must explain T-29"


def test_memo_explains_t30():
    """Memo must explain T-30: at original cap but stale tightens cap -> BLOAT not none."""
    assert _memo_mentions("T-30", "stale", "tighten", "cap", "0.15", "0.20", "0.2", "bloat", "BLOAT_THRESHOLD_EXCEEDED", "effective"), "Memo must explain T-30"


def test_memo_explains_t31():
    """Memo must explain T-31: total_pages=400 -> small (not large from column)."""
    assert _memo_mentions("T-31", "total", "400", "small", "cap", "0.4", "none", "compliant"), "Memo must explain T-31"

def test_memo_explains_t32():
    """Memo must explain T-32: total_pages=400 -> small, at cap 0.4 -> none."""
    assert _memo_mentions("T-32", "total", "400", "small", "cap", "0.4", "none", "compliant"), "Memo must explain T-32"


def test_audit_date_sorted_order():
    """CSV rows must be sorted by last_analyzed date (ascending), then table_name."""
    import csv as csv_mod
    from datetime import datetime as dt
    path = WORKSPACE / "bloat_audit.csv"
    assert path.is_file(), "bloat_audit.csv not found"
    with open(path, encoding="utf-8", newline="") as f:
        rows = list(csv_mod.DictReader(f))

    # Read table_health.csv to get last_analyzed dates
    health_path = WORKSPACE / "input" / "table_health.csv"
    assert health_path.is_file(), "table_health.csv not found"
    last_analyzed_map = {}
    with open(health_path, encoding="utf-8", newline="") as f:
        for row in csv_mod.DictReader(f):
            last_analyzed_map[row["table_name"]] = row["last_analyzed"]

    # Check that audit rows are in date-sorted order
    prev_key = None
    for row in rows:
        tid = row.get("table_name", "").strip()
        la = last_analyzed_map.get(tid, "9999-12-31")
        key = (la, tid)
        if prev_key is not None:
            assert key >= prev_key, f"Row {tid} (last_analyzed={la}) is out of order: prev={prev_key}, current={key}"
        prev_key = key

def test_memo_discusses_maintenance():
    """Memo must discuss reindex/maintenance exemption."""
    memo, err = _load_memo()
    assert err is None, err
    assert re.search(r"(?i)re-?index|maintenance|exempt", memo), "Memo must discuss reindex/maintenance exemption"



def test_memo_explains_t16():
    """Memo must explain T-16: boundary + reindex + stale -> STALE_STATISTICS."""
    assert _memo_mentions("T-16", "stale", "statistics", "31", "days", "30", "reindex", "exempt", "boundary", "0.20", "cap", "STALE_STATISTICS"), "Memo must explain T-16"

def test_memo_explains_t17():
    """Memo must explain T-17: boundary + autovacuum disabled -> AUTOVACUUM_DISABLED."""
    assert _memo_mentions("T-17", "autovacuum", "disabled", "first", "override", "priority", "AUTOVACUUM_DISABLED", "boundary", "0.40", "cap"), "Memo must explain T-17"


def test_memo_size_trap_t06():
    """Memo must explain T-06 size_class column is wrong, computed as large."""
    assert _memo_mentions("T-06", "size", "class", "large", "small", "total", "compute", "column", "wrong", "incorrect"), "Memo must explain T-06 size_class trap"

def test_memo_size_trap_t14():
    """Memo must explain T-14 size_class column says small but computed as large -> BLOAT."""
    assert _memo_mentions("T-14", "size", "class", "large", "small", "total", "compute", "column", "wrong", "BLOAT"), "Memo must explain T-14 size_class trap"

def test_memo_size_trap_t27():
    """Memo must explain T-27 size_class column says small but computed as large -> BLOAT."""
    assert _memo_mentions("T-27", "size", "class", "large", "small", "total", "compute", "column", "wrong", "BLOAT"), "Memo must explain T-27 size_class trap"

def test_memo_size_trap_t31():
    """Memo must explain T-31 size_class column says large but total_pages < 500 -> small."""
    assert _memo_mentions("T-31", "total", "400", "small", "large", "column", "compute", "wrong"), "Memo must explain T-31 size_class trap"

def test_memo_size_trap_t32():
    """Memo must explain T-32 size_class column says large but total_pages < 500 -> small."""
    assert _memo_mentions("T-32", "total", "400", "small", "large", "column", "compute", "wrong"), "Memo must explain T-32 size_class trap"

def test_memo_reindex_expiry_t16():
    """Memo must explain T-16 reindex expired -> BLOAT not exempt."""
    assert _memo_mentions("T-16", "reindex", "expired", "valid_until", "bloat", "BLOAT"), "Memo must explain T-16 reindex expiry"

def test_memo_unapproved_t05():
    """Memo must explain T-05 unapproved reindex -> BLOAT."""
    assert _memo_mentions("T-05", "unapproved", "not approved", "approved", "False", "bloat", "BLOAT", "reindex"), "Memo must explain T-05 unapproved reindex"


def test_memo_discusses_size_class():
    """Memo must discuss size class caps."""
    memo, err = _load_memo()
    assert err is None, err
    assert re.search(r"(?i)size[\s-]?class|large|small|cap|0\.[24]", memo), "Memo must discuss size class caps"