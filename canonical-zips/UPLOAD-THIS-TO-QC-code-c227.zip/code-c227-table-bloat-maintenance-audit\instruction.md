# Task

Run our monthly table maintenance review on this table export. For each table, check whether autovacuum is enabled first, then whether its bloat ratio is within its own size class's cap — noting that a table under an approved active reindex operation is exempt from the bloat check — and finally whether its statistics are stale. The bloat ratio must be computed as `dead_pages / total_pages` (round-half-up to 2 decimal places) from the input export — it is not read directly. Save `bloat_audit.csv` with exactly the columns `table_name,size_class,bloat_ratio,finding` in that order, one row per table, and a `finding` column (`AUTOVACUUM_DISABLED`, `BLOAT_THRESHOLD_EXCEEDED`, `STALE_STATISTICS`, or `none`). Then write `bloat_memo.md` explaining each finding, including the table under active maintenance, and explaining why any table whose bloat ratio exactly equals its size-class cap is compliant.

---
Save your deliverables into your current working directory using exactly these filenames:
    - `bloat_audit.csv` — Per-table maintenance audit
    - `bloat_memo.md` — Markdown table maintenance memo
    - `results.json` — a JSON object with the keys `flagged_count` (number of rows whose finding is not `none`), `autovacuum_disabled_count` (number of rows with `AUTOVACUUM_DISABLED`), `bloat_exceeded_count` (number of rows with `BLOAT_THRESHOLD_EXCEEDED`), `stale_statistics_count` (number of rows with `STALE_STATISTICS`), `compliant_count` (number of rows with `none`)
- Writing those files is the required deliverable and must be your final action; confirm each one exists before you answer.

---

## Working environment

- Your current working directory is `/app`, and it is writable.
- The read-only attachments referred to as `input/` are at `/app/input`.
- Write every deliverable into `/app`, at the exact filenames listed above.
