# code-c227-table-bloat-maintenance-audit

## What the task is

A monthly table maintenance review audit. The agent receives a table health export
(`table_health.csv`), a reindex log (`reindex_log.csv`), and a maintenance policy
(`maintenance_policy.md`). For each table, the agent must:

1. Check autovacuum status (including manual vacuum override)
2. Compute the bloat ratio from `dead_pages / total_pages` using round-half-up
3. Determine size class from `total_pages` (not the legacy `size_class` column)
4. Apply the bloat cap for the computed size class (with stale-stats tightening)
5. Check for approved active reindex exemptions (full, partial, or expired)
6. Check statistics staleness from date fields (not the legacy `days_since_analyze`)
7. Apply finding priority: AUTOVACUUM_DISABLED > BLOAT_THRESHOLD_EXCEEDED > STALE_STATISTICS > none
8. Sort output by `last_analyzed` ascending, then `table_name` alphabetical

The agent delivers three files:
- `bloat_audit.csv` — one row per table with computed size_class, bloat_ratio, and finding
- `bloat_memo.md` — explanation of each finding
- `results.json` — summary counts

## Why it is non-trivial

The task contains multiple traps:
- **Round-half-up vs round-half-even**: The `bloat_ratio` field uses Python's default
  rounding (round-half-even); the policy requires round-half-up
- **Size class from total_pages**: The `size_class` column is a legacy field that may
  not match the computed class from `total_pages`
- **Stale-stats cap tightening**: Stale statistics reduce the bloat cap by 0.05
- **Partial reindex exemption**: A reindex within 7 days of audit_date doubles the cap
  instead of skipping the bloat check
- **Expired reindex**: A reindex with valid_until < audit_date provides no exemption
- **Manual vacuum override**: `vacuum_type=manual` means autovacuum is disabled
- **Exact boundary**: A ratio equal to the cap is NOT over the cap
- **30-day boundary**: Exactly 30 days is NOT stale; 31 days IS stale
- **Last-wins deduplication**: Duplicate table_name entries use last row wins

## What the bundle contains

- 44 unique tables (28 original + 16 new with subtle traps)
- 93 deterministic verifier checks (per-table findings, memo explanations, results counts)
- Gold solution with computed audit CSV, memo, and results.json
- 5 GLM-5.2 difficulty trials, 1 oracle, 3 stability repeats
