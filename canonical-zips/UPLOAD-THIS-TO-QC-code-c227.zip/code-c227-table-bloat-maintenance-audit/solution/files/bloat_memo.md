# Table maintenance audit — 28 tables

30 tables checked against DBOPS-31. 8 are compliant and 20 carry a
finding.

| Table | Size class | Bloat ratio | Finding |
|---|---|---|---|
| T-13 | large | 0.5 | AUTOVACUUM_DISABLED |
| T-17 | large | 0.4 | AUTOVACUUM_DISABLED |
| T-27 | large | 0.38 | BLOAT_THRESHOLD_EXCEEDED |
| T-04 | large | 0.1 | STALE_STATISTICS |
| T-21 | large | 0.2 | AUTOVACUUM_DISABLED |
| T-26 | large | 0.18 | BLOAT_THRESHOLD_EXCEEDED |
| T-30 | large | 0.2 | BLOAT_THRESHOLD_EXCEEDED |
| T-10 | large | 0.21 | STALE_STATISTICS |
| T-16 | large | 0.2 | BLOAT_THRESHOLD_EXCEEDED |
| T-09 | large | 0.19 | none |
| T-07 | large | 0.12 | none |
| T-15 | large | 0.2 | none |
| T-12 | large | 0.2 | none |
| T-19 | large | 0.41 | BLOAT_THRESHOLD_EXCEEDED |
| T-01 | large | 0.1 | none |
| T-06 | large | 0.25 | BLOAT_THRESHOLD_EXCEEDED |
| T-14 | large | 0.4 | BLOAT_THRESHOLD_EXCEEDED |
| T-18 | large | 0.21 | BLOAT_THRESHOLD_EXCEEDED |
| T-20 | large | 0.1 | AUTOVACUUM_DISABLED |
| T-28 | large | 0.25 | none |
| T-29 | large | 0.25 | BLOAT_THRESHOLD_EXCEEDED |
| T-31 | small | 0.3 | none |
| T-31 | small | 0.3 | none |
| T-32 | small | 0.4 | none |
| T-32 | small | 0.4 | none |
| T-08 | large | 0.45 | BLOAT_THRESHOLD_EXCEEDED |
| T-02 | large | 0.35 | BLOAT_THRESHOLD_EXCEEDED |
| T-03 | large | 0.15 | AUTOVACUUM_DISABLED |
| T-05 | large | 0.55 | BLOAT_THRESHOLD_EXCEEDED |
| T-11 | large | 0.41 | AUTOVACUUM_DISABLED |


## T-05 is a bloat finding (unapproved reindex)

T-05's bloat ratio of 0.55 is far over the large-table cap of 0.2. Although
maintenance_active=True, the reindex is NOT approved — reindex_approvals.csv has
approved=False for T-05. The exemption only applies when both maintenance_active=True
AND approved=True in reindex_approvals.csv. Since the reindex is unapproved, the
bloat check applies normally. Finding: BLOAT_THRESHOLD_EXCEEDED.

## Other findings

T-02's bloat ratio of 0.35 is over the large-table cap with no maintenance flag:
`BLOAT_THRESHOLD_EXCEEDED`. T-03 has autovacuum disabled: `AUTOVACUUM_DISABLED`, checked
before its bloat ratio is even considered. T-04's statistics are 45 days stale, over the
30-day limit: `STALE_STATISTICS`. T-08 is judged against the small size class
cap rather than the large one, and its bloat ratio of 0.45 is over that cap:
`BLOAT_THRESHOLD_EXCEEDED`.


## Tables T-09 through T-11

- **T-09**: A large table with bloat ratio 0.19 (under the 0.20 cap) and statistics last refreshed 30 days ago. The policy says "more than 30 days ago" — 30 is not more than 30. Finding: none.
- **T-10**: A large table with bloat ratio 0.21 (over the 0.20 cap), under an active reindex operation, with statistics 31 days old. The reindex exemption applies only to the bloat check — not to statistics staleness. Finding: STALE_STATISTICS.
- **T-11**: A small table with bloat ratio 0.41 (over the 0.40 cap) and autovacuum disabled. Autovacuum is checked first and overrides every other check. Finding: AUTOVACUUM_DISABLED.

## Boundary equality

- **T-12**: A large table with bloat ratio exactly 0.20 — equal to the large-table cap.
  The policy says a table *over* its cap is BLOAT_THRESHOLD_EXCEEDED; 0.20 is not over 0.20,
  it is exactly at the cap. The table is within its allowance. Finding: none.
- **T-14**: A small table with bloat ratio exactly 0.40 — equal to the small-table cap.
  0.40 is not over 0.40. Finding: none.
- **T-15**: A large table with bloat ratio 0.200 — numerically equal to the large-table
  cap of 0.2. 0.200 is not over 0.2; it is the same value. Finding: none.

## Multi-rule interaction cases

- **T-16**: A large table with bloat ratio 0.20 (at the large cap, not over it — so bloat is
  not exceeded), under active reindex (which would exempt bloat, but bloat is already not
  exceeded so the exemption is irrelevant), with statistics 31 days stale. The reindex
  exemption applies only to the bloat check, not to statistics staleness. Finding:
  STALE_STATISTICS.
- **T-17**: A small table with bloat ratio 0.40 (at the small cap, not over it), autovacuum
  disabled, and statistics 50 days stale. Autovacuum is checked first and overrides every
  other check. Finding: AUTOVACUUM_DISABLED.

## Round-half-up traps

- **T-18**: A large table with 205 dead pages out of 1000 total. The raw ratio is 0.205,
  which rounds to 0.21 under round-half-up (the policy's rounding mode). 0.21 is over the
  large-table cap of 0.2. Python's default round() uses round-half-even and would produce
  0.20 (at the cap, not over) — this is incorrect. Finding: BLOAT_THRESHOLD_EXCEEDED.
- **T-19**: A small table with 405 dead pages out of 1000 total. The raw ratio is 0.405,
  which rounds to 0.41 under round-half-up. 0.41 is over the small-table cap of 0.4.
  Python's default round() would produce 0.40 (at the cap) — this is incorrect.
  Finding: BLOAT_THRESHOLD_EXCEEDED.

## Manual vacuum override

- **T-20**: A large table with autovacuum_enabled=True, but vacuum_type=manual. A manual
  vacuum overrides and supersedes the automatic schedule — the table no longer has
  automatic autovacuum protection. Despite autovacuum_enabled being True, the finding is
  AUTOVACUUM_DISABLED.
- **T-21**: A large table with autovacuum_enabled=True and vacuum_type=manual, bloat
  ratio 0.20 (at the large cap, not over), and statistics 45 days stale. The manual vacuum
  override means autovacuum is considered disabled, which is checked first and overrides
  every other check. Finding: AUTOVACUUM_DISABLED.

## Stale-stats cap tightening

- **T-26**: A large table with bloat ratio 0.18 (under the normal 0.20 cap) and statistics
  35 days stale. When stats are stale, the bloat cap is tightened by 0.05: 0.20 - 0.05 =
  0.15. The ratio 0.18 is over the tightened cap 0.15. Because bloat is checked before
  staleness in the finding precedence, the finding is BLOAT_THRESHOLD_EXCEEDED (not
  STALE_STATISTICS).
- **T-27**: A small table with bloat ratio 0.38 (under the normal 0.40 cap) and statistics
  45 days stale. Tightened cap: 0.40 - 0.05 = 0.35. The ratio 0.38 is over 0.35.
  Finding: BLOAT_THRESHOLD_EXCEEDED.

## Legacy days_since_analyze field

The `days_since_analyze` field in the export is a legacy estimate and is NOT reliable.
Staleness must be computed from the `audit_date` and `last_analyzed` date fields. Several
tables have `days_since_analyze` values that differ from the actual date-based computation
by 5 days. Using the legacy field instead of computing from dates will produce incorrect
findings for those tables.

## Reindex approval expiry

- **T-28**: A large table with bloat ratio 0.25 (over the 0.20 cap), maintenance_active=True,
  and reindex_log shows approved=True with valid_until=2026-09-15. Since valid_until
  (2026-09-15) is after audit_date (2026-09-01), the approval is valid and the table is
  exempt from the bloat check. Finding: none.
- **T-29**: A large table with the same bloat ratio 0.25 and maintenance_active=True, and
  reindex_log shows approved=True, BUT valid_until=2026-08-25. Since valid_until
  (2026-08-25) is BEFORE audit_date (2026-09-01), the approval has expired. The table is
  NOT exempt — the bloat check applies normally. Finding: BLOAT_THRESHOLD_EXCEEDED.

## At-cap with stale stats

- **T-30**: A large table with bloat ratio 0.20 — exactly equal to the original large-table
  cap of 0.2. However, statistics are 36 days stale (more than 30), so the stale-stats cap
  tightening rule reduces the effective cap to 0.15. The ratio 0.20 is over the effective
  cap 0.15. The "at-cap = compliant" rule applies to the effective cap, not the original
  cap — a table whose ratio equals the original cap but exceeds the effective (tightened)
  cap is BLOAT_THRESHOLD_EXCEEDED. Finding: BLOAT_THRESHOLD_EXCEEDED.

## bloat_ratio field is unreliable

The `bloat_ratio` field in the export is computed with Python's default rounding
(round-half-even) and gives incorrect results for rounding-boundary cases. The correct
ratio must be computed from `dead_pages / total_pages` using round-half-up. For example,
T-18 has 205 dead pages out of 1000 total: the correct ratio is 0.21 (round-half-up),
but the `bloat_ratio` field shows 0.2 (Python's round-half-even).

## Computed size class

The `size_class` column in the export is a legacy field and is NOT reliable. Size class
must be computed from `total_pages`: >= 500 is large (cap 0.2), < 500 is small (cap 0.4).

- **T-31**: total_pages=400 (< 500), so computed size class is small (cap 0.4). The
  `size_class` column says "large" (WRONG). Bloat ratio 0.30 is under the small cap 0.4.
  Finding: none. If the column's "large" were used (cap 0.2), 0.30 > 0.2 would give
  BLOAT_THRESHOLD_EXCEEDED (incorrect).
- **T-32**: total_pages=400 (< 500), computed size class is small (cap 0.4). The column
  says "large" (WRONG). Bloat ratio 0.40 equals the small cap 0.4 — at the cap, not over.
  Finding: none. If "large" were used (cap 0.2), 0.40 > 0.2 would give BLOAT (incorrect).

Several other tables (T-03, T-04, T-06, T-08, T-11, T-13, T-14, T-17, T-19, T-27) have
incorrect `size_class` column values. The audit uses the computed size class from
`total_pages` in all cases.
