# Cash pool interest allocation

The notional pool statement for the month is in. Allocate interest across the
participants and compute the benefit the header company keeps. The pool
agreement is authoritative on who is in the pool, the two rates, the day count
basis, how a sign-changing participant is priced, which leg withholding tax
attaches to, and how the pool benefit is derived.

## Deliverables

1. `pool_allocation.csv` — participant-level interest allocation
2. `cash_pool_memo.md` — memo on the allocation decisions
3. `results.json` — derived totals

## Inputs

- `input/pool_agreement.md` — binding pool agreement
- `input/participants.csv` — participant register
- `input/balances.csv` — daily balance segments

## Working environment

- Working directory is `/app` (writable).
- Read-only inputs are at `/app/input`.
- Write deliverables to `/app` using the exact filenames above.