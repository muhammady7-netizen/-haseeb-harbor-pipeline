# Notional cash pool — interest allocation agreement

Amounts are in **euro**. The period is June 20X5, which has 30 days. The header
company operates the pool; the companies listed in `participants.csv` participate in it.

## 1. Who is in the pool

A company participates in the pool only **from its accession date**. A company whose
accession date falls **after the end of the period** is **not a participant for that
period**: its balances are reported to the treasury team on the same schedule for
information, they are **not** part of the pooled position, and **no interest is allocated to
it**.

A company whose accession date falls **within the period** participates only from that
date forward: balances before its accession are excluded from the pool, from the pooled
position, and from any interest allocation.

## 2. Rates and day count

- **Credit rate: 1.80% per annum**, applied to a **positive** balance.
- **Debit rate: 4.20% per annum**, applied to a **negative** balance.

Interest is computed on an **actual/360** basis: the balance for a day,
multiplied by the annual rate, divided by 360.

A balance of **zero** on a given day accrues **neither credit interest nor debit
interest** — zero is neither a positive balance nor a negative balance.

## 3. How the allocation is computed

Interest is computed **for each day of the period on that day's balance**, and the daily
amounts are summed. `balances.csv` gives each participant's balance as a set of segments;
a segment from day *a* to day *b* inclusive covers *b − a + 1* days.

The **sign of the balance on each individual day** decides which rate applies. A participant
whose balance crosses from credit to debit part-way through the period earns credit interest
on the days it was in credit and is charged debit interest on the days it was overdrawn.
A participant whose balance changes sign **more than once** is priced on each leg
separately: credit interest on every day the balance is positive, debit interest on
every day it is negative.

It is **not** correct to average the participant's balance over the whole period and price
the average at a single rate, and it is **not** correct to price the closing balance for the
whole period.

Report each participant's **average balance** as its total balance-days divided by
30, for information.

## 4. Withholding tax

Withholding tax at the rate in `participants.csv` is deducted from interest **credited to**
a participant. **No withholding arises on interest charged to a participant** — there is no
payment to withhold from. A participant that is overdrawn for the whole period therefore
suffers no withholding, whatever rate its jurisdiction carries.

A participant that earns credit interest on some days and is charged debit interest on
others suffers withholding **only on the credit interest** — the debit interest is a charge,
not a payment, and there is nothing to withhold from it.

## 5. The pool benefit

The bank credits the header company interest on the **net notional pooled position** for
each day, at the **credit rate**, on the same day count basis. The excess of that bank
interest over the **net interest allocated to the participants** — total credit interest
allocated less total debit interest charged, before withholding tax — is the **pool
benefit** retained by the header company.

Round every figure to two decimal places.

## 6. Rounding convention for totals

Each participant's credit interest and debit interest is computed and **rounded to
two decimal places individually**. The totals in `results.json` —
`credit_interest_total_eur`, `debit_interest_total_eur`, `net_interest_allocated_eur`,
`withholding_tax_eur`, and `pool_benefit_eur` — are the **sum of those rounded
per-participant amounts**, then rounded to two decimal places themselves. Do not
sum unrounded interest and round only the total; sum the rounded per-participant
figures.
