# Notional cash pool — June 20X5 interest allocation

Credit interest of **26,075.00** is allocated to the participants in
credit and debit interest of **28,035.00** is charged to those overdrawn,
a net allocation of **-1,960.00** before withholding tax of
1,425.00. The bank credited the header company
14,060.00 on the net pooled position, so the **pool benefit retained by
the header is 16,020.00**.

| Participant | Average balance | Credit interest | Debit interest | Withholding |
|---|---|---|---|---|
| Vondel BV | 5,166,666.67 | 7,750.00 | 0.00 | 0.00 |
| Liffey Ltd | 1,600,000.00 | 2,400.00 | 0.00 | 0.00 |
| Ebro SA | -2,500,000.00 | 0.00 | 8,750.00 | 0.00 |
| Wisla Sp z o o | 900,000.00 | 1,350.00 | 0.00 | 202.50 |
| Arno SpA | -583,333.33 | 125.00 | 2,333.33 | 0.00 |
| Nordkap AS | 0.00 | 0.00 | 0.00 | 0.00 |
| Tagus SA | 900,000.00 | 1,350.00 | 0.00 | 270.00 |
| Seine SAS | 733,333.33 | 1,350.00 | 583.33 | 270.00 |
| Tiber SA | 0.00 | 300.00 | 700.00 | 0.00 |
| Guadalquivir SL | -1,200,000.00 | 0.00 | 4,200.00 | 0.00 |
| Main GmbH | 3,000,000.00 | 4,500.00 | 0.00 | 225.00 |
| Rhine AG | 940,000.00 | 1,950.00 | 1,260.00 | 195.00 |
| Douro Lda | 166,666.67 | 250.00 | 0.00 | 37.50 |
| Loire SA | 500,000.25 | 750.00 | 0.00 | 150.00 |
| Shannon plc | 666,666.67 | 1,250.00 | 583.33 | 0.00 |
| Scheldt NV | -2,500,000.00 | 0.00 | 8,750.00 | 0.00 |
| Tweed Ltd | 1,333,331.67 | 2,000.00 | 0.01 | 0.00 |
| Vistula SA | 250,000.00 | 750.00 | 875.00 | 75.00 |

## Two rates, priced day by day

Positive balances earn 1.80% and negative balances are charged
4.20%, both on an actual/360 basis. A balance of zero on any day
earns neither credit nor debit interest — zero is neither positive nor negative.

## The participant that crossed from credit to debit

Arno was in credit for the first five days and overdrawn for the remaining
25. Its days in credit earn 125.00 at the
credit rate and its days overdrawn are charged 2,333.33 at
the debit rate, a net charge of 2,208.33.

Seine changed sign twice: credit for days 1-10, debit for days 11-20,
then credit again for days 21-30. Each leg is priced separately —
1,350.00 of credit interest and 583.33 of debit interest — and withholding
applies only to the credit interest, not to the debit charge.

Rhine changed sign four times: credit (days 1-6), debit (days 7-12),
credit (days 13-18), debit (days 19-24), credit (days 25-30). Each of the
five legs is priced at the rate for its sign. Withholding at 10% falls only
on the total credit interest (1,950.00), not on the debit charge (1,260.00).

Vistula alternated sign every five days across six segments — three credit
legs and three debit legs — each priced separately.

Tiber had a zero balance for days 11-15, earning nothing and being charged
nothing for those five days.

Tweed had a tiny debit balance of -5.00 for the first ten days, producing
a debit charge of 0.01, and a large credit balance for the remaining twenty.

Loire carried a balance of 0.50 for the first fifteen days — positive but
tiny — and a normal balance thereafter. The tiny balance earns a negligible
amount of credit interest that rounds to 0.00, but it is still a positive
balance, not zero.

Shannon had a zero-balance segment (days 11-15) between a credit leg and a
debit leg. The zero days accrue nothing; the credit and debit legs are priced
separately.

## Withholding falls only on interest credited

Withholding is deducted from interest **credited to** a participant. Wisla is in credit
throughout and suffers 202.50 on its
1,350.00 of interest. Guadalquivir and Scheldt both carry withholding rates of
25% in the register but are charged interest rather than credited with any,
so **no withholding arises on either** — there is no payment from which to withhold.
Seine earns credit interest and is charged debit interest; withholding at 20% falls only on
the credit leg (270.00), not on the debit charge.

## A company on the register that is not in the pool

Nordkap appears in `participants.csv` and in `balances.csv`, but its accession date falls
after the end of the period. It is **not a participant for this period**: no interest is
allocated to it and its balances are excluded from the net pooled position.

Tagus acceded on day 16 of the period. Its balances for days 1-15 are excluded
from the pool; only days 16-30 are priced and included in the pooled position.
Its average balance is reported as total balance-days divided by 30, not by 15.

Douro acceded on day 30, the last day of the period. Only one day of balance
is priced and included in the pool. Its average balance is total balance-days
divided by 30, which is much smaller than its actual daily balance.

## The pool benefit

Balance-days across the participants total 281,199,958, which at the credit
rate gives the bank's credit of 14,060.00. Net interest allocated to the
participants is -1,960.00, so the header company retains
16,020.00 — the value of setting the overdrawn participants against the ones in
credit, which is the point of the pool.
