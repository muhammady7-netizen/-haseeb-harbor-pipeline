# Task

The notional pool statement for the month is in and I need the interest allocation for the participants and the benefit the header company keeps. Work it up from the attached participant register and daily balance segments. The pool agreement is authoritative on who is in the pool for the period, on the two rates and the day count basis, on how a participant whose balance changes sign is priced, on which leg withholding tax attaches to, and on how the pool benefit is derived. Save `pool_allocation.csv` with the columns `participant,balance_days_eur,average_balance_eur,credit_interest_eur,debit_interest_eur,withholding_tax_eur,net_eur,basis`, one row per company on the register plus rows for the totals, the bank interest on the pooled position and the pool benefit. Then write `cash_pool_memo.md` explaining how you priced the participant that changed sign, why withholding fell where it did, and how you treated anyone on the register who was not in the pool.


- The attachments are provided read-only at: `input/pool_agreement.md`; `input/participants.csv`; `input/balances.csv`. Read them there.
- Save your deliverables into your current working directory using exactly these filenames:
    - `pool_allocation.csv` — Participant-level interest allocation
    - `cash_pool_memo.md` — Markdown memo on the allocation decisions
    - `results.json` — a JSON object with the keys `credit_interest_total_eur`, `debit_interest_total_eur`, `net_interest_allocated_eur`, `withholding_tax_eur`, `pool_benefit_eur`
- Writing those files is the required deliverable and must be your final action; confirm each one exists before you answer.

