# Trust principal & income allocation policy

This policy governs how each transaction on the trust's ledger is allocated between
Principal and Income. Where the CSV transaction feed and the custodial brokerage statement
disagree on an amount, **the brokerage statement governs** and the CSV figure must be
corrected before the split is applied.

## 0. Data preparation

The transaction feed may contain duplicate `txn_id` rows. When the same `txn_id` appears
more than once (matched case-insensitively), keep only the **last row** (last-row-wins)
and ignore earlier rows for that transaction. The `txn_type` field may use mixed case
(e.g. `Interest` or `CAPITAL_GAIN`); match it **case-insensitively** after trim. Emit
canonical lowercase `txn_type` and canonical uppercase `txn_id` (e.g. `T5`, not `t5`) in
the audit CSV.

## 1. Ordinary income

Interest, ordinary dividends, and REIT distributions explicitly coded as ordinary (not
return-of-capital) are allocated 100% to Income.

## 2. Realized gains and losses — Principal

Realized capital gains and losses on the sale of trust assets are allocated 100% to
Principal.

## 3. Return-of-capital distributions — Principal

A distribution coded as return-of-capital (ROC) is allocated 100% to Principal, even though
it is paid alongside ordinary distributions and may look like income on a brokerage 1099.
**This rule applies only to distributions actually coded return-of-capital** — an ordinary
distribution from the same type of security is still Income under rule 1. Treating every
distribution from a security that sometimes pays ROC as automatically Principal is the
commonest false positive; the transaction's own ROC coding is what decides, not the security.

## 4. Trust administration fees — split 50/50

Trustee fees, investment-manager fees, and other trust administration fees are split
50%/50% between Principal and Income, UNLESS the transaction was
recorded on the CSV feed as a plain withdrawal with no split at all (one side is zero) —
those must be corrected to the 50%/50% split.

## 5. Source of truth

Wherever the CSV feed and the brokerage statement disagree on a transaction's amount, the
brokerage statement's figure is used for the allocation, and the CSV figure is corrected.

## 6. Finding names

The audit compares the ledger's reported Income/Principal split against the split this
policy produces: `correct` where they match; `gain_misallocated_to_income` where a capital
gain was booked to Income; `roc_misallocated_to_income` where a return-of-capital
distribution was booked to Income; `fee_not_split` where a fee was left as an unsplit
withdrawal; `brokerage_discrepancy_uncorrected` where the CSV and brokerage amounts disagree
and the ledger still used the CSV figure.

## 7. Finding precedence

Where a single transaction carries both an allocation error (a gain misallocated to
income, a return-of-capital distribution misallocated to income, or a fee left unsplit)
**and** a brokerage discrepancy (the CSV and brokerage figures disagree and the ledger used
the CSV figure), the allocation error is the finding. The brokerage amount is still used to
compute the correct split, but the finding names the allocation error, not the discrepancy.
The brokerage-discrepancy finding is reserved for transactions whose allocation type is
otherwise correct and whose only error is the uncorrected amount.
