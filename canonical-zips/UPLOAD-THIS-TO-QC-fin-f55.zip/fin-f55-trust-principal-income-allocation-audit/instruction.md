# Task

Review the trust ledger before we cut the year-end Principal & Income statement. For each transaction, recompute the correct Income/Principal split from its type, using the brokerage statement's amount as the source of truth wherever it disagrees with the CSV feed, and compare it against how the ledger actually booked it. The policy specifies data-preparation rules: duplicate `txn_id` rows (matched case-insensitively) use last-row-wins, and `txn_type` labels are matched case-insensitively (emit canonical lowercase). Emit canonical uppercase `txn_id` in the audit CSV (e.g., `T5`, not `t5`). Save `pi_allocation_audit.csv` with columns `txn_id,txn_type,csv_amount,brokerage_amount,correct_income,correct_principal,reported_income,reported_principal,finding`, using `correct`, `gain_misallocated_to_income`, `roc_misallocated_to_income`, `fee_not_split` or `brokerage_discrepancy_uncorrected` following the finding rules and precedence in the policy. Then write `pi_allocation_memo.md` explaining each finding and the ordinary distribution that correctly stays income. In the memo, cite each finding by its exact label from the set above (`correct`, `gain_misallocated_to_income`, `roc_misallocated_to_income`, `fee_not_split`, `brokerage_discrepancy_uncorrected`) when discussing the corresponding transaction.

---
Save your deliverables into your current working directory using exactly these filenames:
    - `pi_allocation_audit.csv` — Per-transaction principal/income allocation audit
    - `pi_allocation_memo.md` — Markdown audit memo
    - `results.json` — a JSON object with the keys `txn_count` (number of unique post-dedup transactions in the audit), `flagged_count` (rows whose finding is not `correct`), `gain_misallocation_count` (rows whose emitted finding is `gain_misallocated_to_income`), `fee_not_split_count` (rows whose emitted finding is `fee_not_split`), `brokerage_discrepancy_count` (rows whose emitted finding is `brokerage_discrepancy_uncorrected` — dual allocation+amount-mismatch rows are NOT counted here since their emitted finding is the allocation error)
- Writing those files is the required deliverable and must be your final action; confirm each one exists before you answer.

---

## Working environment

- Your current working directory is `/app`, and it is writable.
- The read-only attachments referred to as `input/` are at `/app/input`.
- Write every deliverable into `/app`, at the exact filenames listed above.
