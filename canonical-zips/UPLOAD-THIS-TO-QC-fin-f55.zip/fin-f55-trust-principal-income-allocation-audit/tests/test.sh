#!/bin/bash
# Harbor verifier entrypoint. Harbor copies this to /tests/test.sh and runs it
# from the task working directory; reward is read back from
# /logs/verifier/reward.txt.
mkdir -p /logs/verifier

cd /app || exit 1

python3 -m pytest \
    --ctrf /logs/verifier/ctrf.json \
    /tests/test_outputs.py \
    -rA 2>&1 | tee /logs/verifier/pytest-stdout.txt
status=${PIPESTATUS[0]}

# Fractional reward: passed/total
if [ $status -eq 0 ]; then
    echo 1 > /logs/verifier/reward.txt
else
    python3 -c "
import json, re
try:
    with open('/logs/verifier/ctrf.json') as f:
        data = json.load(f)
    tests = data.get('results', {}).get('tests', [])
    passed = sum(1 for t in tests if t.get('status') == 'passed')
    total = len(tests)
    if total >= 2:
        print(passed / total if total > 0 else 0.0)
        exit()
except:
    pass

# Fallback: parse pytest stdout for 'N failed, M passed'
try:
    with open('/logs/verifier/pytest-stdout.txt') as f:
        text = f.read()
    m = re.search(r'(\d+)\s+failed.*?(\d+)\s+passed', text)
    if m:
        failed = int(m.group(1))
        passed = int(m.group(2))
        total = failed + passed
        print(passed / total if total > 0 else 0.0)
    else:
        m2 = re.search(r'(\d+)\s+passed', text)
        if m2:
            print(1.0)
        else:
            print(0.0)
except:
    print(0.0)
" > /logs/verifier/reward.txt
fi

exit 0
