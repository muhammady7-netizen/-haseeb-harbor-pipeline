# Principal & Income allocation audit — trust ledger

## Summary

15 transactions reviewed. 7 findings.

| Txn | Type | CSV | Brokerage | Correct I/P | Reported I/P | Finding |
|-----|------|-----|-----------|-------------|--------------|---------|
| T1 | interest | 1200.0 | 1200.0 | 1200.0 / 0.0 | 1200.0 / 0.0 | correct |
| T2 | capital_gain | 8000.0 | 8000.0 | 0.0 / 8000.0 | 8000.0 / 0.0 | gain_misallocated_to_income |
| T3 | dividend_roc | 2500.0 | 2500.0 | 0.0 / 2500.0 | 2500.0 / 0.0 | roc_misallocated_to_income |
| T4 | trustee_fee | -600.0 | -600.0 | -300.0 / -300.0 | -600.0 / 0.0 | fee_not_split |
| T5 | manager_fee | -400.0 | -450.0 | -225.0 / -225.0 | -350.0 / -50.0 | brokerage_discrepancy_uncorrected |
| T6 | reit_ordinary_distribution | 900.0 | 900.0 | 900.0 / 0.0 | 900.0 / 0.0 | correct |
| T7 | capital_loss | -1500.0 | -1500.0 | 0.0 / -1500.0 | 0.0 / -1500.0 | correct |
| T8 | interest | 500.0 | 500.0 | 500.0 / 0.0 | 500.0 / 0.0 | correct |
| T9 | capital_gain | 5000.0 | 5500.0 | 0.0 / 5500.0 | 5000.0 / 0.0 | gain_misallocated_to_income |
| T10 | dividend_roc | 1800.0 | 1800.0 | 0.0 / 1800.0 | 0.0 / 1800.0 | correct |
| T11 | trustee_fee | -800.0 | -800.0 | -400.0 / -400.0 | -400.0 / -400.0 | correct |
| T12 | reit_ordinary_distribution | 1000.0 | 1200.0 | 1200.0 / 0.0 | 1000.0 / 0.0 | brokerage_discrepancy_uncorrected |
| T13 | capital_gain | 3000.0 | 3000.0 | 0.0 / 3000.0 | 0.0 / 3000.0 | correct |
| T14 | dividend_roc | 2200.0 | 2000.0 | 0.0 / 2000.0 | 2200.0 / 0.0 | roc_misallocated_to_income |
| T15 | manager_fee | -300.0 | -300.0 | -150.0 / -150.0 | -150.0 / -150.0 | correct |

## Data preparation

Duplicate T5 row resolved by last-row-wins (the second row `t5` with reported -350.0/-50.0
replaces the first `T5` with -200.0/-200.0, matched case-insensitively). Transaction types
matched case-insensitively (e.g. `Interest` = `interest`, `CAPITAL_GAIN` = `capital_gain`).
Canonical lowercase txn_type and uppercase txn_id emitted in the audit CSV.

## T2: gain_misallocated_to_income

T2 is a realized capital gain of 8000.0, which the policy sends 100% to Principal, but
the ledger booked it entirely to Income. The correct split is 0.0 income / 8000.0
principal. The capital gain was booked to income; it should be principal.

## T3: roc_misallocated_to_income

T3 is a return-of-capital distribution of 2500.0, which belongs to Principal, but the
ledger booked it to Income. The return of capital was booked to income; it should be
principal.

## T4: fee_not_split

T4 is a trustee fee of -600.0 that the ledger recorded as a single unsplit withdrawal
to Income. The policy requires a 50/50 split: -300.0 income / -300.0 principal. The
fee was charged wholly to income instead of being split between income and principal.

## T5: brokerage_discrepancy_uncorrected

T5 is a manager fee where CSV shows -400.0 but brokerage shows -450.0. The ledger used
the CSV figure and split it -350.0/-50.0 instead of the correct -225.0/-225.0 based on
the brokerage amount. The fee was split (not left unsplit — both sides are non-zero), but
the wrong source amount was used. The finding is `brokerage_discrepancy_uncorrected` — the
allocation type is correct (fee split) but the amount is wrong because the ledger used the
CSV figure.

## T9: gain_misallocated_to_income

T9 is a capital gain where CSV shows 5000.0 but brokerage shows 5500.0. The ledger used
the CSV figure of 5000.0 and booked it to Income. The correct split using brokerage is
0.0 income / 5500.0 principal. Both the allocation type (income vs principal) and the
amount (CSV vs brokerage) are wrong. By finding precedence (rule 7), the allocation error
is the finding: `gain_misallocated_to_income`, not `brokerage_discrepancy_uncorrected`.

## T12: brokerage_discrepancy_uncorrected

T12 is a REIT ordinary distribution where CSV shows 1000.0 but brokerage shows 1200.0.
The ledger used the CSV figure of 1000.0 and booked it to Income. The correct split
using brokerage is 1200.0 income / 0.0 principal. The brokerage overrides the CSV; the
ledger was not corrected.

## T14: roc_misallocated_to_income

T14 is a return-of-capital distribution where CSV shows 2200.0 but brokerage shows
2000.0. The ledger used the CSV figure of 2200.0 and booked it to Income. The correct
split using brokerage is 0.0 income / 2000.0 principal. Both the allocation type (income
vs principal) and the amount (CSV vs brokerage) are wrong. By finding precedence (rule 7),
the allocation error is the finding: `roc_misallocated_to_income`, not
`brokerage_discrepancy_uncorrected`.

## Ordinary distribution that correctly stays income

T6 is a REIT distribution explicitly coded as ordinary (not return-of-capital). Despite
coming from a security type that sometimes pays ROC, the transaction's own coding as
ordinary means it stays 100% Income. The ordinary distribution correctly stays income.
