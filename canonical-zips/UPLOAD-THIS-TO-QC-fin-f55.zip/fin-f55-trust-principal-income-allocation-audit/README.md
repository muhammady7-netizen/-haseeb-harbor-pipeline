# fin-f55-trust-principal-income-allocation-audit

Non-connector Harbor task. Audit a trust ledger's principal/income allocations against the trust P&I allocation policy.

## Inputs (read-only, under environment/input/)
- `pi_allocation_policy.md` — binding principal/income allocation rules (gain, ordinary-income, ROC, fee-split, brokerage discrepancy, finding precedence).
- `trust_transactions.csv` — 15 transactions (mixed case, duplicate txn_ids, mixed signs) to reconcile.

## Deliverables (agent writes to its working directory)
- `pi_allocation_audit.csv` — one row per transaction (txn_id, txn_type, csv_amount, brokerage_amount, correct_income, correct_principal, reported_income, reported_principal, finding).
- `pi_allocation_memo.md` — explanation of each flagged finding (T-id + exact label).
- `results.json` — txn_count, flagged_count, gain_misallocation_count, fee_not_split_count, brokerage_discrepancy_count.

## Verifier
47 deterministic checks in `tests/verifier.json` (file presence, columns, per-transaction findings and value recomputation, exact 15-row count, memo proximity checks, results.json keys). No LLM judge.

## Evidence
Oracle reward 1.0; GLM-5.2 1/4 strict pass; 3 stability repeats at 1.0.
