import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from .models import VerifierDefinition, VerifierSpec, effective_weights
from .source_types import DEFAULT_LOOKUP_ORDER
from .sources.registry import SourceRegistry
from .verifiers import VerifierInfrastructureError, result_entry, verify_definition

logger = logging.getLogger(__name__)


def load_spec(path: Path) -> VerifierSpec:
    """Loads and validates a verifier spec.

    Args:
        path: Path to verifier.json.

    Returns:
        Parsed verifier specification.

    Raises:
        ValueError: If the JSON content does not match the v3 schema.
    """
    try:
        # utf-8-sig: a verifier.json saved by a Windows editor carries a BOM,
        # which plain utf-8 leaves in the string and the whole spec fails to load.
        return VerifierSpec.model_validate_json(path.read_text(encoding="utf-8-sig"))
    except ValidationError as exc:
        raise ValueError(f"invalid verifier schema: {exc}") from exc


def run_verifier(
    spec_path: Path,
    *,
    workspace_dir: Path,
    verifier_dir: Path,
    agent_logs_dir: Path | None = None,
    llm_completion: Callable[..., Any] | None = None,
    max_content_chars: int = 90000,
    seeded_input_paths: tuple[str, ...] | list[str] = (),
    lookup_order: tuple[str, ...] | list[str] = DEFAULT_LOOKUP_ORDER,
    trusted_input_dir: Path | None = None,
    trusted_reference_dir: Path | None = None,
) -> dict[str, Any]:
    """Runs all verifiers from a spec and writes output artifacts.

    Args:
        spec_path: Path to verifier.json.
        workspace_dir: Workspace containing task output artifacts.
        verifier_dir: Directory where verifier artifacts should be written.
        agent_logs_dir: Optional directory exposing agent trajectory logs.
            Required only when the spec uses ``response.*`` sources; if
            ``None`` and such a source runs, a clear runtime error is raised.
        llm_completion: Optional LiteLLM-compatible completion function for
            tests.
        max_content_chars: Maximum text content returned by file sources.
        seeded_input_paths: Exact workspace-relative task inputs seeded by the
            harness. Used only by dedicated source commands.
        lookup_order: Ordered rungs used to locate a declared deliverable path.
            Defaults to ``DEFAULT_LOOKUP_ORDER``.
        trusted_input_dir: Optional clean snapshot of declared task inputs for
            executable checks. This must not be the agent-visible workspace.
        trusted_reference_dir: Optional verifier-private gold-artifact root.
            This must never be the agent-visible workspace or input directory.

    Returns:
        The verifier reward payload written to reward.json.

    Raises:
        ValueError: If the spec is invalid.
        RuntimeError: If the run itself cannot be graded -- an unloadable spec
            or a registry that cannot be built. A single verifier's
            infrastructure failure is recorded on that verifier instead.
    """
    try:
        spec = load_spec(spec_path)
    except Exception as exc:
        write_outputs(build_failure_payload(str(exc)), verifier_dir)
        raise

    results: list[dict[str, Any]] = []
    try:
        registry = SourceRegistry(
            workspace_dir,
            agent_logs_dir=agent_logs_dir,
            max_content_chars=max_content_chars,
            seeded_input_paths=seeded_input_paths,
            trusted_input_dir=trusted_input_dir,
            trusted_reference_dir=trusted_reference_dir,
            lookup_order=lookup_order,
        )
        weights = effective_weights(spec.verifiers)
        for definition in spec.verifiers:
            effective_weight = weights[definition.name]
            try:
                results.append(
                    verify_definition(
                        definition,
                        registry,
                        effective_weight,
                        config=spec.config,
                        completion_fn=llm_completion,
                    )
                )
            except VerifierInfrastructureError as exc:
                # An unreachable judge, a missing library or an unreadable
                # deliverable is that verifier's failure, not the run's.
                # Aborting here (as the v2 import did) left every later
                # verifier ungraded and scored the run 0. Isolating costs no
                # trust: both package runtimes still refuse a run with
                # summary.errored > 0. Restored from main 37b6febc3c.
                logger.warning(
                    "verifier %s could not be graded: %s", definition.name, exc
                )
                results.append(
                    exc.partial_result
                    if exc.partial_result is not None
                    else infrastructure_result(definition, effective_weight, str(exc))
                )
    except Exception as exc:
        write_outputs(build_payload(spec, results, fatal_error=str(exc)), verifier_dir)
        raise

    payload = build_payload(spec, results)
    write_outputs(payload, verifier_dir)
    print_summary(payload)
    return payload


def infrastructure_result(
    definition: VerifierDefinition, effective_weight: float, error: str
) -> dict[str, Any]:
    """Builds the errored result for a verifier that raised no partial result.

    Most infrastructure errors carry the result they had built so far; the two
    raise sites that wrap an unexpected exception carry none, and that verifier
    would otherwise vanish from the report entirely.

    Args:
        definition: The verifier that could not be graded.
        effective_weight: Weight the verifier would have carried.
        error: Human-readable infrastructure error.

    Returns:
        Result entry marking the verifier errored, awarding no weight.
    """
    return result_entry(
        definition,
        success=False,
        expected=definition.assertion.expected,
        actual=None,
        effective_weight=effective_weight,
        error=error,
        reason="verifier error",
        evaluation={},
        source_data=None,
    )


def build_payload(
    spec: VerifierSpec,
    results: list[dict[str, Any]],
    fatal_error: str | None = None,
) -> dict[str, Any]:
    """Builds the verifier-owned reward.json payload.

    Args:
        spec: Parsed verifier specification.
        results: Assertion results produced so far.
        fatal_error: Optional infrastructure/authoring error.

    Returns:
        Dictionary payload containing reward, summary, and assertion results.
    """
    if fatal_error:
        passed_weight = 0.0
    else:
        weight_sum = sum(r["result"]["effective_weight"] for r in results if r["result"]["success"])
        passed_weight = min(float(round(weight_sum, 10)), 1.0)
        # When every verifier succeeds, award exactly the full weight so residual
        # per-weight rounding can never leave a perfect run below the total.
        if results and all(r["result"]["success"] for r in results):
            passed_weight = 1.0
    assertion_errors = sum(1 for r in results if not r["result"]["success"] and r["result"].get("error"))
    fatal_error_count = 1 if fatal_error and assertion_errors == 0 else 0
    errored = assertion_errors + fatal_error_count
    failed = sum(1 for r in results if not r["result"]["success"] and not r["result"].get("error"))
    summary = {
        "total_verifiers": len(spec.verifiers),
        "passed": sum(1 for r in results if r["result"]["success"]),
        "failed": failed,
        "errored": errored,
        "total_weight": 1.0,
        "passed_weight": passed_weight,
    }
    payload: dict[str, Any] = {
        "task_id": spec.task_id,
        "reward": passed_weight,
        "summary": summary,
        "assertion_results": results,
    }
    if fatal_error:
        payload["error"] = fatal_error
    return payload


def build_failure_payload(error: str, task_id: str | None = None) -> dict[str, Any]:
    """Builds a best-effort payload for fatal runtime failures.

    Args:
        error: Fatal error message.
        task_id: Optional task id if known.

    Returns:
        Failure payload with no reward.txt companion.
    """
    return {
        "task_id": task_id,
        "reward": 0.0,
        "summary": {
            "total_verifiers": 0,
            "passed": 0,
            "failed": 0,
            "errored": 1,
            "total_weight": 1.0,
            "passed_weight": 0.0,
        },
        "assertion_results": [],
        "error": error,
    }


def write_outputs(payload: dict[str, Any], verifier_dir: Path) -> None:
    """Writes verifier output artifacts.

    Args:
        payload: Full verifier reward payload.
        verifier_dir: Output directory for reward artifacts.
    """
    verifier_dir.mkdir(parents=True, exist_ok=True)
    (verifier_dir / "reward.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )
    (verifier_dir / "reward.txt").write_text(str(payload["reward"]), encoding="utf-8")


def print_summary(payload: dict[str, Any]) -> None:
    """Logs a concise verifier summary.

    Args:
        payload: Full verifier reward payload.
    """
    summary = payload["summary"]
    logger.info(
        "Verifier complete: reward=%s passed=%s failed=%s errored=%s",
        payload["reward"],
        summary["passed"],
        summary["failed"],
        summary["errored"],
    )
    for result in payload["assertion_results"]:
        status = "PASS" if result["result"]["success"] else "FAIL"
        if result["result"].get("error"):
            suffix = f" - {result['result']['error']}"
        elif not result["result"]["success"]:
            suffix = f" - {result['result'].get('reason') or 'assertion failed'}"
        else:
            suffix = ""
        logger.info("[%s] %s%s", status, result["name"], suffix)
