# Content publish readiness standard (CMS-PRS-1)

Binding for the `post_publish_log.csv` export from the blog CMS. A post's `finding` is
decided by these rules alone; the log's own status column is not authoritative.

Before applying any rule, **trim leading and trailing whitespace** on `post_id`,
`hero_image`, `content_status`, `evergreen_republish`, `faq_duplicates`, `published_date`,
the log's `signoff_date`, and each register `cycle_signoff_date`. Also trim `post_id` on
every register row. Last-wins collapse and register lookup key on the trimmed `post_id`,
matched **case-insensitively** (`p-40` and `P-40` are the same post). Report the
canonical upper-cased form of the winning trimmed id (e.g. `P-40`).

If the export contains more than one row for the same `post_id` (after that keying), the
**last row in the file wins** for every field on that post. Do not merge fields across
revisions — only the winning row's values apply.

## R0 — Void / excluded posts are omitted

After last-wins collapse on the log, if the trimmed `content_status` matches `void` or
`excluded` case-insensitively, **omit** that post_id from the audit: emit no row and do
not count it in `post_count` / `finding_count` / `flagged_count` / `clean_count`. Earlier
non-void revisions for the same post_id do not survive once the winning row is
void/excluded. Register rows for omitted posts are ignored.

**Only** `void` and `excluded` are omit statuses. Other statuses remain in the audit and
take normal findings. If an earlier revision is void/excluded but the **winning** row is
not, **keep** the post — last-wins decides omit, not “any revision was void.”

## FAQ parse

Parse `faq_duplicates` as a number after trimming. A blank or non-numeric value is treated
as `0`. A leading `+` is allowed (`+1` → 1). Values that parse to a number ≤ 0 (`0`, `00`,
`0.0`, `-1`) are **not** `DUPLICATE_FAQ`. Numeric strings such as `01` or `1.5` that parse
strictly greater than zero are a duplicate-FAQ finding.

## R1 — Hero image required whenever the field is empty after trim

A post whose trimmed `hero_image` is empty is `MISSING_IMAGE`, regardless of
`content_status` or anything else about it. A non-empty trimmed value — including literal
filenames such as `N/A` or `none` — is treated as an assigned image and is **not**
`MISSING_IMAGE`.

Match `content_status` **case-insensitively** after trim (`live`, `LIVE`, ` Live ` all
count as live when applying other rules that mention live status).

## R2 — No duplicate FAQ items

If the parsed `faq_duplicates` count is strictly greater than zero, the post is
`DUPLICATE_FAQ`.

## R3 — Sample and test posts must never carry a live publish date

Match `content_status` case-insensitively after trim. A post whose trimmed status is
`sample` or `test` is scaffolding. If such a post has a non-empty trimmed
`published_date`, it went live by mistake and is `SAMPLE_LIVE`. A whitespace-only
`published_date` is empty after trim and is **not** a publish date. A sample or test post
with no publish date is not a finding under this rule. Non-sample/non-test statuses are
**not** scaffolding under this rule.

## R4 — A post cannot publish before its own sign-off

Every post's trimmed `published_date` must fall on or after this cycle's recorded sign-off
date. After trim, accept calendar dates in exactly `YYYY-MM-DD` or `YYYY/MM/DD` (same
Y-M-D). Compare as calendar dates, never as raw strings. A non-empty trimmed
`published_date` that is neither form — including US-style `MM/DD/YYYY`, timestamps such
as `2026-09-05T12:00:00`, or impossible calendar components — is still a publish date for
R3, and for R4 is always `PREMATURE_PUBLISH` unless the evergreen exception applies.

When both the published date and the resolved sign-off parse, equal calendar dates are
**not** premature.

Resolve sign-off as follows:

1. Look up `post_id` in `editorial_signoff.csv` using the same trim + case-insensitive key.
   If more than one register row shares a `post_id`, the **last row in the file wins**.
2. If a winning register row exists and its trimmed `cycle_signoff_date` is non-empty, use
   that date (parsed with the same calendar forms).
3. If there is **no** register row for the post, **or** the winning register date is blank
   after trim, fall back to the log's trimmed `signoff_date`.
4. Copy the resolved date into the audit's `signoff_date` column (as `YYYY-MM-DD` when the
   resolved value parses; otherwise copy the trimmed resolved text).

Emit parseable published dates in the audit as `YYYY-MM-DD` (normalize slash form to dash
form).

A post with a non-empty trimmed `published_date` that publishes before the resolved
sign-off date is `PREMATURE_PUBLISH`.

**Exception:** treat `evergreen_republish` as affirmative **only** when the trimmed value
equals `yes` case-insensitively with no other characters (`yes`, `YES`, and ` yes ` after
trim all count). Values such as `true`, `y`, `1`, `yes!`, `yesplease`, or `evergreen` are
**not** evergreen. Blank and `no` are not evergreen. An evergreen republish is never
`PREMATURE_PUBLISH` on date grounds alone. The exception covers only `PREMATURE_PUBLISH`.
Other readiness codes still apply.

## Finding codes

`MISSING_IMAGE`, `DUPLICATE_FAQ`, `SAMPLE_LIVE`, `PREMATURE_PUBLISH`. A post may carry more
than one. When it does, join the applicable codes with `|` in this rule order:
`MISSING_IMAGE`, then `DUPLICATE_FAQ`, then `SAMPLE_LIVE`, then `PREMATURE_PUBLISH`. A post
with no code is `none`.

## Derived totals

These four figures are computed from the completed audit (after last-wins collapse and R0
omit):

- `post_count`: number of unique posts remaining in the audit.
- `finding_count`: number of individual readiness codes assigned. A post whose `finding`
  joins two codes contributes two.
- `flagged_count`: number of posts whose `finding` is not `none`.
- `clean_count`: number of posts whose `finding` is `none`.
