# Publish readiness audit

52 unique posts after log last-wins collapse and R0 omit. 38 carry at least one finding (57 findings in total) and 14 are clean. Sign-off uses `editorial_signoff.csv` last-wins when a non-blank register date exists; otherwise the log cache is the fallback. Calendar dates accept `YYYY-MM-DD` or `YYYY/MM/DD`. Void/excluded winning rows are omitted from the audit.

| Post | Status | Sign-off | Published | Finding |
|---|---|---|---|---|
| P-01 | live | 2026-09-01 | 2026-09-03 | none |
| P-02 | live | 2026-09-10 | 2026-09-05 | MISSING_IMAGE|PREMATURE_PUBLISH |
| P-03 | live | 2026-09-01 | 2026-09-04 | DUPLICATE_FAQ |
| P-04 | sample | 2026-09-01 | 2026-09-02 | SAMPLE_LIVE |
| P-05 | live | 2026-09-10 | 2026-09-05 | PREMATURE_PUBLISH |
| P-06 | live | 2026-09-10 | 2026-08-20 | none |
| P-07 | live | 2026-09-01 | 2026-09-01 | none |
| P-08 | test | 2026-09-01 | — | none |
| P-09 | sample | 2026-09-01 | 2026-09-02 | MISSING_IMAGE|SAMPLE_LIVE |
| P-10 | live | 2026-09-10 | 2026-08-15 | MISSING_IMAGE |
| P-11 | live | 2026-09-10 | 2026-09-03 | PREMATURE_PUBLISH |
| P-12 | test | 2026-09-01 | 2026-09-02 | SAMPLE_LIVE |
| P-13 | live | 2026-09-01 | 2026-09-04 | MISSING_IMAGE|DUPLICATE_FAQ |
| P-14 | live | 2026-09-01 | 2026-09-04 | MISSING_IMAGE |
| P-15 | live | 2026-09-08 | 2026-09-05 | PREMATURE_PUBLISH |
| P-16 | live | 2026-09-01 | 2026-09-04 | MISSING_IMAGE |
| P-17 | live | 2026-09-12 | 2026-09-10 | PREMATURE_PUBLISH |
| P-18 | sample | 2026-09-01 | — | DUPLICATE_FAQ |
| P-19 | test | 2026-09-01 | 2026-09-03 | DUPLICATE_FAQ|SAMPLE_LIVE |
| P-20 | live | 2026-09-12 | 2026-09-02 | MISSING_IMAGE|DUPLICATE_FAQ|PREMATURE_PUBLISH |
| P-21 | live | 2026-09-10 | 2026-08-25 | none |
| P-22 | live | 2026-09-10 | 2026-08-20 | PREMATURE_PUBLISH |
| P-23 | live | 2026-09-10 | 2026-08-18 | PREMATURE_PUBLISH |
| P-24 | live | 2026-09-01 | 2026-09-04 | none |
| P-25 | live | 2026-09-01 | 2026-09-04 | none |
| P-26 | live | 2026-09-01 | 2026-09-04 | DUPLICATE_FAQ |
| P-27 | live | 2026-09-01 | 2026-09-04 | none |
| P-28 | sample | 2026-09-01 | — | none |
| P-29 | live | 2026-09-01 | 2026-09-04 | MISSING_IMAGE |
| P-30 | live | 2026-09-09 | 2026-09-05 | PREMATURE_PUBLISH |
| P-31 | sample | 2026-09-10 | 2026-09-02 | MISSING_IMAGE|DUPLICATE_FAQ|SAMPLE_LIVE|PREMATURE_PUBLISH |
| P-32 | test | 2026-09-01 | 2026-09-03 | SAMPLE_LIVE |
| P-33 | live | 2026-09-10 | 2026-08-10 | PREMATURE_PUBLISH |
| P-34 | live | 2026-09-01 | 2026-09-04 | none |
| P-37 | live | 2026-09-12 | 2026-09-04 | DUPLICATE_FAQ|PREMATURE_PUBLISH |
| P-38 | live | 2026-09-15 | 2026-09-10 | PREMATURE_PUBLISH |
| P-39 | live | 2026-09-10 | 2026-09-05 | PREMATURE_PUBLISH |
| P-40 | live | 2026-09-10 | 2026-09-03 | PREMATURE_PUBLISH |
| P-41 | live | 2026-09-01 | 2026-09-04 | DUPLICATE_FAQ |
| P-42 | live | 2026-09-01 | 2026-09-04 | none |
| P-43 | live | 2026-09-12 | 2026-09-02 | MISSING_IMAGE|DUPLICATE_FAQ|PREMATURE_PUBLISH |
| P-44 | sample | 2026-09-10 | 2026-09-03 | DUPLICATE_FAQ|SAMPLE_LIVE|PREMATURE_PUBLISH |
| P-45 | live | 2026-09-01 | 09/05/2026 | PREMATURE_PUBLISH |
| P-49 | live | 2026-09-01 | 2026-09-04 | none |
| P-50 | live | 2026-09-12 | 2026-09-10 | PREMATURE_PUBLISH |
| P-51 | live | 2026-09-10 | 2026-08-01 | none |
| P-52 | live | 2026-09-10 | 2026-08-01 | PREMATURE_PUBLISH |
| P-54 | sample | 2026-09-10 | 2026-09-05T00:00:00 | MISSING_IMAGE|DUPLICATE_FAQ|SAMPLE_LIVE|PREMATURE_PUBLISH |
| P-55 | live | 2026-09-10 | 2026-09-10 | none |
| P-58 | live | 2026-09-01 | 2026-09-05T12:00:00 | PREMATURE_PUBLISH |
| P-61 | live | 2026-09-01 | 2026-13-01 | PREMATURE_PUBLISH |
| P-62 | live | 2026-09-15 | 2026-09-03 | MISSING_IMAGE|DUPLICATE_FAQ|PREMATURE_PUBLISH |

## Readiness rules applied

A trimmed empty `hero_image` (including whitespace-only) is required to flag `MISSING_IMAGE`; literal filenames such as `N/A` or `none` are not empty and stay assigned. Parsed `faq_duplicates` values strictly greater than zero flag `DUPLICATE_FAQ` (leading `+` allowed; `0.0` and other ≤0 parses stay clean).

## Void / excluded omit

P-35 wins as `void` and P-36 as `EXCLUDED`, so both are omitted from the audit (no row, not counted in totals) even though earlier or surface findings look flagged.

## Void-then-live survival

P-49 earlier revision is void, but the winning row is live with a hero — last-wins keeps the post as clean `none` (do not omit because any revision was void).

## Unparseable publish dates

P-45 US-style `09/05/2026`, P-58 timestamp `2026-09-05T12:00:00`, and P-61 `2026-13-01` are non-empty but not `YYYY-MM-DD`/`YYYY/MM/DD`, so each is `PREMATURE_PUBLISH`. P-54 adds the same timestamp trap on a sample with whitespace hero and `+1` FAQ → `MISSING_IMAGE|DUPLICATE_FAQ|SAMPLE_LIVE|PREMATURE_PUBLISH`.

## Register slash sign-off and equal dates

P-50 register `2026/09/12` vs publish `2026-09-10` is `PREMATURE_PUBLISH` after calendar compare. P-55 publish `2026/09/10` equals register `2026-09-10` after calendar compare → clean `none`.

## Compound register slash

P-62 whitespace hero, FAQ `01`, spaced LIVE, slash publish, and slash register last-wins → `MISSING_IMAGE|DUPLICATE_FAQ|PREMATURE_PUBLISH`.

## Evergreen spaced yes vs bang

P-51 trimmed ` yes ` equals `yes` so the early publish is exempt. P-52 `yes!` is not evergreen and remains `PREMATURE_PUBLISH`.

## Evergreen with missing image

P-10 was published on 2026-08-15, well before its sign-off on 2026-09-10, but its `evergreen_republish` is `YES` (case-insensitive), so the early publish is exempt from `PREMATURE_PUBLISH`. The empty hero image still flags `MISSING_IMAGE` because the evergreen exemption applies only to the publish-date rule, not to the image check. P-10's sole finding is therefore `MISSING_IMAGE`.

## Log revision overlay (no merge)

P-37 has three log revisions; only the last row applies (`faq=02`, log signoff 2026-09-12). Combined with register last-wins this is `DUPLICATE_FAQ|PREMATURE_PUBLISH`.

## Register triple chain

P-38 register rows are non-blank → blank → late date. Last row wins (`2026-09-15`), so publication on 2026-09-10 is `PREMATURE_PUBLISH`.

## Slash calendar date

P-39 uses `2026/09/05` vs register `2026-09-10`. Compared as calendar dates this is `PREMATURE_PUBLISH` (string compare would wrongly clean it).

## Trimmed / casefolded post_id

Log id ` p-40 ` joins register `P-40` after trim + casefold, so sign-off is 2026-09-10 and the early publish is `PREMATURE_PUBLISH`.

## FAQ +1 and 0.0

P-41 `faq_duplicates=+1` is `DUPLICATE_FAQ`. P-42 `0.0` parses to ≤0 and stays clean on R2.

## Compound slash stack

P-43 is whitespace hero, `+1` FAQ, spaced live status, slash publish date, and late register last-wins → `MISSING_IMAGE|DUPLICATE_FAQ|PREMATURE_PUBLISH`.

## Sample overlay with literal none

P-44 last row is `Sample` with literal hero `none`, FAQ `1.0`, and late register → `DUPLICATE_FAQ|SAMPLE_LIVE|PREMATURE_PUBLISH` (literal `none` is not empty).

## Earlier compound findings

P-02 is `MISSING_IMAGE|PREMATURE_PUBLISH`. P-09 is `MISSING_IMAGE|SAMPLE_LIVE`. P-13 is `MISSING_IMAGE|DUPLICATE_FAQ`. P-20 is `MISSING_IMAGE|DUPLICATE_FAQ|PREMATURE_PUBLISH`. P-06 remains clean because evergreen republish is affirmative (`yes`), so the early publish date is not `PREMATURE_PUBLISH`. P-14 is `MISSING_IMAGE` because the hero image is whitespace-only after trim. P-15 falls back to the log sign-off cache when the register has no row. P-11 is `PREMATURE_PUBLISH` only because the register overrides the log cache sign-off.

## Log last-wins

P-01 appears twice; the last row wins, so the audit uses the clean title and `none`.

## Evergreen token trap

P-22 (`true`) and P-23 (`Y`) are not affirmative evergreen (`yes` only), so early publish dates remain `PREMATURE_PUBLISH`. P-21 with exact `YES` is exempt on R4.

## Evergreen on non-winning row

P-63 has two log revisions: the first with evergreen=yes and the second (winning) with evergreen=no. Because last-wins collapse applies to every field, only the winning row's evergreen=no counts. The post was published before its sign-off, and the evergreen exception does not apply, so it is PREMATURE_PUBLISH.

## Register blank last row

P-64 has two register rows: 2026-09-15 then a blank. The blank last row wins, so the register date is empty after trim. Sign-off falls back to the log's 2026-09-01. The publish date 2026-09-03 is on or after 2026-09-01, so the post is clean.

## Negative FAQ count

P-65 has faq_duplicates=-1, which parses to a number <=0. Only strictly positive values flag DUPLICATE_FAQ, so P-65 is clean.

## Tab in hero image

P-66 has a tab character as its hero_image. After trim, the tab is removed and the field is empty, so MISSING_IMAGE applies. Trim removes all whitespace, not just spaces.

## Draft status is not omitted

P-67 has content_status=draft. Only void and excluded are omit statuses; draft is a regular post that stays in the audit. It was published before its sign-off with no evergreen exception, so it is PREMATURE_PUBLISH.

## Sample with whitespace publish date

P-68 is a sample post with a whitespace-only publish date, an empty hero image, and FAQ=1. The whitespace publish date is empty after trim, so it is not a publish date. SAMPLE_LIVE does not apply because there is no publish date. However, MISSING_IMAGE applies (empty hero) and DUPLICATE_FAQ applies (FAQ=1 > 0). The finding is MISSING_IMAGE|DUPLICATE_FAQ.

## Test post with premature publish

P-69 is a test post with a publish date of 2026-09-04 and a register sign-off of 2026-09-10. Both SAMPLE_LIVE (test with a publish date) and PREMATURE_PUBLISH (published before sign-off) apply. The finding is SAMPLE_LIVE|PREMATURE_PUBLISH.

## Evergreen with stacked findings

P-70 has evergreen=yes, an empty hero image, and FAQ=2. The evergreen exception exempts only PREMATURE_PUBLISH. MISSING_IMAGE and DUPLICATE_FAQ still apply. The finding is MISSING_IMAGE|DUPLICATE_FAQ.

## Register triple date last-wins

P-71 has three register rows: 2026-09-01, blank, and 2026-09-10. The last row (2026-09-10) wins. Published 2026-09-05 is before 2026-09-10, so it is PREMATURE_PUBLISH.

## Equal dates in different formats

P-72 has register date 2026/09/01 and published date 2026-09-01. These are equal as calendar dates (slash form normalizes to dash form), so the post is clean.
