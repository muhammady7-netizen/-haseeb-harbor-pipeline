# gen-g734-cms-publish-readiness-audit

A workplace CMS publish-readiness audit. The model receives a blog export (`post_publish_log.csv`) and a binding standard (`publish_readiness_standard.md`). The standard also names an editorial sign-off register (`editorial_signoff.csv`) whose dates override cached sign-off fields in the log.

The model must deliver three files in the workspace root:

1. **`publish_audit.csv`** — one row per post with columns `post_id,title,hero_image,content_status,signoff_date,published_date,finding`. The `finding` column is `none` or readiness codes joined with `|`.
2. **`readiness_memo.md`** — explains every finding and every post whose publish date precedes its sign-off date (including exceptions).
3. **`results.json`** — `post_count`, `finding_count`, `flagged_count`, `clean_count` derived from the completed audit.

## Why it is non-trivial

Correctness depends on coupled reasoning across sources, not independent rule checks:

- Register vs log cache: the log's `signoff_date` may look valid, but the register can override it with a later date.
- Rule interactions: empty hero image is always `MISSING_IMAGE` even on sample posts. Evergreen republish exempts only `PREMATURE_PUBLISH`, not missing hero.
- Compound codes: multiple posts carry codes in standard order.
- CSV edge case: at least one title contains a comma; naive parsing breaks row alignment.
- Derived totals: counts must match the audit; `finding_count` differs from `flagged_count` when a post has multiple codes.
