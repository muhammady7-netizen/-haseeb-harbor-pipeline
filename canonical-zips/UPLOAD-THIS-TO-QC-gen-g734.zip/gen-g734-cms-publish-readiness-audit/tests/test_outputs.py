"""Replays the harness `file_check` spec against the task workspace.

One pytest per graded assertion, so Harbor's per-test grid (and the CTRF report)
names exactly which deliverable check failed. The spec in `verifier.json` and the
engine in `rl_world_verifiers/` are copies of what the task harness runs, so a
result here means the same thing it means there.
"""

import os
import sys
from pathlib import Path

import pytest

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR))

from rl_world_verifiers.models import VerifierSpec, effective_weights  # noqa: E402
from rl_world_verifiers.sources.registry import SourceRegistry  # noqa: E402
from rl_world_verifiers.verifiers import verify_definition  # noqa: E402

WORKSPACE = Path(os.environ.get("HARBOR_TASK_WORKSPACE", "/app"))
_spec_file = next(
    (TESTS_DIR / name for name in ("manifest.json", "verifier.json") if (TESTS_DIR / name).is_file()),
    TESTS_DIR / "verifier.json",
)
SPEC = VerifierSpec.model_validate_json(_spec_file.read_text(encoding="utf-8"))
WEIGHTS = effective_weights(SPEC.verifiers)
REGISTRY = SourceRegistry(WORKSPACE)


@pytest.mark.parametrize(
    "definition",
    SPEC.verifiers,
    ids=[definition.name for definition in SPEC.verifiers],
)
def test_deliverable(definition):
    outcome = verify_definition(
        definition,
        REGISTRY,
        WEIGHTS[definition.name],
        config=SPEC.config,
        completion_fn=None,
    )["result"]
    detail = outcome.get("error") or outcome.get("reason") or "assertion failed"
    assert outcome["success"], f"{definition.name}: {detail}"


def _audit_totals(workspace: Path) -> dict[str, int]:
    """Recompute results.json totals from publish_audit.csv (last-wins by post_id)."""
    import csv

    path = workspace / "publish_audit.csv"
    assert path.is_file(), "publish_audit.csv missing for totals recompute"
    rows: dict[str, str] = {}
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        assert reader.fieldnames is not None
        assert "post_id" in reader.fieldnames and "finding" in reader.fieldnames
        for row in reader:
            pid = (row.get("post_id") or "").strip()
            if not pid:
                continue
            rows[pid] = (row.get("finding") or "").strip()
    finding_count = 0
    flagged = 0
    clean = 0
    for finding in rows.values():
        if finding == "none" or finding == "":
            clean += 1
            continue
        flagged += 1
        finding_count += len([c for c in finding.split("|") if c.strip()])
    return {
        "post_count": len(rows),
        "finding_count": finding_count,
        "flagged_count": flagged,
        "clean_count": clean,
    }


def _audit_totals(workspace):
    """Recompute results.json totals from publish_audit.csv."""
    import csv
    path = workspace / "publish_audit.csv"
    assert path.is_file(), "publish_audit.csv missing for totals recompute"
    rows = {}
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        assert reader.fieldnames is not None
        assert "post_id" in reader.fieldnames and "finding" in reader.fieldnames
        for row in reader:
            pid = (row.get("post_id") or "").strip()
            if not pid:
                continue
            rows[pid] = (row.get("finding") or "").strip()
    finding_count = 0
    flagged = 0
    clean = 0
    for finding in rows.values():
        if finding == "none" or finding == "":
            clean += 1
            continue
        flagged += 1
        finding_count += len([c for c in finding.split("|") if c.strip()])
    return {
        "post_count": len(rows),
        "finding_count": finding_count,
        "flagged_count": flagged,
        "clean_count": clean,
    }


def test_results_recomputed_from_audit():
    """results.json must match totals derived from the delivered publish_audit.csv."""
    import json
    totals = _audit_totals(WORKSPACE)
    results_path = WORKSPACE / "results.json"
    assert results_path.is_file(), "results.json missing"
    data = json.loads(results_path.read_text(encoding="utf-8"))
    for key, expected in totals.items():
        assert key in data, f"results.json missing key {key}"
        assert data[key] == expected, (
            f"results.json {key}={data[key]!r} does not match audit-derived {expected!r}"
        )
