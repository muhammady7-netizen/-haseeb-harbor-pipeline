32 verifiers. 7 interpretive discriminators.
