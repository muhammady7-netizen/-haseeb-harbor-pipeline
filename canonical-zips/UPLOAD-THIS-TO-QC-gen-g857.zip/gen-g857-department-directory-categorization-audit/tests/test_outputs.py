"""Replays verifier.json against workspace + structural cross-checks."""
import os, sys, json, csv
from pathlib import Path
from collections import defaultdict
import pytest

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR))

from rl_world_verifiers.models import VerifierSpec, effective_weights
from rl_world_verifiers.sources.registry import SourceRegistry
from rl_world_verifiers.verifiers import verify_definition

WORKSPACE = Path(os.environ.get("HARBOR_TASK_WORKSPACE", "/app"))
SPEC = VerifierSpec.model_validate_json(
    (TESTS_DIR / "verifier.json").read_text(encoding="utf-8")
)
WEIGHTS = effective_weights(SPEC.verifiers)
REGISTRY = SourceRegistry(WORKSPACE)


@pytest.mark.parametrize(
    "definition",
    SPEC.verifiers,
    ids=[definition.name for definition in SPEC.verifiers],
)
def test_deliverable(definition):
    outcome = verify_definition(
        definition,
        REGISTRY,
        WEIGHTS[definition.name],
        config=SPEC.config,
        completion_fn=None,
    )["result"]
    detail = outcome.get("error") or outcome.get("reason") or "assertion failed"
    assert outcome["success"], f"{definition.name}: {detail}"


def test_unique_person_ids_and_unmapped_schema():
    mappings_path = WORKSPACE / "g857_mappings.csv"
    unmapped_path = WORKSPACE / "g857_unmapped.csv"
    assert mappings_path.is_file()
    assert unmapped_path.is_file()

    with mappings_path.open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    ids = [r["person_id"].strip() for r in rows]
    assert len(ids) == len(set(ids)), "duplicate person_id in g857_mappings.csv"
    assert set(rows[0].keys()) == {"person_id", "target_node", "confidence", "status"}

    with unmapped_path.open(encoding="utf-8", newline="") as f:
        urows = list(csv.DictReader(f))
    assert set(urows[0].keys()) == {"person_id", "legacy_department", "role_code"}
    uids = [r["person_id"].strip() for r in urows]
    assert len(uids) == len(set(uids)), "duplicate person_id in g857_unmapped.csv"

    expected_unmapped = {
        r["person_id"].strip() for r in rows if r["status"].strip() == "NO_ROLE_MATCH"
    }
    actual_unmapped = {r["person_id"].strip() for r in urows}
    if any(r["status"].strip() == "CYCLE_DETECTED" for r in rows):
        return
    assert actual_unmapped == expected_unmapped


def test_headcount_schema_and_tree_rollup():
    input_tax = None
    for cand in [
        Path("/app/input/g857_taxonomy.json"),
        WORKSPACE / "input" / "g857_taxonomy.json",
        Path(__file__).resolve().parents[1] / "environment" / "input" / "g857_taxonomy.json",
    ]:
        if cand.is_file():
            input_tax = cand
            break
    assert input_tax is not None, "taxonomy input not found"
    tax = json.loads(input_tax.read_text(encoding="utf-8"))
    nodes = {n["node_id"]: n for n in tax["nodes"]}
    children = defaultdict(list)
    for nid, n in nodes.items():
        parent = n.get("parent")
        if parent is not None:
            children[parent].append(nid)

    hc = json.loads((WORKSPACE / "g857_headcount.json").read_text(encoding="utf-8"))
    assert set(hc.keys()) == set(nodes.keys())
    for nid, counts in hc.items():
        assert set(counts.keys()) == {"direct_count", "rolled_up_count"}
        assert isinstance(counts["direct_count"], int)
        assert isinstance(counts["rolled_up_count"], int)

    order = []
    seen = set()

    def visit(nid):
        if nid in seen:
            return
        for ch in children[nid]:
            visit(ch)
        seen.add(nid)
        order.append(nid)

    for nid, n in nodes.items():
        if n.get("parent") is None:
            visit(nid)
    for nid in order:
        expect = hc[nid]["direct_count"] + sum(
            hc[ch]["rolled_up_count"] for ch in children[nid]
        )
        assert hc[nid]["rolled_up_count"] == expect, (
            f"{nid}: rolled_up {hc[nid]['rolled_up_count']} != {expect}"
        )


def test_results_match_mappings():
    mappings_path = WORKSPACE / "g857_mappings.csv"
    assert mappings_path.is_file(), "g857_mappings.csv missing"

    findings = {}
    with mappings_path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row.get("status", "").strip() != "MAPPED":
                continue
            target = (row.get("target_node") or "").strip()
            if target:
                findings[target] = findings.get(target, 0) + 1

    hc = json.loads((WORKSPACE / "g857_headcount.json").read_text(encoding="utf-8"))
    for node_id, counts in hc.items():
        direct = counts.get("direct_count", 0)
        expected = findings.get(node_id, 0)
        assert direct == expected, (
            f"{node_id}: direct_count={direct} != mappings-derived {expected}"
        )
