#!/bin/bash
# Harbor verifier entrypoint. Harbor copies this to /tests/test.sh and runs it
# from the task working directory; reward is read back from
# /logs/verifier/reward.txt.
#
# Reward is FRACTIONAL (passed/total over per-check pytest cases), not binary.
# A near-miss run must not collapse to the same 0.0 as a 0/N run.
#
# Binary gate: if any cross-validation check fails OR any deliverable is missing,
# reward is forced to 0.0 regardless of pytest results.
mkdir -p /logs/verifier

cd /app || exit 1

python3 -m pytest \
    --ctrf /logs/verifier/ctrf.json \
    /tests/test_outputs.py \
    -rA \
    2>&1 | tee /logs/verifier/test-stdout.txt
pytest_status=${PIPESTATUS[0]}

python3 - <<'PY'
import re, csv, io, json
from pathlib import Path

# ── 1. Fractional reward from pytest results ──
stdout = Path("/logs/verifier/test-stdout.txt")
text = stdout.read_text(encoding="utf-8", errors="replace") if stdout.exists() else ""

passed = failed = 0
m = re.search(
    r"=+\s*(?:(\d+)\s+failed,\s*)?(\d+)\s+passed(?:,\s*\d+\s+skipped)?\s+in\s+",
    text,
)
if m:
    failed = int(m.group(1) or 0)
    passed = int(m.group(2) or 0)
else:
    failed = len(re.findall(r"^FAILED\s+", text, flags=re.M))
    passed = len(re.findall(r"^PASSED\s+", text, flags=re.M))

total = passed + failed
if total <= 0:
    total = 144  # 138 parametrized spec checks + 6 cross-validation pytest cases
    reward = 0.0
else:
    reward = round(passed / total, 10)
    if passed == total:
        reward = 1.0

# ── 2. Binary gate: deliverables must exist AND counts must match ──
xval_failed = []

csv_path = Path("tender_style_audit.csv")
json_path = Path("results.json")
memo_path = Path("tender_style_memo.md")

# Gate 2a: All deliverables must exist
if not csv_path.exists():
    xval_failed.append("tender_style_audit.csv missing")
if not json_path.exists():
    xval_failed.append("results.json missing")
if not memo_path.exists():
    xval_failed.append("tender_style_memo.md missing")

# Gate 2b: If both CSV and JSON exist, counts must match
if csv_path.exists() and json_path.exists():
    try:
        csv_text = csv_path.read_text(encoding="utf-8", errors="replace")
        reader = csv.DictReader(io.StringIO(csv_text))
        rows = []
        for row in reader:
            clean = {k.strip(): (v.strip() if v else v) for k, v in row.items()}
            rows.append(clean)

        results = json.loads(json_path.read_text(encoding="utf-8"))

        def finding_val(row):
            val = row.get("finding", "none") or "none"
            return val.strip().strip('"').strip()

        csv_doc_count = len(rows)
        csv_flagged = sum(1 for r in rows if finding_val(r) != "none")
        csv_color = sum(1 for r in rows if finding_val(r) in ("PRIMARY_COLOR_NONCOMPLIANT", "ACCENT_COLOR_MISSING"))
        csv_font = sum(1 for r in rows if finding_val(r) == "FONT_NONCOMPLIANT")
        csv_compliant = sum(1 for r in rows if finding_val(r) == "none")

        json_doc_count = results.get("doc_count", 0)
        json_flagged = results.get("flagged_count", 0)
        json_color = results.get("color_issue_count", 0)
        json_font = results.get("font_issue_count", 0)
        json_compliant = results.get("compliant_count", 0)

        if csv_doc_count != json_doc_count:
            xval_failed.append(f"doc_count: CSV={csv_doc_count} vs JSON={json_doc_count}")
        if csv_flagged != json_flagged:
            xval_failed.append(f"flagged_count: CSV={csv_flagged} vs JSON={json_flagged}")
        if csv_color != json_color:
            xval_failed.append(f"color_issue_count: CSV={csv_color} vs JSON={json_color}")
        if csv_font != json_font:
            xval_failed.append(f"font_issue_count: CSV={csv_font} vs JSON={json_font}")
        if csv_compliant != json_compliant:
            xval_failed.append(f"compliant_count: CSV={csv_compliant} vs JSON={json_compliant}")

        # Gate 2c: Sort order must be ascending numeric
        doc_nums = []
        for r in rows:
            raw = r.get("doc_id", "").strip().strip('"').strip()
            if raw.startswith("DOC-"):
                doc_nums.append(int(raw.split("-")[1]))
        for i in range(1, len(doc_nums)):
            if doc_nums[i] <= doc_nums[i - 1]:
                xval_failed.append(f"sort_order: DOC-{doc_nums[i-1]} followed by DOC-{doc_nums[i]}")
                break

    except Exception as e:
        xval_failed.append(f"cross-validation error: {e}")

# Binary gate: any xval failure forces reward to 0.0
if xval_failed:
    reward = 0.0
    Path("/logs/verifier/xval_failures.txt").write_text(
        "\n".join(xval_failed) + "\n", encoding="utf-8"
    )

Path("/logs/verifier/reward.txt").write_text(f"{reward}\n", encoding="utf-8")
Path("/logs/verifier/reward_meta.txt").write_text(
    f"passed={passed}\nfailed={failed}\ntotal={total}\nreward={reward}\n"
    f"xval_failed={len(xval_failed)}\n",
    encoding="utf-8",
)
print(f"fractional_reward passed={passed} failed={failed} total={total} reward={reward} xval_failed={len(xval_failed)}")
PY

# Always exit 0 so Harbor reads reward.txt (including fractional < 1.0).
exit 0
