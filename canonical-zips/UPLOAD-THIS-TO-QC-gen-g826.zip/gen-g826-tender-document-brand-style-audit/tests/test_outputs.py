"""Replays the harness `file_check` spec against the task workspace.

One pytest per graded assertion, so Harbor's per-test grid (and the CTRF report)
names exactly which deliverable check failed. The spec in `verifier.json` and the
engine in `rl_world_verifiers/` are copies of what the task harness runs, so a
result here means the same thing it means there.
"""

import os
import sys
from pathlib import Path

import pytest

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR))

from rl_world_verifiers.models import VerifierSpec, effective_weights  # noqa: E402
from rl_world_verifiers.sources.registry import SourceRegistry  # noqa: E402
from rl_world_verifiers.verifiers import verify_definition  # noqa: E402

WORKSPACE = Path(os.environ.get("HARBOR_TASK_WORKSPACE", "/app"))
SPEC = VerifierSpec.model_validate_json(
    (TESTS_DIR / "verifier.json").read_text(encoding="utf-8")
)
WEIGHTS = effective_weights(SPEC.verifiers)
REGISTRY = SourceRegistry(WORKSPACE)


@pytest.mark.parametrize(
    "definition",
    SPEC.verifiers,
    ids=[definition.name for definition in SPEC.verifiers],
)
def test_deliverable(definition):
    outcome = verify_definition(
        definition,
        REGISTRY,
        WEIGHTS[definition.name],
        config=SPEC.config,
        completion_fn=None,
    )["result"]
    detail = outcome.get("error") or outcome.get("reason") or "assertion failed"
    assert outcome["success"], f"{definition.name}: {detail}"



# ─── Cross-validation: results.json counts must match CSV tallies ───
# ─── Sort order verification ───

import csv as _csv
import io as _io
import json as _json


def _read_audit_rows():
    """Read tender_style_audit.csv from the workspace as a list of dicts."""
    csv_path = WORKSPACE / "tender_style_audit.csv"
    if not csv_path.exists():
        pytest.fail("tender_style_audit.csv not found")
    text = csv_path.read_text(encoding="utf-8", errors="replace")
    reader = _csv.DictReader(_io.StringIO(text))
    rows = []
    for row in reader:
        clean = {k.strip(): (v.strip() if v else v) for k, v in row.items()}
        rows.append(clean)
    return rows


def _read_results():
    """Read results.json from the workspace."""
    json_path = WORKSPACE / "results.json"
    if not json_path.exists():
        pytest.fail("results.json not found")
    return _json.loads(json_path.read_text(encoding="utf-8"))


def _finding_value(row):
    """Extract the finding value, handling the 'finding' column."""
    val = row.get("finding", "none") or "none"
    return val.strip().strip('"').strip()


def test_xval_csv_row_count_matches_doc_count():
    """CSV data-row count must equal results.json doc_count."""
    rows = _read_audit_rows()
    results = _read_results()
    csv_count = len(rows)
    json_count = results.get("doc_count", 0)
    assert csv_count == json_count, (
        f"CSV row count ({csv_count}) != results.json doc_count ({json_count})"
    )


def test_xval_flagged_tally_matches():
    """Non-'none' findings in CSV must equal results.json flagged_count."""
    rows = _read_audit_rows()
    results = _read_results()
    flagged = sum(1 for r in rows if _finding_value(r) != "none")
    expected = results.get("flagged_count", 0)
    assert flagged == expected, (
        f"CSV flagged tally ({flagged}) != results.json flagged_count ({expected})"
    )


def test_xval_color_tally_matches():
    """PRIMARY+ACCENT findings in CSV must equal results.json color_issue_count."""
    rows = _read_audit_rows()
    results = _read_results()
    color = sum(
        1 for r in rows
        if _finding_value(r) in ("PRIMARY_COLOR_NONCOMPLIANT", "ACCENT_COLOR_MISSING")
    )
    expected = results.get("color_issue_count", 0)
    assert color == expected, (
        f"CSV color tally ({color}) != results.json color_issue_count ({expected})"
    )


def test_xval_font_tally_matches():
    """FONT_NONCOMPLIANT findings in CSV must equal results.json font_issue_count."""
    rows = _read_audit_rows()
    results = _read_results()
    font = sum(1 for r in rows if _finding_value(r) == "FONT_NONCOMPLIANT")
    expected = results.get("font_issue_count", 0)
    assert font == expected, (
        f"CSV font tally ({font}) != results.json font_issue_count ({expected})"
    )


def test_xval_compliant_tally_matches():
    """'none' findings in CSV must equal results.json compliant_count."""
    rows = _read_audit_rows()
    results = _read_results()
    compliant = sum(1 for r in rows if _finding_value(r) == "none")
    expected = results.get("compliant_count", 0)
    assert compliant == expected, (
        f"CSV compliant tally ({compliant}) != results.json compliant_count ({expected})"
    )


def test_xval_sort_order():
    """CSV doc_ids must be in ascending numeric order."""
    rows = _read_audit_rows()
    doc_ids = []
    for r in rows:
        raw = r.get("doc_id", "")
        raw = raw.strip().strip('"').strip()
        if raw.startswith("DOC-"):
            num = int(raw.split("-")[1])
            doc_ids.append(num)
    for i in range(1, len(doc_ids)):
        assert doc_ids[i] > doc_ids[i - 1], (
            f"CSV not sorted ascending: DOC-{doc_ids[i-1]:02d} followed by DOC-{doc_ids[i]:02d}"
        )
