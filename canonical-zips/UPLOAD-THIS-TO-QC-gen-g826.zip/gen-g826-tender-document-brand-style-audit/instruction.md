# Task

Audit tender submission documents against `input/tender_brand_style_standard.md` (BS-07) using
`input/tender_submission_documents.csv` and `input/style_waivers.csv`. Apply every rule there:
primary cutover by submission_date, exact accent/typeface/logo tokens, legacy typeface exception,
withdrawn and draft exclusions, waivers, finding priority, last-row-wins duplicates, and
ascending `doc_id` sort in the audit CSV (by numeric suffix, e.g. DOC-01 before DOC-10 before DOC-100). Save `tender_style_audit.csv` with `doc_id,finding`
using `PRIMARY_COLOR_NONCOMPLIANT`, `ACCENT_COLOR_MISSING`, `FONT_NONCOMPLIANT`,
`LOGO_PLACEMENT_ERROR`, or `none`. Write `tender_style_memo.md` covering flagged docs, legacy
clearance, cutover, waivers, and exclusions.

- The attachments are provided read-only at: `input/tender_brand_style_standard.md`; `input/tender_submission_documents.csv`; `input/style_waivers.csv`. Read them there.
- Save your deliverables into your current working directory using exactly these filenames:
    - `tender_style_audit.csv` — Per-document audit
    - `tender_style_memo.md` — Markdown memo
    - `results.json` — a JSON object with the keys `doc_count`, `flagged_count`, `color_issue_count`, `font_issue_count`, `compliant_count`
- Writing those files is the required deliverable and must be your final action; confirm each one exists before you answer.
