# Tender submission brand style standard (BS-07)

## Approved tokens (trim, then exact case-sensitive match)

| Token | Value |
|-------|-------|
| Current primary (on/after cutover) | `#0B3D91` |
| Pre-cutover primary | `#0033A0` |
| Gold accent | `#C5A572` |
| Brand typeface | `Source Sans 3` |
| Logo placement | `top-left` |

## Primary color cutover

Cutover date: **2024-06-01**.
- If `submission_date` is **before** the cutover date, the approved primary is `#0033A0`.
- If `submission_date` is **on or after** the cutover date (or the date is missing/unparseable as YYYY-MM-DD), the approved primary is `#0B3D91`.

Mismatch → `PRIMARY_COLOR_NONCOMPLIANT`.

## Accent / typeface / logo

- Accent blank or not exactly `#C5A572` → `ACCENT_COLOR_MISSING`
- Typeface not exactly `Source Sans 3` → `FONT_NONCOMPLIANT`, unless legacy exception applies
- Logo not exactly `top-left` → `LOGO_PLACEMENT_ERROR`

## Legacy typeface exception

When `is_pre_2024_legacy_template` is true (`true`/`1`/`yes`, case-sensitive), typeface may be one of
`EDA Serif Legacy`, `Times Legacy` without a font finding. Color and logo still apply.
Blank legacy flag = not legacy.

## Exclusions

Exclude from the audit and from totals:
- `status` = `withdrawn` (case-insensitive)
- `review_round` = `draft` (case-insensitive)

## Waivers

`input/style_waivers.csv` lists `doc_id,waived_finding`. If the computed finding equals
`waived_finding` for that document, record `none` instead. Waivers do not cascade to a
lower-priority finding. Blank waiver rows are skipped.

## Priority / duplicates / output order

Priority: PRIMARY > ACCENT > FONT > LOGO > none.
Duplicate `doc_id`: last row wins.
`tender_style_audit.csv` must be sorted ascending by `doc_id` numeric suffix (e.g. DOC-01 before DOC-10 before DOC-100, not lexicographic).

## Processing order

Apply rules in this exact order:
1. **Dedup**: For duplicate `doc_id`, keep only the last row.
2. **Exclusions**: Remove documents where the deduped row has `status` = `withdrawn` or `review_round` = `draft`.
3. **Compute finding**: Evaluate the deduped, non-excluded row against all token rules.
4. **Waivers**: If the computed finding matches a waiver for that `doc_id`, record `none` instead.

Exclusions are checked against the deduped row only, not against prior duplicate rows.

## Totals

`doc_count`, `flagged_count`, `color_issue_count` (PRIMARY+ACCENT findings),
`font_issue_count`, `compliant_count` (`none`).
