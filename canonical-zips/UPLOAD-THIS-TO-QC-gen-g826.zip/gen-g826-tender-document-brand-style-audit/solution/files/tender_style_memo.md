# Tender style audit — 120 graded documents

Flagged 71, compliant 49.
color_issue_count=44; font_issue_count=19.
Excluded: withdrawn status and draft review_round (case-insensitive). Audit rows sorted by doc_id.

## Finding priority

PRIMARY_COLOR_NONCOMPLIANT > ACCENT_COLOR_MISSING > FONT_NONCOMPLIANT > LOGO_PLACEMENT_ERROR.

## Legacy typeface

Legacy flag must be exactly `true`, `1`, or `yes` (case-sensitive). Quoted values in CSV are parsed by the CSV module: `"true"` -> `true` (matches), `"True"` -> `True` (does not match).

## Cutover / waivers

Primary token is `#0033A0` when submission_date < 2024-06-01, else `#0B3D91`. Dates must be exactly YYYY-MM-DD format (4-digit year, 2-digit month, 2-digit day). Unparseable or missing dates default to `#0B3D91`. Quoted CSV fields containing commas (e.g. `"#0B3D91,#0033A0"`) are parsed as a single field by the CSV module and will not match the exact token.

## Processing order

Dedup (last row wins) -> exclude withdrawn/draft -> compute finding -> apply waivers.

## Typeface and placement

Approved typeface `Source Sans 3`; logo placement `top-left` (exact, case-sensitive after trim). Quoted CSV fields with embedded commas or newlines are parsed as single fields by the CSV module.
