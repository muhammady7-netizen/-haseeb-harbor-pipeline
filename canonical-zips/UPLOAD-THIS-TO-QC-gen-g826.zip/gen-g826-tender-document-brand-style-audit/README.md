# gen-g826 - Tender document brand style audit v4

## Why non-trivial

Exact token matching primary cutover by date draft/withdrawn exclusions per-finding waivers priority duplicates numeric sort binary cross-validation gate.
