# the-answer-she-already-gave

## Task Summary
Meeting-confirmation audit over a one-week calendar window on the email-calendar-gym connector, with a targeted confirmation-chase email draft write-back.

## Connector
- **Gym:** email-calendar-gym (container port 8016, streamable-http)
- **User:** Nathan Thomas (nathan.thomas@maplewoodhospital.org, timezone America/Chicago)
- **Window:** 2026-05-19 through 2026-05-25 (one week)

## Golden Answers
| Key | Value |
|---|---|
| real_meetings_count | 4 |
| fully_confirmed_count | 2 |
| still_pending_count | 1 |
| declined_required_count | 1 |
| still_pending_meeting | Technical Interview |
| still_pending_attendee_email | morgan.thompson@maplewoodhospital.org |
| declined_meeting | Skip Level 1:1 |
| declined_attendee_email | morgan.thompson@maplewoodhospital.org |
| pending_attendee_has_other_response | true |

## Central Trap
Morgan Thompson DECLINED Skip Level 1:1 (already answered) but is TENTATIVE on Technical Interview (genuinely open). Model must distinguish decline from tentative AND recognize the same person has two different responses across two meetings.

## Verifiers (19 total)
- 9 file_check verifiers (audit file exists + 8 field values)
- 4 database_state verifiers (draft created, no wrong draft, no optional draft, mailbox count, calendar untouched)
- 1 tool_execution verifier (minimum 2 calls)
- 3 rubric_check verifiers (structural classification, decline vs tentative, final reply conclusion)
- 1 file_check verifier (pending_attendee_has_other_response - cross-meeting discriminator)

## Scoring
- sql: 0.0 (dead bucket removed)
- rubric: 0.4 (3 rubric checks)
- state: 0.0 (checked but not scored)
- trajectory: 0.0
- flat_verifier_scoring: true
- side_effect_gate: true
- Forbidden tools: send_email

## Version History
- v1: Original task download
- v2: Dockerfile image pin + README.md
- v3: Fixed review.csv, manifest types. Oracle PASS, GLM 4/4 TOO_EASY
- v4: Hardened - added pending_attendee_has_other_response (cross-meeting discriminator)
- v5: Fixed scoring weights (sql 0.6->0.0 dead bucket)
- v6: Current version with all fixes

## Configuration
- Agent timeout: 4800s
- Verifier timeout: 1500s
- Agent user: rlgymagent (non-root)
- JUDGE_MODEL: openai/glm-5.2
