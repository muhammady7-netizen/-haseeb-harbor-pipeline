# code-c249-recurring-report-source-selection-audit

Non-connector Harbor task. Audit a recurring reporting pipeline's logged runs against the source-selection standard (REPORTING-OPS-2).

## Deliverables

- `report_source_audit.csv` - one row per unique run_id (finding-precedence de-dupe) plus any missing required job, with a `finding` column
- `report_source_memo.md` - markdown memo explaining every finding
- `results.json` - `flagged_count`, `source_mismatch_count`, `row_count_mismatch_count`, `missing_tail_merge_count`, `missing_job_count`

## Inputs

- `input/report_source_standard.md` - the binding standard (cutover 2026-07-06, row-count, tail-merge, required-jobs, audit deliverable shape / ordered finding-precedence)
- `input/report_run_log.csv` - 36 logged rows (32 unique run_ids after de-dupe of RUN-29/RUN-35/RUN-37/RUN-38) with `source_row_count_snapshot`

## Verifier

61 graded pytest checks: 58 deterministic assertions in `tests/verifier.json` (file existence, unique-run finding rows + missing-job row, `audit_exactly_33_rows`, proximity+prose memo checks with ~450-char connective window including densify traps RUN-35/36/37/38, five `results.json` equals checks) plus 3 checks in `tests/test_outputs.py` (identifying columns, MISSING_JOB empty fields, per-finding local memo prose gate). Fractional reward via pytest passed/total.


Densify notes (post GLM 4/4 @ 1.0): ordered finding-precedence traps (archive-finding beats live-none; dual non-none keeps live — including archive/ROW_COUNT vs live/SOURCE), off-by-one row-count, and memo evidence binding for the new flagged runs. Expected results `16/9/5/1/1`.
