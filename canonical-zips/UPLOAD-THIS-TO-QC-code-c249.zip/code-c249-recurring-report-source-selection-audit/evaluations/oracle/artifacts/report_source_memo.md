# Recurring report source-selection audit - 32 unique runs + 1 missing job

The run log lists 36 physical rows. After finding-precedence de-duplication (non-`none` over `none`, then `live` over `archive` when findings tie) there are 32 unique runs plus one `MISSING_JOB` row for `week-ahead-briefing` (33 audit rows total). 17 rows are compliant (`none`); 16 rows are flagged.

| Run | Job | Run date | Source used | Reported rows | Finding |
|---|---|---|---|---|---|
| (missing) | week-ahead-briefing |  |  | 0 | MISSING_JOB |
| RUN-27 | weekly-journal-brief | 2026-06-15 | archive | 350 | none |
| RUN-29 | weekly-journal-brief | 2026-06-20 | live | 300 | SOURCE_MISMATCH |
| RUN-38 | weekly-journal-brief | 2026-06-22 | live | 300 | SOURCE_MISMATCH |
| RUN-01 | weekly-journal-brief | 2026-06-29 | archive | 412 | none |
| RUN-32 | weekly-journal-brief | 2026-07-03 | archive | 380 | none |
| RUN-13 | weekly-journal-brief | 2026-07-05 | live | 390 | SOURCE_MISMATCH |
| RUN-24 | weekly-journal-brief | 2026-07-05 | live | 380 | SOURCE_MISMATCH |
| RUN-05 | weekly-journal-brief | 2026-07-06 | archive | 305 | none |
| RUN-10 | weekly-journal-brief | 2026-07-06 | live | 350 | SOURCE_MISMATCH |
| RUN-11 | monthly-report | 2026-07-06 | archive | 500 | none |
| RUN-21 | monthly-report | 2026-07-06 | live | 450 | none |
| RUN-22 | weekly-journal-brief | 2026-07-06 | archive | 410 | none |
| RUN-17 | weekly-journal-brief | 2026-07-07 | archive | 360 | SOURCE_MISMATCH |
| RUN-18 | weekly-journal-brief | 2026-07-07 | live | 370 | none |
| RUN-23 | weekly-journal-brief | 2026-07-07 | archive | 395 | SOURCE_MISMATCH |
| RUN-33 | weekly-journal-brief | 2026-07-08 | archive | 390 | SOURCE_MISMATCH |
| RUN-02 | weekly-journal-brief | 2026-07-13 | live | 388 | ROW_COUNT_MISMATCH |
| RUN-37 | weekly-journal-brief | 2026-07-14 | live | 456 | ROW_COUNT_MISMATCH |
| RUN-35 | weekly-journal-brief | 2026-07-20 | archive | 410 | SOURCE_MISMATCH |
| RUN-07 | weekly-journal-brief | 2026-07-27 | live | 402 | none |
| RUN-03 | monthly-report | 2026-08-03 |  | 0 | MISSING_TAIL_MERGE |
| RUN-25 | weekly-journal-brief | 2026-08-03 | live | 500 | ROW_COUNT_MISMATCH |
| RUN-26 | weekly-journal-brief | 2026-08-10 | live | 420 | none |
| RUN-30 | weekly-journal-brief | 2026-08-15 | live | 450 | none |
| RUN-20 | weekly-journal-brief | 2026-08-17 | live | 375 | none |
| RUN-31 | weekly-journal-brief | 2026-08-22 | live | 0 | none |
| RUN-36 | weekly-journal-brief | 2026-08-24 | live | 441 | ROW_COUNT_MISMATCH |
| RUN-28 | monthly-report | 2026-09-03 | live | 600 | none |
| RUN-08 | monthly-report | 2026-09-07 | live | 380 | none |
| RUN-15 | monthly-report | 2026-10-05 | live | 395 | none |
| RUN-34 | monthly-report | 2026-10-05 | live | 700 | none |
| RUN-19 | monthly-report | 2026-11-02 | live | 410 | ROW_COUNT_MISMATCH |

## Duplicate collapse - finding precedence

RUN-29 appears twice on 2026-06-20: finding-precedence keeps the live row because it used live instead of archive required on or before the cutover (`SOURCE_MISMATCH`); the compliant archive duplicate is dropped.

RUN-35 appears twice on 2026-07-20: the archive row used archive but should have used live after the cutover (`SOURCE_MISMATCH`), while the live duplicate is `none`. Non-`none` finding precedence keeps the archive/`SOURCE_MISMATCH` row and drops the live/`none` duplicate (live preference only applies when findings tie).

RUN-37 appears twice on 2026-07-14: archive carries `SOURCE_MISMATCH` and live carries `ROW_COUNT_MISMATCH` (reported 456 against snapshot 455). Both are non-`none`, so the live row is kept — `ROW_COUNT_MISMATCH`.

RUN-38 appears twice on 2026-06-22: archive reported 301 against snapshot 300 (`ROW_COUNT_MISMATCH`) while live used live instead of archive required on or before the cutover (`SOURCE_MISMATCH`). Both findings are non-`none`, so live preference keeps the live/`SOURCE_MISMATCH` row (reported 300) rather than the archive row-count finding.

## Inclusive cutover - runs on 2026-07-06

The cutover rule is inclusive: on or before 2026-07-06 uses archive; after uses live. RUN-05 and RUN-22 correctly used archive on the cutover date (`none`). RUN-11 (monthly, archive on the cutover date) is also `none`. RUN-10 used live on the cutover date - premature - so `SOURCE_MISMATCH` (live used, archive required).

## Pre-cutover live mismatches

RUN-13 and RUN-24 both ran on 2026-07-05 using live. Archive was required on or before 2026-07-06, so both are `SOURCE_MISMATCH` (live used, archive required). RUN-29 and RUN-38's kept live rows are likewise pre-cutover `SOURCE_MISMATCH` (live used, archive required).

## Post-cutover archive mismatches

RUN-17 and RUN-23 both ran on 2026-07-07 using archive; live was required after 2026-07-06: `SOURCE_MISMATCH` (archive used, live required). RUN-18 on the same date correctly used live (`none`). RUN-33 ran on 2026-07-08 still on archive - also `SOURCE_MISMATCH` (archive used, live required). RUN-35's kept archive row on 2026-07-20 is likewise `SOURCE_MISMATCH` (archive used, live required).

## Empty-snapshot and zero-count compliant runs

RUN-20 and RUN-30 correctly used live after cutover with an empty `source_row_count_snapshot`, so the row-count rule does not apply (`none`). RUN-31 reported 0 with snapshot 0 - counts match (`none`).

## Monthly edge cases

RUN-21 is a monthly report on the cutover date using live. The weekly cutover rule does not apply to monthly-report jobs, and the tail-merge rule applies only to the first post-cutover monthly report, so RUN-21 is `none`. RUN-03 (2026-08-03) is that first post-cutover monthly report, with empty source and zero rows - the archive tail merge was skipped: `MISSING_TAIL_MERGE`. Later monthly reports (RUN-08, RUN-15, RUN-28, RUN-34) need no tail merge and are `none` when source/count rules pass.

## Row-count mismatches

RUN-02 used live correctly but reported 388 against snapshot 395: `ROW_COUNT_MISMATCH`. RUN-25 used live correctly but reported 500 against snapshot 450: `ROW_COUNT_MISMATCH`. RUN-19 used live correctly but reported 410 against snapshot 405: `ROW_COUNT_MISMATCH`. RUN-36 used live correctly but reported 441 against snapshot 440 (off-by-one): `ROW_COUNT_MISMATCH`. RUN-37's kept live row reported 456 against snapshot 455: `ROW_COUNT_MISMATCH`. (RUN-38's archive duplicate had 301 vs 300, but that row is dropped by live-source precedence when both duplicates are non-`none`.)

## Missing required job - week-ahead-briefing

No run is logged for this job, but it is on the required recurring roster (weekly-journal-brief, week-ahead-briefing, monthly-report). That is `MISSING_JOB`.
