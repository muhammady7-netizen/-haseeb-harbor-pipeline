repeat-01..03 are distinct harbor oracle trials (different trial ids). None is a byte-copy of evaluations/oracle.
