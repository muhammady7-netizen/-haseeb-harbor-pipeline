# Recurring report source-selection audit memo (REPORTING-OPS-2)

This memo audits every logged run of the recurring reporting pipeline against the weekly source-cutover rule, the row-count-consistency rule, the monthly tail-merge rule, and the required-recurring-job check. The audit produced 32 CSV rows (31 unique logged runs plus one `MISSING_JOB` row), of which 15 carry a finding other than `none`: 8 `SOURCE_MISMATCH`, 5 `ROW_COUNT_MISMATCH`, 1 `MISSING_TAIL_MERGE`, and 1 `MISSING_JOB`. Where the run log listed the same `run_id` more than once, the row kept in the audit CSV was chosen by finding-precedence (a non-`none` finding beats `none`; on a tie the `live` source row beats the `archive` source row), and the reasoning below refers to the kept row.

## SOURCE_MISMATCH findings (weekly source cutover)

RUN-10 is a `weekly-journal-brief` run dated 2026-07-06 that used the `live` source, but because the run date is on or before the 2026-07-06 cutover it should have used `archive` instead; expected `archive`, used `live`.

RUN-13 is a `weekly-journal-brief` run dated 2026-07-05 that used `live`, but should have used `archive` instead because the date is before the cutover; expected `archive`, used `live`.

RUN-17 is a `weekly-journal-brief` run dated 2026-07-07 that used `archive`, but should have used `live` instead because the date is after the 2026-07-06 cutover; expected `live`, used `archive`.

RUN-23 is a `weekly-journal-brief` run dated 2026-07-07 that used `archive`, but should have used `live` instead because the date is after the cutover; expected `live`, used `archive`.

RUN-24 is a `weekly-journal-brief` run dated 2026-07-05 that used `live`, but should have used `archive` instead because the date is on or before the cutover; expected `archive`, used `live`.

RUN-29 is a `weekly-journal-brief` run dated 2026-06-20 whose kept row used `live`, but should have used `archive` instead because the date is before the cutover; expected `archive`, used `live`. The run was logged twice with the same `run_id` (an `archive`/`none` row and a `live`/`SOURCE_MISMATCH` row), and the `live` row's `SOURCE_MISMATCH` was kept because a non-`none` finding beats `none`.

RUN-33 is a `weekly-journal-brief` run dated 2026-07-08 that used `archive`, but should have used `live` instead because the date is after the cutover; expected `live`, used `archive`.

RUN-35 is a `weekly-journal-brief` run dated 2026-07-20 whose kept row used `archive`, but should have used `live` instead because the date is after the cutover; expected `live`, used `archive`. The run was logged twice with the same `run_id` (an `archive`/`SOURCE_MISMATCH` row and a `live`/`none` row), and the `archive` row's `SOURCE_MISMATCH` was kept because a non-`none` finding wins over the `live` preference.

## ROW_COUNT_MISMATCH findings (row-count consistency)

RUN-02 is a `weekly-journal-brief` run dated 2026-07-13 that reported a row count of 388, but because the `source_row_count_snapshot` was 395 the reported count does not match the expected snapshot; reported 388 instead of 395.

RUN-19 is a `monthly-report` run dated 2026-11-02 that reported 410, but because the snapshot was 405 the reported count does not match the expected snapshot; reported 410 instead of 405.

RUN-25 is a `weekly-journal-brief` run dated 2026-08-03 that reported 500, but because the snapshot was 450 the reported count does not match the expected snapshot; reported 500 instead of 450.

RUN-36 is a `weekly-journal-brief` run dated 2026-08-24 that reported 441, but because the snapshot was 440 the reported count does not match the expected snapshot; reported 441 instead of 440.

RUN-37 is a `weekly-journal-brief` run dated 2026-07-14 whose kept row reported 456, but because the snapshot was 455 the reported count does not match the expected snapshot; reported 456 instead of 455. The run was logged twice with the same `run_id` (an `archive`/`SOURCE_MISMATCH` row and a `live`/`ROW_COUNT_MISMATCH` row); both findings are non-`none` so the tie was broken in favor of the `live` row, keeping `ROW_COUNT_MISMATCH`.

## MISSING_TAIL_MERGE finding (monthly tail merge)

RUN-03 is a `monthly-report` run dated 2026-08-03, which is the first monthly report generated after the 2026-07-06 cutover, so it should have merged in the archive source's tail days (the days between the start of that month and the cutover) before synthesizing the month's weekly briefs. Instead the run reported 0 rows with an empty source, showing that the tail merge was skipped, so it is flagged `MISSING_TAIL_MERGE`. Later monthly reports do not need a tail merge and were not flagged on this rule.

## MISSING_JOB finding (required recurring jobs)

The required recurring roster is `weekly-journal-brief`, `week-ahead-briefing`, and `monthly-report`. `weekly-journal-brief` and `monthly-report` each have logged runs, but `week-ahead-briefing` has no run logged at all, so it is flagged `MISSING_JOB` and appears as an extra audit row with empty `run_id`, empty `run_date`, empty `source_used`, and `reported_row_count` of 0.

## Summary counts

- flagged_count: 15
- source_mismatch_count: 8
- row_count_mismatch_count: 5
- missing_tail_merge_count: 1
- missing_job_count: 1
RUN-38 used live instead of archive before the cutover, so it is a source mismatch (live used, archive required).
