# Report source-selection audit memo

This memo audits every logged run of the recurring reporting pipeline against
the source-selection standard (REPORTING-OPS-2): the weekly source-cutover
rule, the row-count-consistency rule, and the monthly tail-merge rule, plus a
separate check that every required recurring job has at least one run logged.
The audit CSV collapses duplicate run IDs by finding-precedence (a non-`none`
finding beats `none`; on a tie the `live`-source row beats the `archive`-source
row) and adds one `MISSING_JOB` row per roster job with no logged run. Of the 32
audit rows, 15 carry a finding and 17 are compliant (`none`): 8
`SOURCE_MISMATCH`, 5 `ROW_COUNT_MISMATCH`, 1 `MISSING_TAIL_MERGE`, and 1
`MISSING_JOB`.

## SOURCE_MISMATCH (weekly source-cutover rule)

Weekly-journal-brief and week-ahead-briefing runs must pull from `archive` for
any run date on or before the 2026-07-06 cutover and from `live` for any date
after it; the cutover date itself is still `archive`. A run whose recorded
source disagrees is `SOURCE_MISMATCH`.

- RUN-10 is a weekly-journal-brief run dated 2026-07-06 that used the `live`
  source, but because the cutover date itself is still `archive`, it should have
  used `archive` instead.
- RUN-13 is a weekly-journal-brief run dated 2026-07-05 that used `live`, but
  because 2026-07-05 is on or before the cutover, it should have used `archive`
  instead.
- RUN-17 is a weekly-journal-brief run dated 2026-07-07 that used `archive`, but
  because 2026-07-07 is after the cutover, the expected source was `live`
  instead.
- RUN-23 is a weekly-journal-brief run dated 2026-07-07 that used `archive`, but
  because that date is after the cutover, it should have used `live` instead.
- RUN-24 is a weekly-journal-brief run dated 2026-07-05 that used `live`, but
  because that date is on or before the cutover, it should have used `archive`
  instead.
- RUN-29 is a weekly-journal-brief run dated 2026-06-20 that appears twice in the
  log (`archive` and `live`); the collapsed audit row keeps the `live` row, which
  used `live`, but because 2026-06-20 is before the cutover it should have used
  `archive` instead.
- RUN-33 is a weekly-journal-brief run dated 2026-07-08 that used `archive`, but
  because that date is after the cutover, it should have used `live` instead.
- RUN-35 is a weekly-journal-brief run dated 2026-07-20 that appears twice in the
  log (`archive` and `live`); the collapsed audit row keeps the `archive` row
  (its `SOURCE_MISMATCH` beats the `none` on the `live` duplicate), and that row
  used `archive`, but because 2026-07-20 is after the cutover it should have used
  `live` instead.

## ROW_COUNT_MISMATCH (row-count-consistency rule)

Where the run log's `source_row_count_snapshot` is present, the run's
`reported_row_count` must equal the snapshot count; otherwise it is
`ROW_COUNT_MISMATCH`.

- RUN-02 is a weekly-journal-brief run that reported a row count of 388, but the
  snapshot for the source used was 395, so the reported count does not match the
  snapshot.
- RUN-19 is a monthly-report run that reported 410 rows, but the snapshot was
  405, so the reported count exceeds the snapshot count.
- RUN-25 is a weekly-journal-brief run that reported 500 rows against a snapshot
  of 450, so the reported count does not match the snapshot.
- RUN-36 is a weekly-journal-brief run that reported 441 rows, but the snapshot
  was 440, so the reported count does not equal the snapshot count.
- RUN-37 is a weekly-journal-brief run dated 2026-07-14 that appears twice in the
  log; the collapsed audit row keeps the `live` row (its `ROW_COUNT_MISMATCH`
  ties the `archive` duplicate's `SOURCE_MISMATCH`, so `live` wins), and that row
  reported 456 rows against a snapshot of 455, so the reported count does not
  match the snapshot.

## MISSING_TAIL_MERGE (monthly tail-merge rule)

The first monthly report generated after the 2026-07-06 cutover must merge in
the archive source's tail days before synthesizing the month's weekly briefs;
one that skipped this is `MISSING_TAIL_MERGE`. Later monthly reports do not need
a tail merge.

- RUN-03 is a monthly-report run dated 2026-08-03, which is the first monthly
  report generated after the cutover, so it should have merged in the archive
  tail days; instead it logged an empty source with zero reported rows, which
  means it skipped the required tail merge.

## MISSING_JOB (required recurring jobs)

Every job on the required recurring roster (weekly-journal-brief,
week-ahead-briefing, monthly-report) must have at least one run logged; a job
with no run at all is `MISSING_JOB`.

- `week-ahead-briefing` is on the required recurring roster, but no run is
  logged for it at all, so it is a missing job. (The other two roster jobs,
  weekly-journal-brief and monthly-report, each have logged runs.)

## Summary of counts

- `flagged_count` (rows whose finding is not `none`): 15
- `source_mismatch_count`: 8
- `row_count_mismatch_count`: 5
- `missing_tail_merge_count`: 1
- `missing_job_count`: 1
