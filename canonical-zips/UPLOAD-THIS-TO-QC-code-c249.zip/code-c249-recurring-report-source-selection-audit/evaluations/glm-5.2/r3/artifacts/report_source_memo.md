# Report source-selection audit memo

This memo explains every finding from the recurring reporting pipeline source-selection audit against standard REPORTING-OPS-2. The audit applies the weekly source-cutover rule, the row-count-consistency rule, the monthly tail-merge rule, and the required-recurring-job rule to every logged run; collapses duplicate run IDs by finding-precedence (non-`none` beats `none`, and on a tie the `live` source row beats the `archive` source row); and adds a `MISSING_JOB` row for any required job with no logged run. Fifteen rows were flagged in total.

## Source mismatches (SOURCE_MISMATCH)

RUN-10 is a weekly-journal-brief run dated 2026-07-06 that used the `live` source, but because that date is on or before the 2026-07-06 cutover it should have used `archive` instead, so the recorded source does not match the weekly cutover rule.

RUN-13 is a weekly-journal-brief run dated 2026-07-05 that used `live`, but because the date is on or before the 2026-07-06 cutover it should have used `archive` instead.

RUN-17 is a weekly-journal-brief run dated 2026-07-07 that used `archive`, but because the date is after the 2026-07-06 cutover it should have used `live` instead.

RUN-23 is a weekly-journal-brief run dated 2026-07-07 that used `archive`, but because the date is after the 2026-07-06 cutover it should have used `live` instead.

RUN-24 is a weekly-journal-brief run dated 2026-07-05 that used `live`, but because the date is on or before the 2026-07-06 cutover it should have used `archive` instead.

RUN-29 is a weekly-journal-brief run dated 2026-06-20 whose log carried two rows for the same run ID; the `live` row was kept over the compliant `archive` row by finding-precedence, and that kept row used `live`, but because the date is on or before the 2026-07-06 cutover it should have used `archive` instead.

RUN-33 is a weekly-journal-brief run dated 2026-07-08 that used `archive`, but because the date is after the 2026-07-06 cutover it should have used `live` instead.

RUN-35 is a weekly-journal-brief run dated 2026-07-20 whose log carried two rows for the same run ID; the `archive` row was kept over the compliant `live` row because a non-`none` finding beats the live-source preference, and that kept row used `archive`, but because the date is after the 2026-07-06 cutover it should have used `live` instead.

## Row-count mismatches (ROW_COUNT_MISMATCH)

RUN-02 is a weekly-journal-brief run that reported 388 rows, but the pipeline's own `source_row_count_snapshot` was 395, so the reported count does not equal the expected snapshot count.

RUN-19 is a monthly-report run that reported 410 rows, but the `source_row_count_snapshot` was 405, so reported does not equal expected.

RUN-25 is a weekly-journal-brief run that reported 500 rows, but the `source_row_count_snapshot` was 450, so reported does not equal expected.

RUN-36 is a weekly-journal-brief run that reported 441 rows, but the `source_row_count_snapshot` was 440, so reported does not equal expected.

RUN-37 is a weekly-journal-brief run whose log carried two rows for the same run ID; the `live` row was kept by finding-precedence (its `ROW_COUNT_MISMATCH` tied the `archive` row's `SOURCE_MISMATCH`, and live wins ties), and that kept row reported 456 rows while the `source_row_count_snapshot` was 455, so reported does not equal expected.

## Missing tail merge (MISSING_TAIL_MERGE)

RUN-03 is the monthly-report run dated 2026-08-03, which is the first monthly report generated after the 2026-07-06 cutover, so it was expected to merge in the archive source's tail days (the July days from 2026-07-01 through the cutover) before synthesizing the month's weekly briefs; instead it used no source and reported 0 rows, skipping the tail merge.

## Missing required job (MISSING_JOB)

week-ahead-briefing is on the required recurring roster (alongside weekly-journal-brief and monthly-report), but no run for that job appears in the run log at all, so it is a missing job and was emitted as an extra `MISSING_JOB` row with empty `run_id`, empty `run_date`, empty `source_used`, and `reported_row_count` 0.

## Summary counts

- flagged_count: 15
- source_mismatch_count: 8
- row_count_mismatch_count: 5
- missing_tail_merge_count: 1
- missing_job_count: 1
