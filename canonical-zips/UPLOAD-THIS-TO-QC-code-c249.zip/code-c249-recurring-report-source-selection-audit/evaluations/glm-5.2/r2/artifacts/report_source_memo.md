# Report source-selection audit memo

This memo explains every finding from the recurring reporting pipeline source-selection audit against standard REPORTING-OPS-2. The companion file `report_source_audit.csv` carries one row per unique run (collapsed by finding-precedence when a run_id appears more than once) plus one row for each required recurring job with no logged run.

## Source mismatches (SOURCE_MISMATCH)

The weekly cutover rule requires weekly-journal-brief runs dated on or before 2026-07-06 to pull from `archive` and runs dated after 2026-07-06 to pull from `live`; a run whose recorded source disagrees for its own run date is SOURCE_MISMATCH.

RUN-10 is flagged because it ran on 2026-07-06 and used `live` instead of the expected `archive` (the cutover date itself is still archive). RUN-13 is flagged because it ran on 2026-07-05 and used `live` where it should have used `archive`. RUN-24 is flagged because it ran on 2026-07-05 and used `live` where `archive` was expected. RUN-17 is flagged because it ran on 2026-07-07 and used `archive` when `live` was expected for any date after the cutover. RUN-23 is flagged because it ran on 2026-07-07 and used `archive` instead of the expected `live`. RUN-33 is flagged because it ran on 2026-07-08 and used `archive` instead of `live`. RUN-29 is flagged because the run_id appears twice on 2026-06-20 and the kept row used `live` where `archive` should have been used (the duplicate archive row was compliant, but the live row's SOURCE_MISMATCH is retained because a non-`none` finding wins over `none`). RUN-35 is flagged because the run_id appears twice on 2026-07-20 and the kept row used `archive` where `live` should have been used (the duplicate live row was compliant, but the archive row's SOURCE_MISMATCH is retained because a finding wins over the live preference when only one side is non-`none`).

## Row-count mismatches (ROW_COUNT_MISMATCH)

The row-count rule requires `reported_row_count` to equal `source_row_count_snapshot` whenever a snapshot is present (non-empty); a divergence is ROW_COUNT_MISMATCH.

RUN-02 is flagged because it reported 388 rows while its snapshot recorded 395. RUN-25 is flagged because it reported 500 rows while the snapshot recorded 450. RUN-36 is flagged because it reported 441 rows against a snapshot of 440. RUN-19 is flagged because it reported 410 rows against a snapshot of 405. RUN-37 is flagged because the run_id appears twice on 2026-07-14 and the kept (live) row reported 456 rows against a snapshot of 455 (both duplicate rows carried non-`none` findings, so the live row was retained by precedence and its row-count divergence is reported).

## Missing tail merge (MISSING_TAIL_MERGE)

The monthly tail-merge rule requires the first monthly report generated after the 2026-07-06 cutover to merge the archive source's tail days (the days between the start of that month and the cutover) before synthesizing the month's weekly briefs; later monthly reports do not need a tail merge. RUN-03 is flagged because it is the first monthly report generated after the cutover (run date 2026-08-03) and it reported an empty `source_used` with 0 reported rows, so it skipped the required archive tail merge instead of merging it before synthesis. (Monthly reports dated on the cutover, RUN-11 and RUN-21, are not "after" the cutover and are not subject to the tail-merge requirement.)

## Missing required job (MISSING_JOB)

The required recurring roster lists weekly-journal-brief, week-ahead-briefing, and monthly-report, and each must have at least one run logged. The week-ahead-briefing job has no run logged at all, so it is flagged MISSING_JOB. (weekly-journal-brief and monthly-report each have logged runs.)
