# code-c249-recurring-report-source-selection-audit

Non-connector Harbor task. Audit a recurring reporting pipeline's logged runs against the source-selection standard (REPORTING-OPS-2).

## Deliverables

- `report_source_audit.csv` - one row per unique run_id (finding-precedence de-dupe) plus any missing required job, with a `finding` column
- `report_source_memo.md` - markdown memo explaining every finding
- `results.json` - `flagged_count`, `source_mismatch_count`, `row_count_mismatch_count`, `missing_tail_merge_count`, `missing_job_count`

## Inputs

- `input/report_source_standard.md` - the binding standard (cutover 2026-07-06, row-count, tail-merge, required-jobs, audit deliverable shape / ordered finding-precedence)
- `input/report_run_log.csv` - 34 logged rows (31 unique run_ids after de-dupe of RUN-29/RUN-35/RUN-37) with `source_row_count_snapshot`

## Verifier

59 graded pytest checks: 57 deterministic assertions in `tests/verifier.json` (file existence, 31 unique-run finding rows + missing-job row with quote-tolerant empty `run_id`, `audit_exactly_32_rows`, proximity+prose memo checks including densify traps RUN-35/36/37, five `results.json` equals checks) plus 2 field-level DictReader checks in `tests/test_outputs.py` that the audit identifying columns (`job_name`, `run_date`, `source_used`, `reported_row_count`) match the de-duplicated run log and that the `MISSING_JOB` row has empty `run_id`/`run_date`/`source_used` with `reported_row_count=0`. Fractional reward via pytest passed/total.

Densify notes (post GLM 4/4 @ 1.0): ordered finding-precedence traps (archive-finding beats live-none; dual non-none keeps live), off-by-one row-count, and memo evidence binding for the new flagged runs. Expected results `15/8/5/1/1`.
