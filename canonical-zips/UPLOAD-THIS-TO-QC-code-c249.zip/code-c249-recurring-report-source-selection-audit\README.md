# code-c249-recurring-report-source-selection-audit

Non-connector Harbor task. Audit a recurring reporting pipeline's logged runs against the source-selection standard (REPORTING-OPS-2).

## Deliverables

- `report_source_audit.csv` - one row per unique run_id (finding-precedence de-dupe) plus any missing required job, with a `finding` column
- `report_source_memo.md` - markdown memo explaining every finding
- `results.json` - `flagged_count`, `source_mismatch_count`, `row_count_mismatch_count`, `missing_tail_merge_count`, `missing_job_count`

## Inputs

- `input/report_source_standard.md` - the binding standard (cutover 2026-07-06, row-count, tail-merge, required-jobs, audit deliverable shape)
- `input/report_run_log.csv` - 29 logged rows (28 unique run_ids; RUN-29 duplicated) with `source_row_count_snapshot`

## Verifier

51 deterministic checks in `tests/verifier.json`: file existence, 28 unique-run finding rows + missing-job row, `audit_exactly_29_rows` (exact header + 29 newline-terminated data rows), memo content checks, and five `results.json` equals checks. Fractional reward via pytest passed/total.
