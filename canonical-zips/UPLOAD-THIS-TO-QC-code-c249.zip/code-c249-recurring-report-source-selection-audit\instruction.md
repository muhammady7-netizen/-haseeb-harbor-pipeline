# Task

Audit this recurring reporting pipeline's logged runs against our source-selection standard. For every run, apply the weekly source-cutover rule, the row-count-consistency rule and the monthly tail-merge rule, and separately confirm every required recurring job has at least one run logged. Save `report_source_audit.csv` with one row per unique run (plus any missing required job) carrying the run's identifying columns from the log (`run_id`, `job_name`, `run_date`, `source_used`, `reported_row_count`) and a final `finding` column using the standard's finding names, `none` where compliant. Then write `report_source_memo.md` explaining every finding, citing the run ID and the specific reason for each finding (for source mismatches, what source was used and what should have been used; for row-count mismatches, the reported count and the snapshot count). The `flagged_count` in `results.json` is the number of rows whose finding is not `none` (i.e. the count of all rows with a finding other than `none`).

## Memo explanation style (graded)

For each flagged finding, put the run ID (or missing job name) and the key evidence tokens in the **same short prose window** (roughly the same paragraph / within a few hundred characters)—not scattered as a bare token list across the file. Use explanatory connective wording such as *because*, *used*, *should*, *instead*, *expected*, or *reported*. Token-only dumps without that connective prose do not satisfy the memo checks.

## Audit CSV representation (graded)

- Emit **exactly one audit row per unique `run_id`**. When the run log contains multiple rows with the same `run_id`, collapse them using **finding-precedence** in this order: (1) prefer a non-`none` finding over `none`; (2) only when that preference ties, prefer the `live` source row over the `archive` source row. Examples of the ordered rule: archive/`none` + live/`SOURCE_MISMATCH` keeps live/`SOURCE_MISMATCH`; archive/`SOURCE_MISMATCH` + live/`none` keeps archive/`SOURCE_MISMATCH` (finding wins over live preference); archive/`SOURCE_MISMATCH` + live/`ROW_COUNT_MISMATCH` keeps live/`ROW_COUNT_MISMATCH` (findings tie, live wins).
- Also emit **one extra row** for each required recurring job that has no logged run at all (`MISSING_JOB`).
- For a `MISSING_JOB` row: leave `run_id`, `run_date`, and `source_used` empty; set `reported_row_count` to `0`; set `job_name` to the missing roster job name; set `finding` to `MISSING_JOB`.
- Write the CSV with **exactly this unquoted header line** (no spaces around commas):
  `run_id,job_name,run_date,source_used,reported_row_count,finding`
- End every data row, including the last, with a newline. Do not add extra columns (do not retain `source_row_count_snapshot` in the audit CSV).

---
The attachments are provided read-only at: `input/report_source_standard.md`; `input/report_run_log.csv`. Read them there.
Save your deliverables into your current working directory using exactly these filenames:
    - `report_source_audit.csv` - Per-run source-selection audit
    - `report_source_memo.md` - Markdown source-selection audit memo
    - `results.json` - a JSON object with the keys `flagged_count`, `source_mismatch_count`, `row_count_mismatch_count`, `missing_tail_merge_count`, `missing_job_count` (JSON numbers: `flagged_count` = rows whose finding is not `none`; the other four keys count rows whose finding equals that finding name)
Writing those files is the required deliverable and must be your final action; confirm each one exists before you answer.

---

## Working environment

- Your current working directory is `/app`, and it is writable.
- The read-only attachments referred to as `input/` are at `/app/input`.
- Write every deliverable into `/app`, at the exact filenames listed above.
