Distinct harbor oracle trials (oracle + 3 stability) on densified 59-check pack.
