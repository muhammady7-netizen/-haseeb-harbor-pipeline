# Revolving facility agreement — interest and fees (extract)

All amounts are in pounds sterling. This extract is authoritative for what is payable. Round
every amount to the **nearest penny, half up**.

Total Commitments under the facility are **20,000,000**.

## 1. Calculation of interest

Interest on each Loan is calculated on the **actual number of days elapsed** and on a year of
**365 days**:

    interest = principal x (Base Rate + Margin) / 100 x days / 365

A year of 360 days is **not** used for any Loan under this facility, in any currency.

## 2. Interest periods and business days

An Interest Period runs **from and including its first day to but excluding its last day**, so
the number of days charged is the number of days between the two.

**Business Day** means any day other than a Saturday or a Sunday.

Where the last day of an Interest Period would fall on a day that is **not** a Business Day,
that last day is moved to the **next** Business Day — the **modified following** convention —
**unless** that would take it into the next calendar month, in which case it is moved to the
**preceding** Business Day instead. The Interest Period is **lengthened or shortened
accordingly** and interest is charged for the days actually elapsed.

An Interest Period that runs a day or two longer than the calendar suggests is therefore not
on its face an error. Check the day of the week of the scheduled last day before disputing it.

## 3. The Margin and the ratchet

The Margin is set by reference to the **Leverage Ratio** in the most recent Compliance
Certificate **delivered to the Agent**:

| Leverage Ratio | Margin |
|---|---|
| 3.00x or higher | 2.75% |
| 2.50x or higher | 2.25% |
| 2.00x or higher | 1.75% |
| below 2.00x | 1.50% |

The rows are read in the order shown and the **first** row whose threshold the Leverage Ratio
meets is the one that applies.

A change in the Margin takes effect on the **first day of the next Interest Period beginning
after the Compliance Certificate is delivered**. It does **not** take effect from the quarter
end to which the certificate relates, and it does **not** take effect part-way through an
Interest Period that has already begun. An Interest Period that began before delivery runs to
its end on the old Margin.

## 4. Commitment fee

A commitment fee accrues at **35% of the applicable
Margin** on the **undrawn amount of the Total Commitments** — that is, on the Total Commitments
**less** the Loans outstanding — for each day of the fee period, on the same day-count basis as
interest.

The fee is **not** charged on the Total Commitments. Charging it on the whole facility charges
the Borrower twice for the drawn part, which is already carrying interest.

## 5. Utilisation fee

A utilisation fee accrues at **0.10% a year on the aggregate of the Loans
outstanding**, for each day on which those Loans **exceed
50% of the Total Commitments**, on the same day-count basis as interest.

The utilisation fee is payable **in addition to** the commitment fee and to interest. It is the
Borrower's obligation whether or not the Agent invoices it, and an amount that should have been
charged and was not is part of the reconciliation.

## 6. Scope of this review

The commitment fee and the utilisation fee are payable quarterly in arrears. Only the fees for
the **first fee period, 4 January 2022 to 4 April 2022**, have been invoiced so far. This
review covers the attached invoices and any amount that should have been invoiced **for that
same fee period**; later fee periods are outside it.

## 7. Reporting

For every invoice line, report the amount charged, the amount properly due and the difference,
stated as **amount charged less amount due**, so that an **overcharge is positive**. Include a
line for any amount that should have been charged and was not; its difference is negative.
Report the total interest due, the total fees due, the net adjustment, and how many invoice
lines you are disputing and how many you are confirming.
