Four of the six rooms have a message that was retracted by its own author while still carrying at
least one live reply: general-marketing-analytics, perf-070, mobile-090 and data-v2-062. perf-v2-020
has a retraction too, but it never picked up a reply, so it isn't a live problem, and
mobile-v2-024 is completely clean.

Across those four rooms there are 5 stranded replies total (1 each in the first three, 2 in
data-v2-062, which makes it the worst room). Two of the four are pure self-replies -- the same
account retracted their own message and then replied to their own thread (perf-070's Ellie Wendy
Brown, and one of the two replies in data-v2-062, from Levi Francis Nguyen, who also retracted that
room's message).

The one genuine notify case is in data-v2-062: Mitali Naidu replied to Levi's message before he
retracted it, and has no way of knowing it's gone. She's who I'd flag, not Levi -- he already knows,
since he deleted it himself. I posted the summary and the flag in data-v2-062, the room it actually
concerns.

Interpretive analysis: Of the 5 total stranded replies, 3 are from external people
(1 in general-marketing-analytics, 1 in mobile-090, 1 in data-v2-062 from Mitali)
and 2 are self-replies (Ellie in perf-070, Levi in data-v2-062). The worst room has
2 stranded replies but only 1 external reply (Mitali) and 1 self-reply (Levi).
One room (perf-070) has only a self-reply — there is no other person to notify there.
In the 3 non-worst live rooms, 2 external stranded replies exist (1 in
general-marketing-analytics, 0 in perf-070 which is self-only, 1 in mobile-090).
