# System Prompt
You are a careful task-execution agent. Use the tools provided by the configured gym or gyms to complete the user's task. Base conclusions on retrieved evidence, do not invent records or identifiers, and return the requested result in the requested format.

# Task
Someone on the data governance side asked me to check something before it becomes a bigger cleanup
job: are there threads in our rooms where the original message got retracted by whoever posted it,
but people had already replied to it before that happened? Those replies are still sitting there,
attached to a message that technically isn't part of the record anymore.

Six rooms are mine to check: general-marketing-analytics, perf-070, mobile-090, data-v2-062,
perf-v2-020 and mobile-v2-024. For each one, look at every message that has at least one reply and
check whether that specific message was later retracted by its own author. Don't assume a room is
clean just because nothing looks unusual in the channel view - a retraction is a flag on the
message record itself, not a change in what gets displayed, so you have to actually open every
thread with a reply and look.

A room only counts as having a live problem if a message that was retracted there still has at
least one reply attached to it. A retraction with no replies isn't a live problem for anyone - it's
just someone deleting their own message and nothing else happened, and it should not be counted
the same way. If a room has more than one retracted message, check each one separately - only the
ones that actually have replies count.

Across the rooms that do have this problem, add up how many replies in total are now attached to a
retracted message. Then find the single worst room - the one with the most such replies - and
figure out, in that room specifically, who should actually be told their reply is hanging off a
retracted message. Don't tell me to notify the person who retracted the message themselves - they
already know. I want the other person, if there is one.

Write the numbers to `/workspace/metrics.json` as plain numbers, and the two identifiers as plain
strings, under exactly these keys: channels_with_live_orphaned_threads, total_stranded_replies,
worst_channel_id, worst_channel_stranded_reply_count, notify_candidate_id, notify_candidate_name.
- `retracted_msg_author_also_replied` (boolean): whether the person who retracted the message in the worst room also left a reply on that same thread. A self-reply means they already know about the thread — they do not need to be notified.
- `worst_room_has_self_reply` (boolean): whether the worst room's orphaned thread has a reply from the same person who retracted the original message, alongside at least one reply from a different person. This is what makes the notify question meaningful — there is someone other than the retractor who needs telling.
- `notify_candidate_is_not_retractor` (boolean): whether the person you identified to notify is someone OTHER than the person who retracted the original message. The person who retracted already knows — you want the other person, if there is one.
- `total_retractions_with_replies` (number): across all six rooms, how many retracted messages have at least one reply attached. This is not the same as the number of rooms with a live problem — a single room can have more than one retracted message, and only the ones with replies count.
- `rooms_with_inert_retraction` (number): how many rooms have a retracted message that has zero replies attached. These are not live problems — someone deleted their own message and nothing else happened.

List every room that has this problem in `/workspace/orphaned_thread_audit.csv` - a header row,
then one row per room, with exactly these columns in this order: channel_id, channel_name,
retracted_message_author_id, retracted_message_author_name, stranded_reply_count.

Then post one message - in the single worst room only, nowhere else - laying out what you found,
and end the message with exactly these two lines, filled in:
  orphaned: <how many rooms have this problem>
  notify: <the real name of the person who should be told>

Give me your conclusion and the evidence for it in your final reply.
