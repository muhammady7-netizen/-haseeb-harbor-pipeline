# Connector task
