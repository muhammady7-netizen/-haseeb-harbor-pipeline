# the-thread-that-outlived-its-own-start

## Task Summary
Find threads in six Slack rooms where the original message got retracted by its author, but people had already replied to it before that happened. Those replies are still sitting there attached to a message that is no longer part of the record.

## Connector
- **Gym:** slack-gym (container port 8008, streamable-http)
- **User:** Vishal Desai Pawar (UVS1ZHNER2I5), Software Engineer
- **Rooms:** general-marketing-analytics, perf-070, mobile-090, data-v2-062, perf-v2-020, mobile-v2-024

## Golden Answers
| Key | Value |
|---|---|
| channels_with_live_orphaned_threads | 4 |
| total_stranded_replies | 5 |
| worst_channel_id | CN20Z0W91YE0 |
| worst_channel_stranded_reply_count | 2 |
| notify_candidate_id | UNN2VSEY3JSW |
| notify_candidate_name | Mitali Naidu |

## Central Trap
- Retraction with no replies is NOT a problem (perf-v2-020 has one, but it's not a live issue)
- data-v2-062 has TWO retracted messages: one with 0 replies (non-event) and one with 2 replies (real problem)
- Self-replies don't need notifying (the person who retracted their own message and replied to it already knows)
- The notify candidate is Mitali Naidu — the OTHER reply author in the worst room, NOT Levi Francis Nguyen who retracted the message

## Verifiers (16 total)
- 7 file_check verifiers (metrics.json fields)
- 4 database_state verifiers (one message posted, correct room, no other rooms touched, seed intact)
- 1 tool_execution verifier (did real work)
- 3 rubric_check verifiers (every thread opened, notify candidate excluded retracting author, final reply conclusion)
- 1 file_check verifier (CSV header correct)

## Scoring
- sql: 0.0
- rubric: 0.4 (3 rubric checks)
- state: 0.0 (checked but not scored)
- trajectory: 0.0

## Configuration
- Agent timeout: 4800s
- Verifier timeout: 1500s
- Agent user: rlgymagent (non-root)
- JUDGE_MODEL: openai/glm-5.2
