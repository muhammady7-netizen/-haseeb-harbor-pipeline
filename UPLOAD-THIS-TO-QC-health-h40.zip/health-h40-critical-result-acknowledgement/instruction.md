# Task

Audit the critical results register against the trust's critical results procedure. Save `results_audit.csv` with the columns `result_id,tier,clock_start,notification_minutes,acknowledgement_minutes,acknowledged_by_role,escalation_status,findings` covering every result on the register, where the two minute figures are measured from the clock start you derive, `acknowledgement_minutes` is left empty where there is no acknowledgement the procedure recognises, and `findings` lists every finding against that result or records it as compliant. Then write `results_memo.md` covering the late notifications, the late or absent acknowledgements, which results should have been escalated and were not, and which long elapsed times are not breaches at all.

The `findings` column must use only these semicolon-separated category codes: `notification_late` for a late notification, `acknowledgement_late` for a late or absent acknowledgement, `acknowledger_unapproved` for an acknowledgement by a role the procedure does not recognise, `escalation_missing` for a missed acknowledgement window with no escalation on the register, or `compliant` if the result has no finding. A result may carry more than one code, separated by semicolons.

---



## Output format

Whole numbers only: write `5`, not `5.0`. The `acknowledgement_minutes` column in results_audit.csv is a whole number of minutes.


## Deliverables

Save these files in your working directory:
- `results_audit.csv`
- `results_memo.md`
- `results.json` — a JSON object with keys: `notification_breaches`, `acknowledgement_breaches`, `unapproved_acknowledgement_results`, `missing_escalation_results`, `results_compliant`
