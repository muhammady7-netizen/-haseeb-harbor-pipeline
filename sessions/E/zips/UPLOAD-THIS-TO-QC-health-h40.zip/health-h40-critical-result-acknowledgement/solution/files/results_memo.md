# CR-7 critical results audit - 56 results

29 results are clean.

## Late notifications

- **R-02** (tier 1) - notified 45 min after clock start 2026-06-15T22:10 (limit 30 min).
- **R-09** (tier 2) - notified 300 min after clock start 2026-06-15T08:30 (limit 240 min).
- **R-13** (tier 1) - notified 50 min after clock start 2026-06-15T21:00 (limit 30 min).
- **R-16** (tier 2) - notified 931 min after clock start 2026-06-15T17:59 (limit 240 min).
- **R-21** (tier 1) - notified 36 min after clock start 2026-06-17T23:59 (limit 30 min).
- **R-26** (tier 1) - notified 31 min after clock start 2026-06-17T16:00 (limit 30 min).
- **R-31** (tier 1) - notified 35 min after clock start 2026-06-20T23:00 (limit 30 min).
- **R-40** (tier 1) - notified 31 min after clock start 2026-06-23T10:00 (limit 30 min).
- **R-47** (tier 2) - notified 241 min after clock start 2026-06-24T09:00 (limit 240 min).
- **R-53** (tier 1) - notified 35 min after clock start 2026-06-25T03:00 (limit 30 min).

## Late or absent acknowledgements

- **R-03** - acknowledged at 80 min after clock start 2026-06-15T14:00.
- **R-04** - acknowledged at 90 min after clock start 2026-06-16T03:00.
- **R-06** - acknowledged at 40 min after clock start 2026-06-15T16:00.
- **R-10** - acknowledged at never min after clock start 2026-06-15T10:00.
- **R-13** - acknowledged at 90 min after clock start 2026-06-15T21:00.
- **R-15** - acknowledged at 510 min after clock start 2026-06-15T16:00.
- **R-16** - acknowledged at 1081 min after clock start 2026-06-15T17:59.
- **R-21** - acknowledged at 71 min after clock start 2026-06-17T23:59.
- **R-22** - acknowledged at 45 min after clock start 2026-06-17T14:00.
- **R-24** - acknowledged at 481 min after clock start 2026-06-17T11:00.
- **R-27** - acknowledged at 481 min after clock start 2026-06-17T17:59.
- **R-30** - acknowledged at 481 min after clock start 2026-06-21T10:00.
- **R-32** - acknowledged at 3841 min after clock start 2026-06-19T17:59.
- **R-33** - acknowledged at 490 min after clock start 2026-06-20T08:00.
- **R-35** - acknowledged at 90 min after clock start 2026-06-22T09:00.
- **R-45** - acknowledged at 61 min after clock start 2026-06-24T14:00.
- **R-49** - acknowledged at 3841 min after clock start 2026-06-20T17:59.
- **R-52** - acknowledged at 40 min after clock start 2026-06-25T15:00.
- **R-53** - acknowledged at 70 min after clock start 2026-06-25T03:00.
- **R-54** - acknowledged at 481 min after clock start 2026-06-21T17:59.
- **R-55** - acknowledged at 481 min after clock start 2026-06-22T08:00.

## Unapproved acknowledger

- **R-06** - acknowledged by ward_clerk, not on the approved list.
- **R-22** - acknowledged by nurse_hca, not on the approved list.
- **R-35** - acknowledged by phlebotomist, not on the approved list.
- **R-52** - acknowledged by healthcare_assistant, not on the approved list.
- **R-53** - acknowledged by pharmacist, not on the approved list.

## Missing escalation

- **R-04** - missed acknowledgement window, no escalation.
- **R-13** - missed acknowledgement window, no escalation.
- **R-16** - missed acknowledgement window, no escalation.
- **R-21** - missed acknowledgement window, no escalation.
- **R-30** - missed acknowledgement window, no escalation.
- **R-33** - missed acknowledgement window, no escalation.
- **R-35** - missed acknowledgement window, no escalation.
- **R-45** - missed acknowledgement window, no escalation.
- **R-53** - missed acknowledgement window, no escalation.
- **R-54** - missed acknowledgement window, no escalation.
- **R-55** - missed acknowledgement window, no escalation.

## What is not a finding

- Weekend results: core hours 08:00-18:00 apply every day.
- R-49: notification before clock started (Friday evening) counts as within window.
- R-56: escalation present but ack was on time - not required, not a finding.
- Inclusive boundaries: exactly at the window limit is within it.
