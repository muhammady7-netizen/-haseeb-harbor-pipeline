# CR-7 critical results audit — 17 results

8 results are clean. The findings on the other nine fall into four classes and
two results carry three findings each.

## Late notification (4)

- **R-02** (tier 1) — telephoned 45 minutes after its clock started, against a 30-minute window.
- **R-09** (tier 2) — telephoned 300 minutes after its clock started, against a 240-minute window.
- **R-13** (tier 1) — telephoned 50 minutes after its clock started, against a 30-minute window.
- **R-16** (tier 2) — telephoned 931 minutes after its clock started, against a 240-minute window. Released at 17:59, one minute before the 18:00 cutoff, its clock starts at release time because 17:59 is still within core hours. The notification the next morning at 09:30 is well past the window.

## Late or absent acknowledgement (7)

- **R-03** (tier 1) — acknowledged at 80 minutes against a 60-minute window.
- **R-04** (tier 1) — acknowledged at 90 minutes against a 60-minute window.
- **R-06** (tier 1) — no valid acknowledgement is recorded.
- **R-10** (tier 2) — no valid acknowledgement is recorded.
- **R-13** (tier 1) — acknowledged at 90 minutes against a 60-minute window.
- **R-15** (tier 2) — acknowledged at 510 minutes against a 480-minute window. Released at 16:00 during core hours, its clock runs continuously from that point; the acknowledgement arrived at 00:30 the following morning, 30 minutes past the window. It was escalated and the escalation is recorded.
- **R-16** (tier 2) — acknowledged at 1081 minutes against a 480-minute window. Its clock started at 17:59 and ran continuously; the acknowledgement at 12:00 the next day is far past the window. It was not escalated.

## Acknowledged by somebody who cannot act on it (1)

- **R-06** was acknowledged 40 minutes after release, comfortably inside the window, by a role
  that is not on the approved list. The result is therefore unacknowledged and shows as a breach
  as well. Nothing in the elapsed times reveals this.

## Missed window with no escalation (3)

- **R-04** missed its acknowledgement window and nothing appears on the escalation register. The delay and the failure to escalate it are separate findings.
- **R-13** missed its acknowledgement window and nothing appears on the escalation register. The delay and the failure to escalate it are separate findings.
- **R-16** missed its acknowledgement window and nothing appears on the escalation register. The delay and the failure to escalate it are separate findings.

## What is not a finding

- **Out-of-hours tier 2 results.** R-08 was released in the evening and acknowledged the next
  afternoon — over eighteen hours of wall clock — and is fully compliant, because a tier 2 clock
  starts at 08:00 the following morning. R-11, released before core
  hours, starts at 08:00 the same morning. Measuring either from the
  release timestamp reports two breaches that do not exist.
- **The 18:00 boundary.** R-14 was released at exactly 18:00. The procedure says a tier 2 result
  released at or after 18:00 starts its clock at 08:00 the next morning, so R-14's clock starts at
  08:00 on 2026-06-17, not at the release time. Both its notification (120 min) and acknowledgement
  (480 min, exactly at the inclusive boundary) fall within their windows.
- **One minute makes all the difference.** R-16 was released at 17:59, one minute before R-14's
  18:00 cutoff. Because 17:59 is still within core hours (08:00–18:00), its clock starts at the
  release time, not at 08:00 the next morning. The same notification and acknowledgement that would
  be compliant under an 08:00 clock start are instead over fifteen hours late. R-14 and R-16
  together show why the boundary is drawn at 18:00, not near it.
- **Tier 1 gets no such grace.** R-12 and R-13 were both released outside core hours. R-12 is
  compliant on the continuous clock; R-13 is late on both counts. Applying the core-hours rule to
  tier 1 would clear both.
- **The inclusive boundary.** R-05 was acknowledged at exactly the tier 1 window and is within
  it. R-15 was notified at exactly 240 minutes and is within the tier 2 notification window.
- **An escalation that was not needed.** R-17 was acknowledged at 50 minutes, comfortably inside
  the tier 1 window, yet an entry appears on the escalation register. The procedure requires
  escalation only when the acknowledgement window is missed; an escalation that was not required
  is not a finding, and R-17 is compliant.
