# CR-7 critical results audit - 28 results

14 results are clean. The findings on the other 14 fall into four classes.

## Late notifications

- **R-02** (tier 1) - telephoned 45 minutes after clock start against a 30-minute window.
- **R-09** (tier 2) - telephoned 300 minutes after clock start against a 240-minute window.
- **R-13** (tier 1) - telephoned 50 minutes after clock start against a 30-minute window.
- **R-16** (tier 2) - telephoned 931 minutes after clock start against a 240-minute window.
- **R-21** (tier 1) - telephoned 36 minutes after clock start against a 30-minute window.
- **R-26** (tier 1) - telephoned 31 minutes after clock start against a 30-minute window.

## Late or absent acknowledgements

- **R-03** - acknowledged at 80 minutes.
- **R-04** - acknowledged at 90 minutes.
- **R-06** - acknowledged at 40 minutes.
- **R-10** - acknowledged at  minutes.
- **R-13** - acknowledged at 90 minutes.
- **R-15** - acknowledged at 510 minutes.
- **R-16** - acknowledged at 1081 minutes.
- **R-21** - acknowledged at 71 minutes.
- **R-22** - acknowledged at 45 minutes.
- **R-24** - acknowledged at 481 minutes.
- **R-27** - acknowledged at 481 minutes.

## Unapproved acknowledger

- **R-06** - acknowledged by ward_clerk, not on the approved list.
- **R-22** - acknowledged by nurse_hca, not on the approved list.

## Missing escalation

- **R-04** - missed acknowledgement window with no escalation.
- **R-13** - missed acknowledgement window with no escalation.
- **R-16** - missed acknowledgement window with no escalation.
- **R-21** - missed acknowledgement window with no escalation.

## What is not a finding

- Out-of-hours tier 2 results with long wall-clock times that are compliant because the clock starts at 08:00.
- The 18:00 boundary: R-14 at exactly 18:00 starts next morning; R-16 at 17:59 starts immediately.
- Inclusive boundaries: exactly at the window limit is within it.
- An escalation that was not required is not a finding.
- R-22 acknowledged by nurse_hca (unapproved) - ack does not count, window missed.
