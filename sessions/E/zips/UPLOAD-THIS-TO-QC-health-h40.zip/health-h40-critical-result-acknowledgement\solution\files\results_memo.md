# CR-7 critical results audit — 13 results

6 results are clean. The findings on the other seven fall into four classes and
one result carries three of them.

## Late notification (3)

- **R-02** (tier 1) — telephoned 45 minutes after its clock started, against a 30-minute window.
- **R-09** (tier 2) — telephoned 300 minutes after its clock started, against a 240-minute window.
- **R-13** (tier 1) — telephoned 50 minutes after its clock started, against a 30-minute window.

## Late or absent acknowledgement (5)

- **R-03** (tier 1) — acknowledged at 80 minutes against a 60-minute window.
- **R-04** (tier 1) — acknowledged at 90 minutes against a 60-minute window.
- **R-06** (tier 1) — no valid acknowledgement is recorded.
- **R-10** (tier 2) — no valid acknowledgement is recorded.
- **R-13** (tier 1) — acknowledged at 90 minutes against a 60-minute window.

## Acknowledged by somebody who cannot act on it (1)

- **R-06** was acknowledged 40 minutes after release, comfortably inside the window, by a role
  that is not on the approved list. The result is therefore unacknowledged and shows as a breach
  as well. Nothing in the elapsed times reveals this.

## Missed window with no escalation (2)

- **R-04** missed its acknowledgement window and nothing appears on the escalation register. The delay and the failure to escalate it are separate findings.
- **R-13** missed its acknowledgement window and nothing appears on the escalation register. The delay and the failure to escalate it are separate findings.

## What is not a finding

- **Out-of-hours tier 2 results.** R-08 was released in the evening and acknowledged the next
  afternoon — over eighteen hours of wall clock — and is fully compliant, because a tier 2 clock
  starts at 08:00 the following morning. R-11, released before core
  hours, starts at 08:00 the same morning. Measuring either from the
  release timestamp reports two breaches that do not exist.
- **Tier 1 gets no such grace.** R-12 and R-13 were both released outside core hours. R-12 is
  compliant on the continuous clock; R-13 is late on both counts. Applying the core-hours rule to
  tier 1 would clear both.
- **The inclusive boundary.** R-05 was acknowledged at exactly the tier 1 window and is within
  it.
