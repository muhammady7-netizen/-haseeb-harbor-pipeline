# fin-f55-trust-principal-income-allocation-audit

Non-connector Harbor task. Audit trust ledger principal/income allocations against the P&I policy.
