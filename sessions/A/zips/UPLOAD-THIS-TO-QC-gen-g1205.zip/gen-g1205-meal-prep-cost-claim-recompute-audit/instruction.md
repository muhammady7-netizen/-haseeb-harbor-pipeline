# Task

Recompute this batch of meal-prep recipes' per-serving cost claims against the recipe cost claim standard before the shorts post (honor the secondary price register override, trim, last-wins, exact-true pantry tokens, tolerance, and one-finding precedence stated in the standard). Use the current reference prices after applying the register Ã¢â‚¬â€ not the obsolete base-sheet alone, and not any price a recipe's own notes cite Ã¢â‚¬â€ and remember that not every extra ingredient counts toward the true cost. Also flag any recipe whose own math relied on an out-of-date chicken price, and any recipe with no usable serving count. Save `recipe_cost_audit.csv` with **exactly two columns** Ã¢â‚¬â€ header `recipe_id,finding` only (one data row per unique recipe; no extra diagnostic columns and no pipe characters) Ã¢â‚¬â€ using finding values `COST_CLAIM_INVALID`, `PRICE_SHEET_STALE`, `SERVING_COUNT_MISSING`, or `none`. Then write `recipe_cost_memo.md` (at least 1500 characters) explaining each finding, how the secondary register changed current prices, and which recipe's extra ingredient the standard excludes from cost. The memo must reference the last-wins rule, the secondary price register, the tolerance boundary, the pantry-staple exclusion, the precedence rule, and the stale-price check.

---
Save your deliverables into your current working directory using exactly these filenames:
    - `recipe_cost_audit.csv` Ã¢â‚¬â€ Per-recipe cost-claim audit
    - `recipe_cost_memo.md` Ã¢â‚¬â€ Markdown memo
    - `results.json` Ã¢â‚¬â€ a JSON object with exactly these keys and no others: `recipe_count`, `flagged_count`, `cost_claim_flagged_count`, `stale_price_flagged_count`, `compliant_count`
- Writing those files is the required deliverable and must be your final action; confirm each one exists before you answer.

---

## Working environment

- Your current working directory is `/app`, and it is writable.
- The read-only attachments referred to as `input/` are at `/app/input`.
- Write every deliverable into `/app`, at the exact filenames listed above. Do not nest files in subdirectories.
