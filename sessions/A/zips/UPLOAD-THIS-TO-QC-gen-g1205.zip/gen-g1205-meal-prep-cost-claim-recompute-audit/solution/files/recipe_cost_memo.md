# Meal-prep cost claim audit — 100 recipes

Graded with the current recipe cost claim standard (secondary register override,
trim, last-wins, exact-true pantry token, inclusive $0.25 tolerance, and
one-finding precedence). The secondary register moves chicken to $4.25/lb,
rice to $0.65/cup, and asparagus to $3.25/lb; the proposed $4.50 errata is not
in force (proposed status excluded).
44 compliant, 56 with findings.

## Secondary price register

The secondary price register overrides the base sheet ($4.00/$0.60/$3.00) with
active rows only. Chicken moves to $4.25/lb (last active row wins; the $4.10 row
is superseded; the $4.50 row is proposed and excluded). Rice moves to $0.65/cup
(the $0.55 row is draft). Asparagus moves to $3.25/lb (the `Active` row
matches after trim and case-insensitive compare).

## Precedence and serving-count gates

`SERVING_COUNT_MISSING` beats every other finding. Blank, whitespace-only, `0`,
`0.0`, `0.00`, `0.000`, `+0`, `-0`, `00`, and negative servings all qualify — see R-08, R-10, R-11, R-16, R-30, R-37, R-42, R-46, R-51, R-63, R-74, R-79, R-85, R-88, R-96.
Recipes that are also stale still stay on the serving-count path.

## Stale chicken price

Numeric compare after trim against $4.25 (the register price, not $4.00):
`4.25` and spaced `4.25 ` match; `4.00` and `4.0` do not. `4.250` and `4.2500`
match (numerically equal). `4.2` and `4.3` do not match. `4.25.0` is
unparseable and does not match. Blank `chicken_price_used` does not match.
Stale findings: R-04, R-100, R-15, R-24, R-29, R-34, R-35, R-45, R-50, R-54, R-58, R-62, R-67, R-68, R-69, R-73, R-81, R-84, R-87, R-90. Where a claim would also fail, precedence keeps
`PRICE_SHEET_STALE` only.

## Cost claim invalid (and pantry token traps)

R-02, R-05, R-09, R-17, R-18, R-19, R-25, R-26, R-32, R-47, R-49, R-59, R-60, R-71, R-78, R-82, R-83, R-91, R-92, R-97, R-98 -> `COST_CLAIM_INVALID`. Exact-true
pantry exclusion clears recipes with exact `true`/`TRUE`/`True` tokens.
Tokens `yes`, `1`, `Y`, `Truee`, `TRUE!`, and blank are not pantry staples, so those
recipes include the finishing-salt cost and flag. Tolerance is inclusive: a
recipe at exactly +$0.25 flags (`COST_CLAIM_INVALID`); only strictly below
$0.25 stays `none`.

## Last-wins and canonical ids

R-23's last row is clean (`none`) after an earlier invalid draft. R-24's last
row is stale (supersedes a clean first). R-31 casefolds and trims to a single
clean row. R-34 has three rows; the last (stale) wins. R-43 has two rows; the
last (clean) wins over a stale middle row. R-57 has four rows; the last (clean)
wins. R-72 has five rows; the last (clean) wins. R-87 has two rows; the last
(stale) wins. Spaced ` R-12 ` and ` r-48 ` report as `R-12` and `R-48`.

## Pantry-staple exclusion the standard clears

R-44 includes a $5.00 truffle oil tagged as pantry-staple with an exact `True`
token. The standard excludes R-44's truffle oil from the cost computation
entirely — once excluded, the true cost per serving falls back under the claim,
so the finding is `none`. R-03 and R-20 include a $2.00 finishing salt with exact
`True`/` True ` tokens; R-33 has `TRUE` and R-39 has spaced ` true `. All are
excluded under the same rule. The standard excludes the extra ingredient from
the cost — once excluded, the true cost per serving falls back under the claim,
so the finding is `none`.

## Clean rows

R-01, R-03, R-06, R-07, R-12, R-13, R-14, R-20, R-21, R-22, R-23, R-27, R-28, R-31, R-33, R-36, R-38, R-39, R-40, R-41, R-43, R-44, R-48, R-52, R-53, R-55, R-56, R-57, R-61, R-64, R-65, R-66, R-70, R-72, R-75, R-76, R-77, R-80, R-86, R-89, R-93, R-94, R-95, R-99 -> `none`.

## Finding classes

Assigned codes include `COST_CLAIM_INVALID`, `PRICE_SHEET_STALE`,
`SERVING_COUNT_MISSING`, and `none`.
