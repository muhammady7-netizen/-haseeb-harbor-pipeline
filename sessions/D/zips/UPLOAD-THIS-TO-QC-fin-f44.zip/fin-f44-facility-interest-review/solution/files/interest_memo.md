# Review of the agent's interest and fee charges

Interest properly due is **371,912.34** and fees **16,797.95**, against
421,312.33 charged. We are owed a net **32,602.04**. Four invoice lines
are disputed and two are confirmed, and one fee that should have been charged was not.

| Reference | Charged | Due | Difference |
|---|---|---|---|
| INV-2201 | 79,520.55 | 79,520.55 | 0.00 |
| INV-2202 | 129,000.00 | 127,232.88 | 1,767.12 |
| INV-2203 | 38,835.62 | 13,592.47 | 25,243.15 |
| INV-2204 | 95,473.97 | 88,241.10 | 7,232.87 |
| INV-2205 | 64,383.56 | 64,383.56 | 0.00 |
| INV-2206 | 14,098.63 | 12,534.25 | 1,564.38 |
| Utilisation fee (not invoiced) | 0.00 | 3,205.48 | (3,205.48) |
| **Total** | **421,312.33** | **388,710.29** | **32,602.04** |

## The day-count basis

Loan B has been charged on a year of 360 days. The agreement calculates interest on the actual
days elapsed and a year of **365**, for every Loan. On the correct basis the
charge is 127,232.88 rather than 129,000.00. Loan A, on the same
rate and the same days, was charged correctly, which is what makes the difference visible.

## The margin step-down

The Compliance Certificate for the quarter ended 31 December 2021 was delivered on
20 March 2022 and put Leverage in the band that carries a Margin of
1.75%. The change takes effect from the **first Interest Period
beginning after delivery**, which includes Loan C and Loan E, both starting on 4 April.
Loan C should have been charged at 6.10% after the margin step-down and was charged at
6.60%, giving 88,241.10 rather than 95,473.97. Loan E should also
have been charged at 6.10% and was charged at 6.60%.

Loans A and B are **not** affected: their Interest Period had already begun when the
certificate was delivered, so it runs to its end on the old Margin. The certificate delivered
in May falls in the same Leverage band and changes nothing at all.

## The commitment fee

The commitment fee (INV-2203) of 13,592.47 is charged on the **undrawn** commitment, not the drawn principal. During the fee period
13,000,000 was drawn against Total Commitments of 20,000,000, so the fee is
due on 7,000,000 and comes to 13,592.47. The agent charged it on the whole
20,000,000, which charges us a second time for the drawn part that is already carrying
interest.

## The fee that was not charged

Utilisation ran at 65% of Total Commitments throughout
the fee period, above the threshold, so a utilisation fee of 3,205.48 was
payable on the Loans outstanding. Nothing was invoiced for it. It is our obligation whether or
not the agent bills it, so it comes **off** what we are claiming back.

## The line that looks wrong and is not

Loan D was charged for 94 days where the calendar between the two
dates in the schedule shows 92.
The scheduled last day, 1 October 2022, was a **Saturday**. Under the modified following
convention it moves to the next Business Day, Monday 3 October, and the period lengthens
accordingly. The move stays inside October, so it is not pulled back. The charge of
64,383.56 is **correct** and we should not dispute it; Loan A is correct as
charged too.

## The line that rolled back

Loan E was charged for 26 days. The scheduled last day, 30 April 2022, was a **Saturday**.
Under the modified following convention the next Business Day is Monday 2 May, but that
falls in the next calendar month, so the last day moves **back** to the preceding Business Day,
Friday 29 April. The period shortens to 25 days. Combined with the margin step-down,
the correct charge is 12,534.25 rather than the 14,098.63 invoiced.
