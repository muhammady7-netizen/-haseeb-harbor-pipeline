# Task

The agent bank's charges on the revolver look high and I want them checked before we settle. Using the attached loan schedule, the compliance certificates and the invoices, recompute what is properly payable. The facility agreement is authoritative on the day-count basis, on how an interest period is measured and what happens when its last day is not a business day, on when a margin change takes effect, on what the commitment fee is charged on, and on the utilisation fee. Save `interest_review.csv` with the columns `reference,description,amount_charged_gbp,amount_due_gbp,difference_gbp,finding`, one row per invoice line, a row for anything that should have been charged and was not, and a total row. Then write `interest_memo.md` setting out each line we are disputing and why, each line we are confirming even though it looks wrong, and anything that runs in the bank's favour.

---
Delivery conventions for this run (added by the eval harness; the request above is unchanged):
- The attachments are provided read-only at: `input/facility_agreement.md`; `input/loan_schedule.csv`; `input/compliance_certificates.csv`; `input/bank_invoices.csv`. Read them there.
- Save your deliverables into your current working directory using exactly these filenames:
    - `interest_review.csv` — Line-by-line recomputation of the bank's charges
    - `interest_memo.md` — Markdown memo for the settlement discussion
    - `results.json` — a JSON object (all numbers) with these keys:
        - `interest_due_gbp` — the sum of `amount_due_gbp` across all interest rows (INV-2201, INV-2202, INV-2204, INV-2205, INV-2206; exclude the commitment-fee line INV-2203)
        - `fees_due_gbp` — the sum of `amount_due_gbp` across all fee rows (the commitment-fee invoice line INV-2203 plus any uncharged utilisation fee line)
        - `net_adjustment_gbp` — the total `difference_gbp` across all rows, where `difference_gbp` is `amount_charged_gbp - amount_due_gbp` (an overcharge is positive, an uncharged amount is negative)
        - `disputed_lines_count` — the number of invoiced lines where `amount_charged_gbp` does not equal `amount_due_gbp` (excluding the total row and any uncharged-fee row)
        - `confirmed_lines_count` — the number of invoiced lines where `amount_charged_gbp` equals `amount_due_gbp` (a line that matches the invoice is confirmed, as is a line that looks wrong but is correct on the rules)
- Writing those files is the required deliverable and must be your final action; confirm each one exists before you answer.

---

## Working environment

- Your current working directory is `/app`, and it is writable.
- The read-only attachments referred to as `input/` are at `/app/input`.
- Write every deliverable into `/app`, at the exact filenames listed above.
