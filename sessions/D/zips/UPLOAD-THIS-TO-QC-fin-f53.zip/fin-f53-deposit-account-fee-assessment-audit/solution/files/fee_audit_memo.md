# Deposit account fee assessment audit — 47 items

47 lines checked. 16 correct; 31 findings.

## Overdraft cap — V, II, B, J
`daily_seq` drives the cap (not row count). V (seq 6) and II (seq 7) are lone high-seq rows past the daily cap. B/J are sequence 5.

## NSF — C, KK trim, GG/JJ non-tokens
C and KK (` True` after trim) were swept but still charged (`nsf_not_waived`). GG (`yes`) and JJ (`1`) are not waiver tokens and are correctly charged. Blank W is not a waiver.

## FX — half-up, min $5, max $20, trim/blank, unmatched, chain
Half-up edges Y/CC/DD/OO must be 15.63/14.63/16.63/18.63 (not banker's). NN half-up then **max $20** => 20.0. E is GBP/`gffn` last non-partner; 3% would be $24 but **max $20** => 20.0. TT assessed $24.00 against max 20.0 (undercharge). EE assessed $15.62 against half-up 15.63. T/U/Z show the $5 minimum. FF unmatched `ghostnet` and RR blank network are non-partner. HH is `euR`. MM (`USD `) and LL (blank currency=USD) are exempt. SS `chainnet` last row is partner => $0. S remains partner-exempt; X lowercase usd exempt; P USD exempt. AA flipnet last non-partner.

## Dormant — last-wins activity, 12.1, missing REL, trim
F and UU (leading-space ` REL-01` after trim) need $5. G and QQ on REL-02: activity register **last-wins FALSE**, so dormant applies (surface read of an earlier true row is misleading). PP is months 12.1 (>12). BB is missing REL-99. O is exactly 12 (not past threshold).
