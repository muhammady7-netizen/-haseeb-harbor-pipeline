# Consumer deposit account fee schedule

Where an assessed fee disagrees with this schedule, the schedule decides.
Supporting registers under `input/` are part of the schedule for network and dormancy lookups.
Before any match, **trim leading/trailing whitespace** on `swept_same_day`, `currency`,
`network_code`, and `relationship_id`.

## 1. Overdraft item fee

$34.00 per item that overdraws the account, capped at 4 fees per calendar day
(`post_date`). Sequence numbers on the export are 1-based within that calendar day.
**Use `daily_seq` as the position** — do not infer position by counting how many
overdraft rows appear for that day in the export. A lone row with `daily_seq` 5
or higher is still past the cap. The 5th and any later overdrawing item on the
same day is not charged. A 5th-or-later item that was still charged is a
`daily_cap_exceeded` finding. Items at sequence 4 are still inside the cap.

## 2. NSF (returned item) fee

$34.00 per returned item, waived if a linked savings or overdraft-protection transfer
covered the shortfall on the same business day (`swept_same_day` is true). A swept item
that was still charged is an `nsf_not_waived` finding. A non-swept returned item is charged
the full fee. After trimming, **only** the tokens `true` / `TRUE` / `True` count as swept
(case-insensitive exact token). Values such as `yes`, `1`, `Y`, or `swept` are **not**
waivers. An empty / blank `swept_same_day` is also **not** a waiver.

## 3. Foreign transaction fee

Start with 3% of `amount`, rounded half-up to two decimal places, on any purchase whose
`currency` is not USD — except purchases whose network resolves to a GlobalFee-Free
partner in `network_registry.csv`. Partner resolution: match `network_code`
case-insensitively; if more than one registry row matches, the last matching row wins.
If `network_code` is blank or matches **no** registry row, treat the network as
**non-partner**. Partner transactions are exempt from the foreign fee regardless of
currency.

USD purchases are never foreign-fee eligible; the USD check is **case-insensitive**
(`USD`, `usd`, `Usd`) after trim. An **empty/blank currency** is treated as USD.
Any other currency code (including mixed case like `euR`) is foreign-fee eligible
unless partner-exempt.

After the 3% half-up step:
1. apply a **minimum foreign fee of $5.00** (if 3% half-up is below $5.00, use $5.00);
2. then apply a **maximum foreign fee of $20.00** (if the fee after the minimum step
   exceeds $20.00, charge $20.00).

A non-partner foreign purchase that was not charged the resulting fee — including an
**undercharge** below that resulting fee — is an `fx_fee_not_charged` finding.

## 4. Dormant account fee

$5.00 per month when `months_inactive` is **numerically** strictly greater than 12 and
the linked relationship had no customer-initiated activity in the period. Look up
`relationship_id` in `linked_activity.csv` (`had_customer_activity`). If more than one
activity row matches the same `relationship_id`, the **last matching row wins**.
Activity on a linked relationship waives the fee even past 12 months. If
`relationship_id` is **absent** from `linked_activity.csv`, treat that as no
customer-initiated activity. A dormant account past 12 months with no linked activity
that was not charged is a `dormant_fee_not_charged` finding. Exactly 12 (or 12.0)
months inactive is not yet past the threshold; 12.1 is past it. Boolean activity
values are case-insensitive after trim.

## 5. Finding names

`correct`, `daily_cap_exceeded`, `nsf_not_waived`, `fx_fee_not_charged`,
`dormant_fee_not_charged`.
