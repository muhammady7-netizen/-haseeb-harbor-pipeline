# Task

Ops pulled a statement fee export and asked for a schedule check before the customer letter goes out. The disclosed fee schedule is in `input/fee_schedule.md`. The line items are in `input/assessed_fee_items.csv`. Two supporting registers sit alongside them: `input/network_registry.csv` (merchant network codes) and `input/linked_activity.csv` (same-relationship activity used for dormancy waivers). Where the export and the schedule disagree, the schedule (and those registers) decide. Read every rule in the schedule carefully — including trimming, sequence numbers, which boolean tokens count, case folding, blank currency/network handling, missing or duplicate register rows (last matching row wins), numeric month thresholds, half-up rounding, and minimum/maximum foreign fees.

For each line, recompute the fee that should have applied and compare it to `assessed_fee`. Write `fee_audit.csv` with columns `item_id,fee_type,assessed_fee,correct_fee,finding`. Allowed finding values: `correct`, `daily_cap_exceeded`, `nsf_not_waived`, `fx_fee_not_charged`, `dormant_fee_not_charged`. Then write `fee_audit_memo.md` that walks every finding and notes any line that looks non-compliant on a surface read but actually complies. Finish with `results.json` using keys `fee_item_count`, `flagged_count`, `cap_exceeded_count`, `nsf_error_count`, `dormant_error_count`.

---
Save your deliverables into your current working directory using exactly these filenames:
    - `fee_audit.csv` — Per-item deposit account fee audit
    - `fee_audit_memo.md` — Markdown audit memo
    - `results.json` — a JSON object with the keys `fee_item_count`, `flagged_count`, `cap_exceeded_count`, `nsf_error_count`, `dormant_error_count`
- Writing those files is the required deliverable and must be your final action; confirm each one exists before you answer.

---

## Working environment

- Your current working directory is `/app`, and it is writable.
- The read-only attachments referred to as `input/` are at `/app/input`.
- Write every deliverable into `/app`, at the exact filenames listed above.
