# fin-f53-deposit-account-fee-assessment-audit

**Task ID:** NONC-B1-1000791  
**Trainer:** Muhammad Haseeb Younas

## What this task is

A deposit-account fee schedule audit. The model receives a disclosed fee schedule, an assessed-fee export, a merchant network registry, and a linked-activity register. It must recompute each line's correct fee, classify findings, and deliver a CSV audit, memo, and summary JSON.

## Inputs (read-only under `input/`)

- `fee_schedule.md` — overdraft cap, NSF waiver tokens, FX min/max/half-up, dormancy rules
- `assessed_fee_items.csv` — fee line export
- `network_registry.csv` — partner resolution (last matching row wins)
- `linked_activity.csv` — dormancy waiver lookup (last matching row wins)

## Deliverables (workspace root `/app`)

1. `fee_audit.csv` — `item_id,fee_type,assessed_fee,correct_fee,finding`
2. `fee_audit_memo.md` — walk every finding; note surface-noncompliant lines that comply
3. `results.json` — `fee_item_count`, `flagged_count`, `cap_exceeded_count`, `nsf_error_count`, `dormant_error_count`

## Why it is non-trivial

- Overdraft cap uses `daily_seq`, not row count per day
- NSF waiver accepts only `true`/`TRUE`/`True` after trim — not `yes` or `1`
- FX: 3% half-up, $5 minimum, $20 maximum; undercharges fail
- Network/partner and activity registers use last-wins; unmatched network is non-partner
- Dormancy: numeric >12 months; missing relationship = no activity

## Grading

Deterministic checks in `tests/verifier.json` via vendored `rl_world_verifiers` (`tests/test.sh` → pytest). Reward is **fractional** (`passed/total` over the 71 per-checks) so partial audit quality is not collapsed to the same 0.0 as an empty run. Core facts are structured CSV/JSON checks; memo stems are soft anchors.

## QC notes

- Oracle + stability v9 at reward 1.0
- Authoritative GLM battery: `glm-f53-v9-1..5` → **1/5** (0,0,0,0,1); first four **0/4** (meets ≤2/4 bar)
- Golden trajectory is **oracle ATIF** (`solution/golden_trajectory.json`) — not a copy of any GLM run
- Independent GLM pass: `glm-f53-v9-5` / evaluations r5 (trajectory digest distinct from golden)
