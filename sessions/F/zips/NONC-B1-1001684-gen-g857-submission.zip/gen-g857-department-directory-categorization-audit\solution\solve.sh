#!/bin/bash
cp /app/solution/files/g857_mappings.csv /app/g857_mappings.csv
cp /app/solution/files/g857_headcount.json /app/g857_headcount.json
cp /app/solution/files/g857_unmapped.csv /app/g857_unmapped.csv
