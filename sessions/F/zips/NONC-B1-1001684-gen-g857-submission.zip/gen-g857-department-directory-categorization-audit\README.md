# gen-g857 Department Taxonomy Migration

Offline audit: move directory entries into a new department hierarchy and identify ambiguous placements.

## Inputs
- g857_people.csv: person_id, legacy_department, role_code
- g857_taxonomy.json: nodes with parent, depth, allowed_roles
- g857_crosswalk.csv: legacy_department, target_node, confidence

## Deliverables
- g857_mappings.csv: person_id, target_node, confidence, status
- g857_headcount.json: direct_count and rolled_up_count per node
- g857_unmapped.csv: unmapped people

## Verifier
69 deterministic checks + 1 cross-check test.
