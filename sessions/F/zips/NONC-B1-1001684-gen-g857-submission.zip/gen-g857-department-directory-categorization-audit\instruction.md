# Department Taxonomy Migration

Move directory entries into a new department hierarchy and identify ambiguous placements.

## Inputs

- `g857_people.csv`: `person_id,legacy_department,role_code` — one row per person.
- `g857_taxonomy.json`: a JSON object with a `nodes` array; each node has `node_id`, `parent` (node_id or `null` for root), `depth` (integer), and `allowed_roles` (array of role codes this node accepts).
- `g857_crosswalk.csv`: `legacy_department,target_node,confidence` — candidate mappings from legacy departments to taxonomy nodes with a confidence score (float, 0.0–1.0).

## Required work

1. **Detect taxonomy cycles.** Build the parent→child tree from `g857_taxonomy.json`. If any node is reachable from itself by following parent links, stop and write only `g857_unmapped.csv` with all person_ids set to `UNMAPPED` and `status` set to `CYCLE_DETECTED`.
2. **For each person**, find all crosswalk rows where `legacy_department` matches the person's `legacy_department`. Among those, select the one whose `target_node` appears in the taxonomy and whose `allowed_roles` includes the person's `role_code`. If multiple qualify, pick the one with the highest `confidence`. Ties in confidence are broken by deepest `depth` (larger depth wins). Further ties broken by `node_id` (lexicographically smallest wins).
3. If no role-compatible mapping exists (either no crosswalk row for that legacy_department, or the target node does not allow the person's role), the person is `UNMAPPED` with `status` set to `NO_ROLE_MATCH`.
4. **Roll up headcount.** For each taxonomy node, `direct_count` is the number of people mapped to it. `rolled_up_count` is `direct_count` plus the sum of `rolled_up_count` of all direct children. Root nodes' `rolled_up_count` equals their subtree total.
5. Mapped persons have `status` = `MAPPED`.

## Deliverables

- `g857_mappings.csv`: `person_id,target_node,confidence,status` — one row per person, header exactly `person_id,target_node,confidence,status`.
- `g857_headcount.json`: a JSON object mapping each `node_id` to `{"direct_count": N, "rolled_up_count": N}`. Include all taxonomy nodes even if `direct_count` is 0.
- `g857_unmapped.csv`: `person_id,legacy_department,role_code` — one row per unmapped person.

## Verification

Validate acyclic hierarchy, depths, role rules, mapping ties, ancestor totals, and one mapping outcome per person. The verifier rejects duplicate primary keys, unexpected columns in exact-schema outputs, nonfinite numbers, undeclared status labels, and summary totals that do not reconcile to row-level values.

Do not invent missing records. Save the complete deliverable set under `/app`.
