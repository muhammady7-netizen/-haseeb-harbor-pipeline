"""Replays verifier.json against workspace."""
import os, sys, json
from pathlib import Path
import pytest

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR))

from rl_world_verifiers.models import VerifierSpec, effective_weights
from rl_world_verifiers.sources.registry import SourceRegistry
from rl_world_verifiers.verifiers import verify_definition

WORKSPACE = Path(os.environ.get("HARBOR_TASK_WORKSPACE", "/app"))
SPEC = VerifierSpec.model_validate_json(
    (TESTS_DIR / "verifier.json").read_text(encoding="utf-8")
)
WEIGHTS = effective_weights(SPEC.verifiers)
REGISTRY = SourceRegistry(WORKSPACE)


@pytest.mark.parametrize(
    "definition",
    SPEC.verifiers,
    ids=[definition.name for definition in SPEC.verifiers],
)
def test_deliverable(definition):
    outcome = verify_definition(
        definition,
        REGISTRY,
        WEIGHTS[definition.name],
        config=SPEC.config,
        completion_fn=None,
    )["result"]
    detail = outcome.get("error") or outcome.get("reason") or "assertion failed"
    assert outcome["success"], f"{definition.name}: {detail}"


def test_results_match_mappings():
    """Cross-check headcount against mappings CSV."""
    import csv, json

    mappings_path = WORKSPACE / "g857_mappings.csv"
    assert mappings_path.is_file(), "g857_mappings.csv missing"

    findings = {}
    with mappings_path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            target = (row.get("target_node") or "").strip()
            if target and target != "UNMAPPED":
                findings[target] = findings.get(target, 0) + 1

    hc_path = WORKSPACE / "g857_headcount.json"
    assert hc_path.is_file(), "g857_headcount.json missing"
    hc = json.loads(hc_path.read_text(encoding="utf-8"))

    for node_id, counts in hc.items():
        direct = counts.get("direct_count", 0)
        expected = findings.get(node_id, 0)
        assert direct == expected, f"{node_id}: direct_count={direct} != mappings-derived {expected}"
