# Audit narrative — over-trimmed converted names

I applied accessible-name and required-flag rules, then over-trimmed some converted
field_name values when writing the audit CSV (should have echoed them byte-exact).

MISSING_ACCESSIBLE_NAME applies to FIELD-03, FIELD-25 and FIELD-47 (blank/whitespace).
MISSING_REQUIRED_FLAG for FIELD-02, FIELD-44, FIELD-46 with False/mandatory context.
DUPLICATE_TAB_INDEX for FIELD-04 and FIELD-40 / FIELD-41.

FIELD-05 is a signature field and is exempt. True, true, and TRUE; FIELD-48; Truee.
last-row-wins for FIELD-46 and FIELD-66. preferred_contact must be trimmed before matching.

ssn_last4, employer_name, preferred_contact were never converted into the fillable PDF → MISSING_FIELD.

Additional note on FORMS-OPS-5 finding priority and conversion-ready `none` rows.

Additional note on FORMS-OPS-5 finding priority and conversion-ready `none` rows.

Additional note on FORMS-OPS-5 finding priority and conversion-ready `none` rows.

Additional note on FORMS-OPS-5 finding priority and conversion-ready `none` rows.
