# Conversion audit memo

FORMS-OPS-5 pass with a few residual CSV mismatches on signature exemption rows.

MISSING_ACCESSIBLE_NAME applies to FIELD-03, FIELD-25 and FIELD-47 (blank / whitespace names).
MISSING_REQUIRED_FLAG applies where FIELD-02, FIELD-44 and FIELD-46 are mandatory with False.
DUPLICATE_TAB_INDEX covers FIELD-04 and FIELD-40 with FIELD-41.

FIELD-05 is a signature field and is exempt. Tokens True, true, and TRUE; FIELD-48 vs Truee.
last-row-wins for FIELD-46 and FIELD-66. preferred_contact must be trimmed before matching.

ssn_last4, employer_name, preferred_contact were never converted into the fillable PDF and are MISSING_FIELD.
Additional converted fields stay `none` under priority ordering when no higher finding applies.

Additional note on FORMS-OPS-5 finding priority and conversion-ready `none` rows.

Additional note on FORMS-OPS-5 finding priority and conversion-ready `none` rows.

Additional note on FORMS-OPS-5 finding priority and conversion-ready `none` rows.
