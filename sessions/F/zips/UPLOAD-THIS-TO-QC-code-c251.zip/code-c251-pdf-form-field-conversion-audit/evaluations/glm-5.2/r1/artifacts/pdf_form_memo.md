# PDF conversion audit notes

Compared `/app/input/converted_field_inventory.csv` to `/app/input/source_form_inventory.csv`
using `/app/input/pdf_conversion_standard.md` (FORMS-OPS-5).

## Counts
42 flagged rows: 6 MISSING_ACCESSIBLE_NAME, 14 MISSING_REQUIRED_FLAG,
14 DUPLICATE_TAB_INDEX, 8 MISSING_FIELD.

## Signature exemption
FIELD-05 is a signature field and is exempt under the signature-type rule when
source-mandatory and unflagged. FIELD-11 and FIELD-51 follow the same rule.

## Accessible names
MISSING_ACCESSIBLE_NAME applies to FIELD-03, FIELD-25 and FIELD-47, all of which have blank
or whitespace-only names (FIELD-25 trims to blank).

## Required-flag token rule
Only True, true, and TRUE count. FIELD-02 / FIELD-44 / FIELD-46 are mandatory with False,
so MISSING_REQUIRED_FLAG. FIELD-48 keeps TRUE; FIELD-64 uses Truee and is invalid.

## Duplicate tab indices
DUPLICATE_TAB_INDEX covers FIELD-04 (shared tab 2) and the FIELD-40 / FIELD-41 pair.

## Whitespace and last-row-wins
preferred_contact must be trimmed before matching.
last-row-wins applies to FIELD-46 and FIELD-66.

## Missing source fields
ssn_last4, employer_name, preferred_contact, co_signer_id, co_signer_email,
co_borrower_address, account_type, and secondary_phone were never converted into the fillable PDF,
so each is MISSING_FIELD.

## Priority
MISSING_ACCESSIBLE_NAME > MISSING_REQUIRED_FLAG > DUPLICATE_TAB_INDEX > none.
