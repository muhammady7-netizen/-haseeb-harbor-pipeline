# Fillable-PDF conversion audit memo

Audited 66 converted fields against FORMS-OPS-5 and the source form inventory
(66 source fields). 42 findings across
6 missing accessible name,
14 missing required flag,
14 duplicate tab index, and
8 missing source field.

## Audit table

| Field ID | Name | Type | Required | Tab | Finding |
|---|---|---|---|---|---|
| FIELD-01 | applicant_name | text | True | 1 | none |
| FIELD-02 | date_of_birth | text | False | 2 | MISSING_REQUIRED_FLAG |
| FIELD-03 |  | text | True | 3 | MISSING_ACCESSIBLE_NAME |
| FIELD-04 | mailing_address | text | True | 2 | DUPLICATE_TAB_INDEX |
| FIELD-05 | signature | signature | False | 5 | none |
| FIELD-06 | phone_number | text | True | 6 | none |
| FIELD-07 | email_address | text | False | 7 | none |
| FIELD-08 | employment_start | date | True | 8 | none |
| FIELD-09 | annual_income | number | True | 9 | none |
| FIELD-10 | co_signer_name | text | True | 10 | none |
| FIELD-11 | co_signer_signature | signature | False | 11 | none |
| FIELD-12 | loan_amount | number | True | 12 | DUPLICATE_TAB_INDEX |
| FIELD-13 | loan_purpose | text | False | 13 | none |
| FIELD-14 |  collateral_desc | text | True | 12 | DUPLICATE_TAB_INDEX |
| FIELD-15 | branch_code | text | yes | 15 | none |
| FIELD-16 | account_number | text | True | 16 | none |
| FIELD-17 | interest_rate | number | False | 17 | none |
| FIELD-18 | term_months | number | 1 | 18 | MISSING_REQUIRED_FLAG |
| FIELD-19 | monthly_payment | number | False | 19 | none |
| FIELD-20 | next_of_kin | text | False | 20 | none |
| FIELD-21 | relationship | text | False | 12 | DUPLICATE_TAB_INDEX |
| FIELD-22 | consent_checkbox | checkbox | True | 22 | none |
| FIELD-23 | witness_signature | signature | False | 23 | none |
| FIELD-24 | date_signed | date | True | 24 | none |
| FIELD-25 |     | text | False | 25 | MISSING_ACCESSIBLE_NAME |
| FIELD-26 | emergency_contact | text | True | 26 | none |
| FIELD-27 |  | text | False | 27 | MISSING_ACCESSIBLE_NAME |
| FIELD-28 | income_source | text | True | 27 | DUPLICATE_TAB_INDEX |
| FIELD-29 | previous_address | text | False | 28 | MISSING_REQUIRED_FLAG |
| FIELD-30 | reference_name | text |  True  | 28 | DUPLICATE_TAB_INDEX |
| FIELD-31 | reference_phone | text | False | 29 | none |
| FIELD-32 | witness_name | text | True | 30 | none |
| FIELD-33 | employer_phone | signature | True | 31 | none |
| FIELD-34 | applicant_email | text | yes | 32 | MISSING_REQUIRED_FLAG |
| FIELD-35 |  | signature | True | 33 | MISSING_ACCESSIBLE_NAME |
| FIELD-36 | co_signer_phone | text | True | 33 | DUPLICATE_TAB_INDEX |
| FIELD-37 | employment_status | text | 1 | 34 | MISSING_REQUIRED_FLAG |
| FIELD-38 |  employer_address  | text | True | 35 | none |
| FIELD-39 | middle_initial | text | Y | 36 | MISSING_REQUIRED_FLAG |
| FIELD-40 | notary_signature | signature | True | 37 | DUPLICATE_TAB_INDEX |
| FIELD-41 | notary_name | text | True | 37 | DUPLICATE_TAB_INDEX |
| FIELD-42 |  | text | False | 38 | MISSING_ACCESSIBLE_NAME |
| FIELD-43 | declared_income | number | True | 33 | DUPLICATE_TAB_INDEX |
| FIELD-44 | esign_consent | text | False | 40 | MISSING_REQUIRED_FLAG |
| FIELD-45 | auth_code | signature | False | 41 | none |
| FIELD-46 | approval_code | text | False | 42 | MISSING_REQUIRED_FLAG |
| FIELD-47 |  | text | False | 33 | MISSING_ACCESSIBLE_NAME |
| FIELD-48 | verification_code | text | TRUE | 44 | none |
| FIELD-49 | renamed_field | text | False | 45 | none |
| FIELD-50 |  spaced_field  | text | False | 46 | MISSING_REQUIRED_FLAG |
| FIELD-51 | initial_signature | signature | True | 50 | none |
| FIELD-52 | optional_remarks | text | True | 51 | none |
| FIELD-53 | tax_id_number | text | yes | 52 | MISSING_REQUIRED_FLAG |
| FIELD-54 | swift_code | text | False | 53 | DUPLICATE_TAB_INDEX |
| FIELD-55 | iban_number | text | False |  53  | DUPLICATE_TAB_INDEX |
| FIELD-56 | signature_date | text | False | 54 | MISSING_REQUIRED_FLAG |
| FIELD-57 | prev_employer_name | text | False |  | DUPLICATE_TAB_INDEX |
| FIELD-58 | prev_employer_phone | text | False |  | DUPLICATE_TAB_INDEX |
| FIELD-59 | preferred_contact_method | text | True | 55 | none |
| FIELD-60 | additional_contact | text | True | 56 | none |
| FIELD-61 | additional_contact | text | False | 57 | MISSING_REQUIRED_FLAG |
| FIELD-62 | branch_routing_code | text | TRUE  | 58 | none |
| FIELD-63 | sort_code | text |  true | 59 | none |
| FIELD-64 | tax_withholding | text | Truee | 60 | MISSING_REQUIRED_FLAG |
| FIELD-65 | correspondence_address | text | True | 61 | none |
| FIELD-66 | co_applicant_id | text | False | 62 | MISSING_REQUIRED_FLAG |
| MISSING-SSN_LAST4 | ssn_last4 |  |  |  | MISSING_FIELD |
| MISSING-EMPLOYER_NAME | employer_name |  |  |  | MISSING_FIELD |
| MISSING-PREFERRED_CONTACT | preferred_contact  |  |  |  | MISSING_FIELD |
| MISSING-CO_SIGNER_ID |  co_signer_id  |  |  |  | MISSING_FIELD |
| MISSING-CO_SIGNER_EMAIL |  co_signer_email  |  |  |  | MISSING_FIELD |
| MISSING-CO_BORROWER_ADDRESS | co_borrower_address |  |  |  | MISSING_FIELD |
| MISSING-ACCOUNT_TYPE | account_type |  |  |  | MISSING_FIELD |
| MISSING-SECONDARY_PHONE | secondary_phone |  |  |  | MISSING_FIELD |

## Signature fields are exempt from the required-flag rule

FIELD-05 (signature) is exempt under the signature-type rule even when source-mandatory
and unflagged. FIELD-11 (co_signer_signature) follows the same signature exemption.
e-signature capture enforces completion outside the form's own required-field validation.
The finding for both is therefore none. FIELD-33 (employer_phone) is a non-mandatory
signature field that IS flagged required, which is over-flagging, not a violation.
FIELD-51 (initial_signature) is a signature field marked mandatory on the source form and
flagged required (True). Since signature-type fields are exempt, this is not a violation.

## Missing accessible name (highest priority)

FIELD-03 has a blank field_name, so the finding is MISSING_ACCESSIBLE_NAME.
FIELD-25 has a whitespace-only field_name that trims to blank → MISSING_ACCESSIBLE_NAME.
FIELD-27 also has a blank field_name AND shares tab index 27 with FIELD-28,
but MISSING_ACCESSIBLE_NAME has higher priority than DUPLICATE_TAB_INDEX.
FIELD-35 has a blank field_name. Even though it also shares tab index 33 with other fields
and carries required_flag=True, MISSING_ACCESSIBLE_NAME has higher priority.
FIELD-42 and FIELD-47 also have blank field names with MISSING_ACCESSIBLE_NAME.

## Missing required flag (exact-token rule)

FIELD-02 (date_of_birth) is mandatory, not a signature, and has required_flag=False —
finding MISSING_REQUIRED_FLAG.
FIELD-18 (term_months) is mandatory and has required_flag="1" (only True/true/TRUE counts).
FIELD-29 (previous_address) is mandatory, not flagged, AND shares tab index 28.
MISSING_REQUIRED_FLAG has higher priority than DUPLICATE_TAB_INDEX.
FIELD-34 (applicant_email) has required_flag=yes, not a valid token.
FIELD-37 (employment_status) has required_flag="1", not a valid token.
FIELD-39 (middle_initial) has required_flag="Y", not a valid token.
FIELD-44 (esign_consent) has required_flag=False and source marks it mandatory (signature
type on source, but converted as text, not exempt) — finding MISSING_REQUIRED_FLAG.
FIELD-46 (approval_code) last row wins (text type, not signature), mandatory, flag=False —
finding MISSING_REQUIRED_FLAG.
FIELD-50 (spaced_field) after trim matches source (mandatory), flag=False.
FIELD-53 (tax_id_number) last row wins with required_flag=yes, not valid.
FIELD-56 (signature_date) has "signature" in its name but converted type is text.
The exemption applies to converted fields of type signature, not fields with "signature"
in their name. Since type is text, exemption does not apply.
FIELD-61 (additional_contact) second row wins with required_flag=False, source marks
additional_contact as mandatory.
FIELD-64 (tax_withholding) has required_flag="Truee", not exactly True/true/TRUE.
FIELD-66 (co_applicant_id) last row wins (text, not signature), mandatory, flag=False.

## Over-flagging is not a violation

FIELD-10 (co_signer_name) is not mandatory on the source form but IS flagged required.
FIELD-15 (branch_code) has required_flag=yes, but the source form does not mark it
mandatory. FIELD-26 (emergency_contact) is not mandatory but IS flagged required.
FIELD-32 (witness_name) has a duplicate field_id; the last row wins, and it is
over-flagged (not mandatory but flagged). FIELD-52 (optional_remarks) is not mandatory
but IS flagged required. Over-flagging a non-mandatory field is not a violation.

## Duplicate tab index

FIELD-04 is graded DUPLICATE_TAB_INDEX (shares tab index 2 with a higher-priority
required-flag row).
FIELD-12, FIELD-14, and FIELD-21 share tab index 12. FIELD-28 shares tab index 27 with
FIELD-27 (MISSING_ACCESSIBLE_NAME at higher priority). FIELD-30 shares tab index 28 with
FIELD-29 (MISSING_REQUIRED_FLAG at higher priority). FIELD-36, FIELD-40, FIELD-41,
FIELD-43, and FIELD-47 share tab index 33 with FIELD-35 (MISSING_ACCESSIBLE_NAME at
higher priority). FIELD-40 and FIELD-41 both receive DUPLICATE_TAB_INDEX for shared
tab index 37. FIELD-54 (swift_code)
and FIELD-55 (iban_number) share tab index 53 ("53" and " 53 " both trim to "53").
FIELD-57 (prev_employer_name) and FIELD-58 (prev_employer_phone) both have blank
tab_index. Two fields with blank tab_index that match are DUPLICATE_TAB_INDEX.

## Whitespace trimming

FIELD-30 has required_flag=' True ' with spaces; after trimming it is True (valid).
FIELD-31 has tab_index=' 29 ' which trims to 29. FIELD-62 has required_flag='TRUE '
which trims to TRUE (valid). FIELD-63 has required_flag=' true' which trims to true
(valid). FIELD-65 has field_name='  correspondence_address  ' which trims to
correspondence_address and matches the source field (mandatory=True).
Source field names with leading/trailing whitespace (e.g. ' collateral_desc',
'preferred_contact ', ' co_signer_id ', ' co_signer_email ') must be trimmed before matching.

## Last-wins on duplicate field_id

FIELD-32 appears twice; last row (required_flag=True) wins. FIELD-46 appears twice;
first row type=signature, second row type=text. Last row wins, so text (not exempt).
FIELD-49 appears twice; first name=account_type, second name=renamed_field. Last row
wins, so name is renamed_field (no source match, no required-flag check). account_type
from source no longer matches, so it gets a MISSING_FIELD row. FIELD-53 appears twice;
first flag=True, second flag=yes. Last row wins, so yes (not valid). FIELD-66 appears
twice; first type=signature, second type=text. Last row wins, so text (not exempt).

## Signature exemption type mismatch

FIELD-44 has source type=signature (mandatory) but converted type=text. The required-flag
exemption applies only to converted fields of type signature, not source fields.
Since FIELD-44 is text, it is not exempt and needs required_flag=True.

## Missing source fields

ssn_last4, employer_name, preferred_contact, co_signer_id, co_signer_email,
co_borrower_address, account_type, and secondary_phone appear on the source form's
field inventory but were never converted into the fillable PDF. Each gets a
MISSING_FIELD finding row with the source field's name in the field_name column.

## Finding priority

When a converted field trips multiple rules, the finding precedence is
MISSING_ACCESSIBLE_NAME > MISSING_REQUIRED_FLAG > DUPLICATE_TAB_INDEX > none.

## Required flag token validation

The standard accepts True, true, and TRUE as valid required flags.
FIELD-48 has required_flag="TRUE" (uppercase). TRUE satisfies the rule. Finding is none.
FIELD-64 has required_flag="Truee" (not exactly True/true/TRUE). The extra character
makes it invalid. Finding is MISSING_REQUIRED_FLAG.
