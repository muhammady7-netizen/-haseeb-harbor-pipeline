#!/bin/bash
# Harbor verifier entrypoint. Harbor copies this to /tests/test.sh and runs it
# from the task working directory; reward is read back from
# /logs/verifier/reward.txt.
#
# Reward is FRACTIONAL (passed/total over per-check pytest cases), not binary.
# Errors count in the denominator (never inflate reward by dropping errored checks).
mkdir -p /logs/verifier

cd /app || exit 1

python3 -m pytest \
    --ctrf /logs/verifier/ctrf.json \
    /tests/test_outputs.py \
    -rA \
    2>&1 | tee /logs/verifier/test-stdout.txt
pytest_status=${PIPESTATUS[0]}

python3 - <<'PY'
import re
from pathlib import Path

stdout = Path("/logs/verifier/test-stdout.txt")
text = stdout.read_text(encoding="utf-8", errors="replace") if stdout.exists() else ""

passed = failed = errors = skipped = 0
# Match summaries like: "5 failed, 80 passed, 8 errors in 3s" or "93 passed in 1.2s"
m = re.search(
    r"=+\s*([\d\w\s,]+?)\s+in\s+[0-9.]+s",
    text,
)
if m:
    chunk = m.group(1)
    def grab(label: str) -> int:
        mm = re.search(rf"(\d+)\s+{label}", chunk)
        return int(mm.group(1)) if mm else 0
    failed = grab("failed")
    passed = grab("passed")
    skipped = grab("skipped")
    errors = grab("errors?")
else:
    failed = len(re.findall(r"^FAILED\s+", text, flags=re.M))
    passed = len(re.findall(r"^PASSED\s+", text, flags=re.M))
    errors = len(re.findall(r"^ERROR\s+", text, flags=re.M))

total = passed + failed + errors  # errors stay in denominator
if total <= 0:
    try:
        import json
        spec = json.loads(Path("/tests/verifier.json").read_text(encoding="utf-8"))
        total = len(spec.get("verifiers", []))
    except Exception:
        total = 0
    reward = 0.0
else:
    reward = round(passed / total, 10)
    if passed == total and errors == 0 and failed == 0:
        reward = 1.0

Path("/logs/verifier/reward.txt").write_text(f"{reward}\n", encoding="utf-8")
Path("/logs/verifier/reward_meta.txt").write_text(
    f"passed={passed}\nfailed={failed}\nerrors={errors}\nskipped={skipped}\ntotal={total}\nreward={reward}\n",
    encoding="utf-8",
)
print(f"fractional_reward passed={passed} failed={failed} errors={errors} total={total} reward={reward}")
PY

# Always exit 0 so Harbor reads reward.txt (including fractional < 1.0).
exit 0
