# Task

Audit this converted fillable PDF's form fields against our conversion standard. For every converted field, apply the accessible-name rule, the required-flag rule and the duplicate-tab-index rule, and separately confirm every field on the source form's inventory actually made it into the conversion — the required-flag rule works differently for signature fields, so check each field's own type rather than assuming every source-mandatory field needs the flag. Match converted fields to source fields by trimmed `field_name`. Save `pdf_form_audit.csv` with unquoted CSV fields (no pipe `|` characters, no trailing columns beyond the six specified). A blank `tab_index` counts as a shared tab index: two or more fields with blank `tab_index` are `DUPLICATE_TAB_INDEX`. (do not use pipe `|` characters in any field value) `field_id,field_name,field_type,required_flag,tab_index,finding` — one row per converted field starting with the converted field's `field_id` (e.g. FIELD-01) and ending with the `finding` column, plus one row per source field that is missing from the conversion (using `MISSING-<FIELD_NAME_UPPER_WITH_UNDERSCORES>` as the `field_id`, the trimmed source field name in the `field_name` column (strip leading/trailing whitespace from the inventory value), empty values for `field_type`, `required_flag`, and `tab_index`, and `MISSING_FIELD` in the `finding` column). The `required_flag` field accepts only the exact values True, true, and TRUE (case-sensitive; write that token list in the memo as the plain text True, true, and TRUE) as a valid required flag; tokens such as `yes`, `1`, `Y`, or blank are not valid required flags. Use the standard's finding names, `none` where conversion-ready.

CSV representation (converted rows): copy `field_name`, `required_flag`, and `tab_index` exactly as they appear in the converted inventory — preserve leading/trailing whitespace and do not normalize those three columns. Use trimming only (a) when matching a converted `field_name` to the source inventory and (b) when writing the `field_name` value on `MISSING-*` rows. Example: a converted inventory value ` collateral_desc` must appear in the audit CSV as ` collateral_desc`, not `collateral_desc`.

Then write `pdf_form_memo.md` (at least 1000 characters of substantive prose). Do not submit a bare token list. Memo checks reward **unordered token co-occurrence anywhere in the memo** (finding tokens may appear before or after field IDs; section order is free; extra correct detail is allowed). Required tokens:
- MISSING_ACCESSIBLE_NAME plus FIELD-03, FIELD-25, FIELD-47, and blank/empty/whitespace wording
- MISSING_REQUIRED_FLAG plus FIELD-02, FIELD-44, FIELD-46, and False/mandatory wording
- DUPLICATE_TAB_INDEX plus FIELD-04, FIELD-40, and FIELD-41
- ssn_last4, employer_name, preferred_contact (any order), the phrase never converted into the fillable PDF (whitespace-flexible), and MISSING_FIELD
- FIELD-05, the word signature, and the word exempt (literal parenthetical not required)
- True, true, and TRUE plus FIELD-48 and Truee
- last-row-wins (or last row wins) plus FIELD-46 and FIELD-66
- preferred_contact plus must be trimmed before matching


Save `results.json` with keys `flagged_count`, `missing_accessible_name_count`, `missing_required_flag_count`, `duplicate_tab_index_count`, `missing_field_count`.

---

## Working environment

- Your current working directory is `/app`, and it is writable.
- The read-only attachments referred to as `input/` are at `/app/input` (`converted_field_inventory.csv`, `source_form_inventory.csv`, `pdf_conversion_standard.md`).
- Write every deliverable into `/app`, at the exact filenames listed above.
