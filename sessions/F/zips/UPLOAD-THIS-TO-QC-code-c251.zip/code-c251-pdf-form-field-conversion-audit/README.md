# code-c251-pdf-form-field-conversion-audit

Audit a converted fillable PDF's form fields against the conversion standard (FORMS-OPS-5).

## Deliverables
- `pdf_form_audit.csv`
- `pdf_form_memo.md` (≥1000 characters)
- `results.json`

## Gold results
flagged_count=42, missing_accessible_name_count=6, missing_required_flag_count=14, duplicate_tab_index_count=14, missing_field_count=8

## Trap fields (16)
FIELD-44..FIELD-50 plus additional required-flag / duplicate-tab / blank-name / whitespace-trim traps graded in verifier.json.

## Representation
Converted CSV rows echo raw inventory `field_name` / `required_flag` / `tab_index` (whitespace preserved). Trim only for matching and MISSING rows.

