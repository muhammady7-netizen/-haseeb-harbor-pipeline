# code-c251-pdf-form-field-conversion-audit

Audit a converted fillable PDF's form fields against the conversion standard (FORMS-OPS-5).

## Task summary

The agent receives:
- `converted_field_inventory.csv` — the converted PDF's form fields
- `source_form_inventory.csv` — the original source form's field inventory
- `pdf_conversion_standard.md` — the conversion standard

The agent must audit each converted field against:
1. Accessible field names (blank = MISSING_ACCESSIBLE_NAME)
2. Required flag mirroring source (signature fields exempt, last-row-wins for duplicates)
3. No duplicate tab order
4. Every source field must convert (match by trimmed field_name)

## Deliverables

- `pdf_form_audit.csv` — one row per field + MISSING_FIELD rows for unconverted source fields
- `pdf_form_memo.md` — explanation of each finding
- `results.json` — count summary

## Trap fields

- FIELD-44: source type=signature but converted type=text — not exempt, needs required_flag
- FIELD-45: converted type=signature — exempt from required-flag rule
- FIELD-46: duplicate field_id, last-row-wins changes type from signature to text — required-flag applies
- FIELD-47: blank name (MISSING_ACCESSIBLE_NAME has priority over duplicate tab + required flag)
- FIELD-48: required_flag="TRUE" (uppercase, valid)
- FIELD-49: duplicate field_id, last-row-wins changes field_name — affects source matching
- FIELD-50: field_name with leading/trailing spaces — trim before matching
- FIELD-51..FIELD-66: additional densify traps (required-flag / tab / accessible-name / missing-source edges)

## Gold results

flagged_count=42, missing_accessible_name_count=6, missing_required_flag_count=14, duplicate_tab_index_count=14, missing_field_count=8
