#!/bin/bash
mkdir -p /logs/verifier
cd /app || exit 1
python3 -m pytest --ctrf /logs/verifier/ctrf.json /tests/test_outputs.py -rA 2>&1 | tee /logs/verifier/test-stdout.txt
python3 - <<'PY'
import json
import re
from pathlib import Path

sys_path = Path("/tests")
text = Path("/logs/verifier/test-stdout.txt").read_text(encoding="utf-8", errors="replace")
failed_names = []
for m in re.finditer(r"^FAILED\s+\S+::\S+\[([^\]]+)\]", text, flags=re.M):
    failed_names.append(m.group(1))
passed_n = len(re.findall(r"^PASSED\s+", text, flags=re.M))
failed_n = len(re.findall(r"^FAILED\s+", text, flags=re.M))
m = re.search(r"=+\s*(?:(\d+)\s+failed,\s*)?(\d+)\s+passed", text)
if m:
    failed_n = int(m.group(1) or 0)
    passed_n = int(m.group(2) or 0)
total = passed_n + failed_n

spec = json.loads(Path("/tests/verifier.json").read_text(encoding="utf-8"))
verifiers = spec.get("verifiers", [])
# effective weights (same rules as rl_world_verifiers.models.effective_weights)
explicit = {v["name"]: v["metadata"]["weight"] for v in verifiers if v.get("metadata", {}).get("weight") is not None}
explicit_sum = sum(explicit.values())
unweighted = [v["name"] for v in verifiers if v["name"] not in explicit]
weights = dict(explicit)
if unweighted:
    remaining = max(0.0, 1.0 - explicit_sum)
    default = round(remaining / len(unweighted), 10) if unweighted else 0.0
    head = default * (len(unweighted) - 1)
    for i, name in enumerate(unweighted):
        weights[name] = round(remaining - head, 10) if i == len(unweighted) - 1 else default

fail_set = set(failed_names)
# If pytest summary exists but names missing, fall back to passed/total
if total > 0 and (failed_names or failed_n == 0):
    passed_w = sum(w for n, w in weights.items() if n not in fail_set)
    reward = 1.0 if failed_n == 0 and passed_n == total else round(min(passed_w, 1.0), 10)
else:
    reward = 0.0 if total <= 0 else round(passed_n / total, 10)
    if passed_n == total and total > 0:
        reward = 1.0

Path("/logs/verifier/reward.txt").write_text(f"{reward}\n", encoding="utf-8")
Path("/logs/verifier/reward_meta.txt").write_text(
    f"passed={passed_n}\nfailed={failed_n}\ntotal={total}\nreward={reward}\n",
    encoding="utf-8",
)
Path("/logs/verifier/reward.json").write_text(
    json.dumps({"reward": reward, "passed": passed_n, "failed": failed_n, "total": total}, indent=2) + "\n",
    encoding="utf-8",
)
print(f"weighted_reward passed={passed_n} failed={failed_n} total={total} reward={reward}")
PY
exit 0
