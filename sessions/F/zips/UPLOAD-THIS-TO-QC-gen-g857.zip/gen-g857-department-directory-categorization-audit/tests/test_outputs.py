"""Replays the harness `file_check` spec against the task workspace.

One pytest per graded assertion, so Harbor's per-test grid (and the CTRF report)
names exactly which deliverable check failed. The spec in `verifier.json` and the
engine in `rl_world_verifiers/` are copies of what the task harness runs, so a
result here means the same thing it means there.
"""

import os
import sys
from pathlib import Path

import pytest

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR))

from rl_world_verifiers.models import VerifierSpec, effective_weights  # noqa: E402
from rl_world_verifiers.sources.registry import SourceRegistry  # noqa: E402
from rl_world_verifiers.verifiers import verify_definition  # noqa: E402

WORKSPACE = Path(os.environ.get("HARBOR_TASK_WORKSPACE", "/app"))
SPEC = VerifierSpec.model_validate_json(
    (TESTS_DIR / "verifier.json").read_text(encoding="utf-8")
)
WEIGHTS = effective_weights(SPEC.verifiers)
REGISTRY = SourceRegistry(WORKSPACE)


@pytest.mark.parametrize(
    "definition",
    SPEC.verifiers,
    ids=[definition.name for definition in SPEC.verifiers],
)
def test_deliverable(definition):
    outcome = verify_definition(
        definition,
        REGISTRY,
        WEIGHTS[definition.name],
        config=SPEC.config,
        completion_fn=None,
    )["result"]
    detail = outcome.get("error") or outcome.get("reason") or "assertion failed"
    assert outcome["success"], f"{definition.name}: {detail}"


def _g857_totals(workspace: Path) -> dict[str, int]:
    import csv

    path = workspace / "department_directory_audit.csv"
    assert path.is_file(), "department_directory_audit.csv missing"
    findings: dict[str, str] = {}
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        assert reader.fieldnames is not None, "audit CSV missing header"
        fields = [h.strip() for h in reader.fieldnames]
        assert fields[:3] == ["dept_id", "dept_name", "finding"], (
            f"unexpected audit header {reader.fieldnames!r}"
        )
        for row in reader:
            did = (row.get("dept_id") or "").strip()
            if did:
                findings[did] = (row.get("finding") or "").strip()
    return {
        "department_count": len(findings),
        "missing_from_chart_count": sum(
            1 for v in findings.values() if v == "MISSING_FROM_CHART"
        ),
        "misplaced_department_count": sum(
            1 for v in findings.values() if v == "MISPLACED_DEPARTMENT"
        ),
        "duplicate_id_count": sum(1 for v in findings.values() if v == "DUPLICATE_ID"),
        "compliant_count": sum(1 for v in findings.values() if v == "none"),
    }


def test_results_recomputed_from_audit():
    import json

    totals = _g857_totals(WORKSPACE)
    path = WORKSPACE / "results.json"
    assert path.is_file(), "results.json missing"
    data = json.loads(path.read_text(encoding="utf-8"))
    for key, expected in totals.items():
        assert data.get(key) == expected, (
            f"results.json {key}={data.get(key)!r} != audit-derived {expected!r}"
        )


def test_audit_unique_dept_count_matches_results():
    import json

    totals = _g857_totals(WORKSPACE)
    data = json.loads((WORKSPACE / "results.json").read_text(encoding="utf-8"))
    assert totals["department_count"] == data["department_count"]
    assert (
        totals["missing_from_chart_count"]
        + totals["misplaced_department_count"]
        + totals["duplicate_id_count"]
        + totals["compliant_count"]
        == totals["department_count"]
    )
