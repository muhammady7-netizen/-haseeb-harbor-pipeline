"""Replays verifier.json — one pytest per graded assertion."""
import os, sys
from pathlib import Path
import pytest
TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR))
from rl_world_verifiers.models import VerifierSpec, effective_weights
from rl_world_verifiers.sources.registry import SourceRegistry
from rl_world_verifiers.verifiers import verify_definition
WORKSPACE = Path(os.environ.get("HARBOR_TASK_WORKSPACE", "/app"))
SPEC = VerifierSpec.model_validate_json((TESTS_DIR / "verifier.json").read_text(encoding="utf-8"))
WEIGHTS = effective_weights(SPEC.verifiers)
REGISTRY = SourceRegistry(WORKSPACE)
@pytest.mark.parametrize("definition", SPEC.verifiers, ids=[d.name for d in SPEC.verifiers])
def test_deliverable(definition):
    outcome = verify_definition(
        definition, REGISTRY, WEIGHTS[definition.name], config=SPEC.config, completion_fn=None
    )["result"]
    detail = outcome.get("error") or outcome.get("reason") or "assertion failed"
    assert outcome["success"], f"{definition.name}: {detail}"
