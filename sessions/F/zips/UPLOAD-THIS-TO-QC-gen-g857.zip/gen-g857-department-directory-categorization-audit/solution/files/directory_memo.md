# Department directory categorization audit

64 unique departments after registry last-wins collapse. 24 compliant (`none`), 3 `MISSING_FROM_CHART`, 22 `MISPLACED_DEPARTMENT`, 15 `DUPLICATE_ID`.

Parent names were resolved through `division_alias.csv` with case-insensitive alias matching and last matching alias wins, then compared case-insensitively (`Finance`/`FINANCE`, `Central Ops`/`central ops`). Trim removes only leading/trailing whitespace — internal spaces in a `registry_id` stay significant (`RID IN` ≠ `RIDIN`). Transitional review is affirmative only for the trimmed exact token `true` / `TRUE` / `True` / `TrUe` (case-insensitive exact), not `Truee` / `TRUE!` / `truex` / `yes`, and only when the resolved slide parent equals a non-empty resolved prior parent (whitespace-only prior never grants the exception).

| Department | Finding |
|---|---|
| DEPT-01 | MISSING_FROM_CHART |
| DEPT-02 | none |
| DEPT-03 | MISPLACED_DEPARTMENT |
| DEPT-04 | none |
| DEPT-05 | none |
| DEPT-06 | DUPLICATE_ID |
| DEPT-07 | none |
| DEPT-08 | none |
| DEPT-09 | DUPLICATE_ID |
| DEPT-10 | MISSING_FROM_CHART |
| DEPT-11 | MISPLACED_DEPARTMENT |
| DEPT-12 | MISPLACED_DEPARTMENT |
| DEPT-13 | MISPLACED_DEPARTMENT |
| DEPT-14 | none |
| DEPT-15 | none |
| DEPT-16 | MISPLACED_DEPARTMENT |
| DEPT-17 | MISPLACED_DEPARTMENT |
| DEPT-18 | MISPLACED_DEPARTMENT |
| DEPT-19 | MISPLACED_DEPARTMENT |
| DEPT-20 | MISPLACED_DEPARTMENT |
| DEPT-21 | none |
| DEPT-22 | none |
| DEPT-23 | none |
| DEPT-24 | MISPLACED_DEPARTMENT |
| DEPT-25 | none |
| DEPT-26 | none |
| DEPT-27 | MISPLACED_DEPARTMENT |
| DEPT-28 | DUPLICATE_ID |
| DEPT-29 | DUPLICATE_ID |
| DEPT-30 | none |
| DEPT-31 | DUPLICATE_ID |
| DEPT-32 | DUPLICATE_ID |
| DEPT-33 | none |
| DEPT-34 | none |
| DEPT-35 | MISPLACED_DEPARTMENT |
| DEPT-36 | none |
| DEPT-37 | MISPLACED_DEPARTMENT |
| DEPT-38 | none |
| DEPT-39 | none |
| DEPT-40 | MISPLACED_DEPARTMENT |
| DEPT-41 | DUPLICATE_ID |
| DEPT-42 | DUPLICATE_ID |
| DEPT-43 | DUPLICATE_ID |
| DEPT-44 | MISPLACED_DEPARTMENT |
| DEPT-45 | MISPLACED_DEPARTMENT |
| DEPT-46 | none |
| DEPT-47 | MISPLACED_DEPARTMENT |
| DEPT-48 | MISPLACED_DEPARTMENT |
| DEPT-49 | MISPLACED_DEPARTMENT |
| DEPT-50 | MISPLACED_DEPARTMENT |
| DEPT-51 | none |
| DEPT-52 | MISSING_FROM_CHART |
| DEPT-53 | none |
| DEPT-54 | none |
| DEPT-55 | none |
| DEPT-56 | MISPLACED_DEPARTMENT |
| DEPT-57 | none |
| DEPT-58 | DUPLICATE_ID |
| DEPT-59 | DUPLICATE_ID |
| DEPT-60 | MISPLACED_DEPARTMENT |
| DEPT-61 | DUPLICATE_ID |
| DEPT-62 | DUPLICATE_ID |
| DEPT-63 | DUPLICATE_ID |
| DEPT-64 | DUPLICATE_ID |

## Last-wins on the registry

DEPT-01 appears twice. The first row would look misplaced under Administration; the last row wins and has an empty slide parent, so the finding is `MISSING_FROM_CHART` (`MISSING_FROM_CHART`). DEPT-60 likewise last-wins from a clean General Services row to Administration → `MISPLACED_DEPARTMENT` (`MISPLACED_DEPARTMENT`).

## Duplicate registry ids

DEPT-06 and DEPT-09 share `RID-DUP`; DEPT-28 and DEPT-29 share `RID-DUP2`; DEPT-31 and DEPT-32 share `RID-SP` after trim on the spaced id; DEPT-41 / DEPT-42 / DEPT-43 share `RID-TRIP`; DEPT-58 / DEPT-59 share `RID-Q` after trim; DEPT-61 / DEPT-62 share `RID-SEAL` and stay `DUPLICATE_ID` even with affirmative transitional review and matching prior. DEPT-63 / DEPT-64 share `RID-DUP3`; DEPT-63 last-wins to a row with matching Operations parents that would otherwise be `none`, and DEPT-64 has matching Finance parents, but both are `DUPLICATE_ID` because duplicate-id precedence overrides every other rule - a department with a colliding id is `DUPLICATE_ID` even when its placement would otherwise look clean. Blank or whitespace-only registry ids do not collide and do not duplicate: DEPT-25 / DEPT-26 are blank and DEPT-33 is whitespace-only after trim. Internal spaces are significant, so DEPT-53 (`RID IN`) and DEPT-54 (`RIDIN`) do not collide.

## Missing vs literal slide parents

DEPT-10 has whitespace-only `slide_parent` and DEPT-52 has a tab-only `slide_parent` → both `MISSING_FROM_CHART`. DEPT-11 / DEPT-12 / DEPT-13 use literal `N/A`, `none`, and `-`; DEPT-37 uses spaced ` N/A `; DEPT-47 uses spaced ` - `; DEPT-48 uses lowercase `n/a`. Those literals are not missing from the chart — they remain non-empty after trim, so they are present on the slide and grade as `MISPLACED_DEPARTMENT`.

## Alias resolution and Ops last-wins

DEPT-14 (`Admin`), DEPT-36 (`ADMIN` case variant), DEPT-15 (`GS` / spaced general services), DEPT-38 (`HR` → Human Resources), and DEPT-55 (`Fin` → Finance) resolve clean. Alias last-wins maps `Ops` to `Central Ops`: DEPT-39 (registry Ops, slide Central Ops) and DEPT-57 (slide `central ops`, case-insensitive equality) are `none`, while DEPT-27 / DEPT-40 / DEPT-56 (slide Ops, Operations, or unaliased `operations` against resolved Central Ops) are `MISPLACED_DEPARTMENT`. DEPT-46 (`FINANCE` vs `Finance`) is `none` on case-insensitive parent equality alone.

## Transitional-review exception

Affirmative token is only the exact case-insensitive `true` family. DEPT-05 (`True`), DEPT-21 (`TRUE` with `Fac Svcs`), DEPT-30 (` True `), DEPT-34 (`TrUe`), and DEPT-51 (` TRUE ` with prior `Fac Svcs`) stay `none` when slide equals prior. DEPT-16 (`yes`), DEPT-17 (`1`), DEPT-18 (`Y`), DEPT-44 (`truex`), DEPT-49 (`Truee`), and DEPT-50 (`TRUE!`) are not affirmative → `MISPLACED_DEPARTMENT`. DEPT-19 has blank prior, DEPT-35 has whitespace-only prior after trim, and DEPT-20 sits under a third parent — all remain misplaced despite a true-family flag.

## Ordinary misplacements and cleans

DEPT-03, DEPT-24, DEPT-45, and DEPT-60 are ordinary misplacements. DEPT-02, DEPT-04, DEPT-07, DEPT-08, DEPT-22, DEPT-23, DEPT-25, DEPT-26, DEPT-33, DEPT-53, and DEPT-54 are `none` without needing the transitional exception.
