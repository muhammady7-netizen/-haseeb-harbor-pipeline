# Department Taxonomy Migration

Move directory entries into a new department hierarchy and identify ambiguous placements.

## Inputs

- `g857_people.csv`: `person_id,legacy_department,role_code` — one row per person. `person_id` values are unique; reject any output that repeats a `person_id`.
- `g857_taxonomy.json`: a JSON object with a `nodes` array; each node has `node_id`, `parent` (node_id or `null` for root), `depth` (integer), and `allowed_roles` (array of role codes this node accepts).
- `g857_crosswalk.csv`: `legacy_department,target_node,confidence` — candidate mappings from legacy departments to taxonomy nodes with a confidence score (float, 0.0–1.0).

## Required work

1. **Detect taxonomy cycles.** Build the parent→child tree from `g857_taxonomy.json` by following each node's `parent`. If any node is an ancestor of itself, the taxonomy has a cycle: write `g857_mappings.csv` with one row per person where `target_node` is `UNMAPPED`, `confidence` is blank (empty field), and `status` is `CYCLE_DETECTED`; write `g857_unmapped.csv` with every person (`person_id,legacy_department,role_code`); write `g857_headcount.json` with every taxonomy `node_id` set to `{"direct_count": 0, "rolled_up_count": 0}`; then stop.
2. **For each person**, find all crosswalk rows where `legacy_department` matches the person's `legacy_department`. Among those, select the one whose `target_node` appears in the taxonomy and whose `allowed_roles` includes the person's `role_code`. If multiple qualify, pick the one with the highest `confidence`. Ties in confidence are broken by deepest `depth` (larger depth wins). Further ties broken by `node_id` (lexicographically smallest wins).
3. If no role-compatible mapping exists (either no crosswalk row for that legacy_department, or the target node does not allow the person's role), the person is unmapped: `target_node` is `UNMAPPED`, `confidence` is blank (empty field), `status` is `NO_ROLE_MATCH`.
4. **Roll up headcount.** For each taxonomy node, `direct_count` is the number of people mapped to it (`status`=`MAPPED`). `rolled_up_count` equals `direct_count` plus the sum of `rolled_up_count` of all direct children (nodes whose `parent` is this node). Every node must appear in the headcount object.
5. Mapped persons have `status` = `MAPPED` and a concrete taxonomy `target_node` (never `UNMAPPED`). Allowed status labels are exactly: `MAPPED`, `NO_ROLE_MATCH`, `CYCLE_DETECTED`.

## Deliverables

- `g857_mappings.csv`: header exactly `person_id,target_node,confidence,status` — one row per input person, no duplicate `person_id`, no extra columns.
- `g857_headcount.json`: object mapping each `node_id` to exactly `{"direct_count": <int>, "rolled_up_count": <int>}` (finite integers only). Include all taxonomy nodes even if counts are 0.
- `g857_unmapped.csv`: header exactly `person_id,legacy_department,role_code` — one row per person with `status` `NO_ROLE_MATCH` or `CYCLE_DETECTED`, no extra columns.

## Verification

Validate acyclic hierarchy (or the cycle abort outputs), depths, role rules, mapping ties, ancestor totals, unique person keys, exact schemas, finite numbers, declared status labels only, and headcount totals that reconcile to mapping rows and to the parent/child tree.

Do not invent missing records. Save the complete deliverable set under `/app`.

## Output encoding (required)

- **Unmapped confidence:** for `NO_ROLE_MATCH` or `CYCLE_DETECTED` rows in `g857_mappings.csv`, leave the `confidence` field empty (write `UNMAPPED,,NO_ROLE_MATCH` — not `0`).
- **Mapped confidence formatting:** write the selected crosswalk confidence with insignificant trailing zeros stripped (example: crosswalk `0.90` → output `0.9`; `0.92` stays `0.92`).
- **Trailing newlines:** every CSV deliverable must end with a trailing newline after the last data row.
- **Headcount JSON key order:** each node object must serialize `direct_count` before `rolled_up_count`, e.g. `{"direct_count": 1, "rolled_up_count": 2}`.
