# Task

Audit the master department registry against the current org-chart slide fields
before republishing the chart. The standard is binding, including any other files
it names. For each unique department, determine whether its registry id collides,
whether it appears on the chart, whether it sits under the correct parent division,
and whether a transitional-review exception applies — a department under transitional
review follows a different placement rule than an ordinary one. Save
`department_directory_audit.csv` with one row per unique department and a `finding`
column (`MISSING_FROM_CHART`, `MISPLACED_DEPARTMENT`, `DUPLICATE_ID`, `none`). Then
write `directory_memo.md` explaining each finding class you assigned and the
transitional-review exception, including the trim, alias last-wins, blank-id, and
literal slide-parent edge cases the standard calls out. Also provide `results.json`
with `department_count`, `missing_from_chart_count`, `misplaced_department_count`,
`duplicate_id_count`, and `compliant_count` derived from the completed audit. Leave
those three files in the working directory you start in; do not nest them in an
`output` folder.
