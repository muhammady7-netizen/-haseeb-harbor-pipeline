# Department Taxonomy Migration

Move directory entries into a new department hierarchy and identify ambiguous placements.

## Inputs

- `g857_people.csv`: `person_id,legacy_department,role_code` — one row per person.
- `g857_taxonomy.json`: a JSON object with a `nodes` array; each node has `node_id`, `parent` (node_id or `null` for root), `depth` (integer), and `allowed_roles` (array of role codes this node accepts).
- `g857_crosswalk.csv`: `legacy_department,target_node,confidence` — candidate mappings from legacy departments to taxonomy nodes with a confidence score (float, 0.0–1.0).

## Required work

1. **Detect taxonomy cycles.** Build the parent→child tree from `g857_taxonomy.json` by following each node's `parent`. If any node is an ancestor of itself, stop: write `g857_mappings.csv` with one row per person (`target_node`=`UNMAPPED`, `confidence` blank, `status`=`CYCLE_DETECTED`); write `g857_unmapped.csv` with every person (`person_id,legacy_department,role_code`); write `g857_headcount.json` with every taxonomy `node_id` set to `{"direct_count": 0, "rolled_up_count": 0}`.
2. **For each person**, find all crosswalk rows where `legacy_department` matches the person's `legacy_department`. Among those, select the one whose `target_node` appears in the taxonomy and whose `allowed_roles` includes the person's `role_code`. If multiple qualify, pick the one with the highest `confidence`. Ties in confidence are broken by deepest `depth` (larger depth wins). Further ties broken by `node_id` (lexicographically smallest wins).
3. If no role-compatible mapping exists (either no crosswalk row for that legacy_department, or the target node does not allow the person's role), the person is `UNMAPPED` with `status` set to `NO_ROLE_MATCH`.
4. **Roll up headcount.** For each taxonomy node, `direct_count` is the number of people mapped to it. `rolled_up_count` is `direct_count` plus the sum of `rolled_up_count` of all direct children. Root nodes' `rolled_up_count` equals their subtree total.
5. Mapped persons have `status` = `MAPPED`.

## Deliverables

- `g857_mappings.csv`: `person_id,target_node,confidence,status` — one row per person, header exactly `person_id,target_node,confidence,status`.
- `g857_headcount.json`: a JSON object mapping each `node_id` to `{"direct_count": N, "rolled_up_count": N}`. Include all taxonomy nodes even if `direct_count` is 0.
- `g857_unmapped.csv`: `person_id,legacy_department,role_code` — one row per unmapped person.

## Verification

Validate acyclic hierarchy, depths, role rules, mapping ties, ancestor totals, and one mapping outcome per person. The verifier rejects duplicate primary keys, unexpected columns in exact-schema outputs, nonfinite numbers, undeclared status labels, and summary totals that do not reconcile to row-level values.

Do not invent missing records. Do not use pipe `|` characters in any CSV field value. Save the complete deliverable set under `/app`.

`g857_unmapped.csv` must list exactly the people whose mapping `status` is `NO_ROLE_MATCH` or `CYCLE_DETECTED`, copying `person_id`, `legacy_department`, and `role_code` from `g857_people.csv` (one row per such person; do not fabricate rows).

## Output encoding (required)

- For `NO_ROLE_MATCH` / `CYCLE_DETECTED` rows, leave `confidence` blank (`UNMAPPED,,NO_ROLE_MATCH`), not `0`.
- Write mapped confidence with insignificant trailing zeros stripped (e.g. crosswalk `0.90` → `0.9`).
- End every CSV with a trailing newline. In headcount JSON, serialize `direct_count` before `rolled_up_count` for each node.
