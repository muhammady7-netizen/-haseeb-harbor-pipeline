# Department directory governance standard (DDG-1)

Binding for the master department registry export before the org-chart slide is
republished. A department's `finding` is decided by these rules alone; informal
notes in the export are not authoritative.

Before any match, **trim leading and trailing whitespace** on `dept_id`,
`dept_name`, `registry_id`, `registry_parent`, `slide_parent`, `prior_parent`,
`transitional_review`, and on every `alias` / `canonical_division` value in
`division_alias.csv`. Trim does **not** remove internal spaces — after trim,
`RID IN` and `RIDIN` remain different registry ids.

If the registry export contains more than one row for the same `dept_id` (after
trim), the **last row in the file wins** for every field on that department.
Derived `department_count` counts unique departments after that last-wins
collapse.

## 1. Parent name resolution

Resolve `registry_parent`, `slide_parent`, and `prior_parent` through
`division_alias.csv` before any placement comparison:

1. Match the trimmed parent string to `alias` **case-insensitively**.
2. If more than one alias row matches, the **last matching row in the file wins**.
3. Use that row's `canonical_division` (trimmed) as the resolved parent.
4. If **no** alias row matches, the trimmed parent string itself is the resolved
   parent.

Parent equality is **case-insensitive** on the resolved names
(`Operations` and `operations` are the same division; `Finance` and `FINANCE`
are the same; `Central Ops` and `central ops` are the same).

## 2. Duplicate registry ids (highest precedence)

A department whose trimmed `registry_id` is shared by **two or more** distinct
departments (after last-wins collapse) is `DUPLICATE_ID`. Blank / empty
`registry_id` values **do not** participate in duplicate detection — two blank
ids are not a collision, and a value that is only whitespace becomes blank after
trim and likewise does not collide. Duplicate-id is checked before every other
rule; a department with a colliding id is `DUPLICATE_ID` even if its slide
placement would otherwise look fine, look missing, or carry an affirmative
transitional-review flag.

## 3. Presence on the chart

After trim, a department whose `slide_parent` is **empty** is
`MISSING_FROM_CHART`. Checked after duplicate-id, before placement. A
whitespace-only or tab-only `slide_parent` is empty after trim.

A non-empty trimmed `slide_parent` — including literal tokens such as `N/A`,
`n/a`, `none`, or `-` (with or without surrounding spaces that trim away) —
means the department **appears** on the slide. Those literals are **not**
treated as missing; they fall through to the placement rule and will normally
be `MISPLACED_DEPARTMENT` unless they resolve (via alias) to the registry
parent.

## 4. Correct placement

A department that appears on the slide (non-empty trimmed `slide_parent`) whose
resolved slide parent differs from its resolved registry parent is
`MISPLACED_DEPARTMENT`.

## 5. The transitional-review exception

Treat `transitional_review` as affirmative **only** when the trimmed value is
exactly `true` / `TRUE` / `True` (case-insensitive exact token — so `TrUe` and
` TRUE ` after trim count, but `yes`, `1`, `Y`, `truex`, `Truee`, `TRUE!`,
`TRUE` with extra characters, or `transitional` do not). Blank and
`false` / `False` / `no` are not affirmative.

When transitional review is affirmative, the department may remain on the slide
under its **prior** parent rather than the registry's newly designated parent,
until the review closes — that is not a misplacement. The exception applies
only when:

1. transitional review is affirmative under the token rule above, **and**
2. the trimmed `prior_parent` is non-empty (whitespace-only prior is empty after
   trim and never grants the exception), **and**
3. the resolved slide parent equals the resolved prior parent.

If the slide sits under some third division (neither registry parent nor prior
parent after resolution), it is still `MISPLACED_DEPARTMENT`. A blank
`prior_parent` never grants the exception. Flagging a qualifying
transitional-review department as misplaced is the commonest false positive in
this audit.

## Finding names

`DUPLICATE_ID`, `MISSING_FROM_CHART`, `MISPLACED_DEPARTMENT`, `none`, in that
precedence order. Each department gets exactly one finding.

## Deliverable shape

`department_directory_audit.csv` must have exactly the header
`dept_id,dept_name,finding` and **one data row per unique department** after
registry last-wins (no extra blank rows).

## Derived totals

Computed from the completed audit after last-wins collapse:

- `department_count`: number of unique departments
- `missing_from_chart_count`: rows with finding `MISSING_FROM_CHART`
- `misplaced_department_count`: rows with finding `MISPLACED_DEPARTMENT`
- `duplicate_id_count`: rows with finding `DUPLICATE_ID`
- `compliant_count`: rows with finding `none`
