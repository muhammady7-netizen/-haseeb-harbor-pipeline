# gen-g857 — Department Taxonomy Migration

Map 64 directory people into a 25-node taxonomy via crosswalk confidence, role filters, and tie-breaks (confidence → depth → lex).

## Deliverables
- `g857_mappings.csv`
- `g857_headcount.json`
- `g857_unmapped.csv` (6 expected unmapped)

## Checks
122 deterministic verifier checks.
