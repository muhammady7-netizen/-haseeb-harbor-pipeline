# Department directory categorization audit

Before republishing the org-chart slide, audit the master department registry
against the current slide fields. The governance standard is binding, including
any other files it names.

## Deliverables

1. `department_directory_audit.csv` — one row per unique department with a `finding`
   column (`MISSING_FROM_CHART`, `MISPLACED_DEPARTMENT`, `DUPLICATE_ID`, `none`)
2. `directory_memo.md` — explains each finding class and the transitional-review
   exception
3. `results.json` — derived counts

## Inputs

- `input/department_directory_governance_standard.md` — binding standard
- `input/department_registry.csv` — master registry
- `input/division_alias.csv` — division alias register

## Working environment

- Working directory is `/app` (writable).
- Read-only inputs are at `/app/input`.
- Write deliverables to `/app` using the exact filenames above.
