"""Structured validation for code-c227 table bloat maintenance audit.

Replaces regex-based verifier.json checks with proper CSV/JSON parsing:
- Validates exact CSV schema, unique rows, no extras
- Validates each table's finding, size_class, bloat_ratio fields
- Reconciles results.json counts with CSV content
- Checks memo for substantive explanations (not token stuffing)
- Core gate: missing deliverable = 0 reward
"""

import os
import sys
import json
import csv
import re
from pathlib import Path
from collections import Counter
import math

import pytest

WORKSPACE = Path(os.environ.get("HARBOR_TASK_WORKSPACE", "/app"))

# Expected gold answers (from policy + inputs)
def _round_half_up(n, decimals=2):
    multiplier = 10 ** decimals
    return math.floor(n * multiplier + 0.5) / multiplier

EXPECTED_TABLES = {
    "T-01": {"size_class": "large", "bloat_ratio": 0.1, "finding": "none"},
    "T-02": {"size_class": "large", "bloat_ratio": 0.35, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-03": {"size_class": "large", "bloat_ratio": 0.15, "finding": "AUTOVACUUM_DISABLED"},
    "T-04": {"size_class": "large", "bloat_ratio": 0.1, "finding": "STALE_STATISTICS"},
    "T-05": {"size_class": "large", "bloat_ratio": 0.55, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-06": {"size_class": "large", "bloat_ratio": 0.25, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-07": {"size_class": "large", "bloat_ratio": 0.12, "finding": "none"},
    "T-08": {"size_class": "large", "bloat_ratio": 0.45, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-09": {"size_class": "large", "bloat_ratio": 0.19, "finding": "none"},
    "T-10": {"size_class": "large", "bloat_ratio": 0.21, "finding": "STALE_STATISTICS"},
    "T-11": {"size_class": "large", "bloat_ratio": 0.41, "finding": "AUTOVACUUM_DISABLED"},
    "T-12": {"size_class": "large", "bloat_ratio": 0.2, "finding": "none"},
    "T-13": {"size_class": "large", "bloat_ratio": 0.5, "finding": "AUTOVACUUM_DISABLED"},
    "T-14": {"size_class": "large", "bloat_ratio": 0.4, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-15": {"size_class": "large", "bloat_ratio": 0.2, "finding": "none"},
    "T-16": {"size_class": "large", "bloat_ratio": 0.2, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-17": {"size_class": "large", "bloat_ratio": 0.4, "finding": "AUTOVACUUM_DISABLED"},
    "T-18": {"size_class": "large", "bloat_ratio": 0.21, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-19": {"size_class": "large", "bloat_ratio": 0.41, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-20": {"size_class": "large", "bloat_ratio": 0.1, "finding": "AUTOVACUUM_DISABLED"},
    "T-21": {"size_class": "large", "bloat_ratio": 0.2, "finding": "AUTOVACUUM_DISABLED"},
    "T-26": {"size_class": "large", "bloat_ratio": 0.18, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-27": {"size_class": "large", "bloat_ratio": 0.38, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-28": {"size_class": "large", "bloat_ratio": 0.25, "finding": "none"},
    "T-29": {"size_class": "large", "bloat_ratio": 0.25, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-30": {"size_class": "large", "bloat_ratio": 0.2, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-31": {"size_class": "small", "bloat_ratio": 0.3, "finding": "none"},
    "T-32": {"size_class": "small", "bloat_ratio": 0.4, "finding": "none"},
    "T-33": {"size_class": "small", "bloat_ratio": 0.21, "finding": "none"},
    "T-34": {"size_class": "large", "bloat_ratio": 0.2, "finding": "none"},
    "T-35": {"size_class": "large", "bloat_ratio": 0.22, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-36": {"size_class": "large", "bloat_ratio": 0.18, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-37": {"size_class": "large", "bloat_ratio": 0.25, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-38": {"size_class": "small", "bloat_ratio": 0.33, "finding": "none"},
    "T-39": {"size_class": "large", "bloat_ratio": 0.05, "finding": "AUTOVACUUM_DISABLED"},
    "T-40": {"size_class": "large", "bloat_ratio": 0.05, "finding": "STALE_STATISTICS"},
    "T-41": {"size_class": "small", "bloat_ratio": 0.4, "finding": "none"},
    "T-42": {"size_class": "large", "bloat_ratio": 0.2, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
    "T-43": {"size_class": "small", "bloat_ratio": 0.21, "finding": "none"},
    "T-44": {"size_class": "large", "bloat_ratio": 0.83, "finding": "BLOAT_THRESHOLD_EXCEEDED"},
}

EXPECTED_RESULTS = {
    "flagged_count": 27,
    "autovacuum_disabled_count": 7,
    "bloat_exceeded_count": 17,
    "stale_statistics_count": 3,
    "compliant_count": 13,
}

REQUIRED_HEADER = ["table_name", "size_class", "bloat_ratio", "finding"]
VALID_FINDINGS = {"AUTOVACUUM_DISABLED", "BLOAT_THRESHOLD_EXCEEDED", "STALE_STATISTICS", "none"}
SIZE_CLASS_CAPS = {"large": 0.2, "small": 0.4}

# Short tokens that alone are too weak to count as a "substantive concept"
_WEAK_CONCEPTS = {
    "bloat", "cap", "none", "over", "exceed", "first", "size", "class",
    "total", "large", "small", "days", "field", "wrong", "incorrect",
}

_FINDING_CANONICAL = {
    "autovacuum_disabled": "AUTOVACUUM_DISABLED",
    "bloat_threshold_exceeded": "BLOAT_THRESHOLD_EXCEEDED",
    "stale_statistics": "STALE_STATISTICS",
    "bloat": "BLOAT_THRESHOLD_EXCEEDED",  # only when concept is exactly "BLOAT" (handled below)
    "none": "none",
}


def _load_csv():
    """Load and parse bloat_audit.csv with full validation."""
    path = WORKSPACE / "bloat_audit.csv"
    if not path.is_file():
        return None, "bloat_audit.csv not found"
    try:
        with open(path, encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            if reader.fieldnames != REQUIRED_HEADER:
                return None, f"Header mismatch: got {reader.fieldnames}, expected {REQUIRED_HEADER}"
            rows = list(reader)
            return rows, None
    except Exception as e:
        return None, f"CSV parse error: {e}"


def _load_json():
    """Load results.json."""
    path = WORKSPACE / "results.json"
    if not path.is_file():
        return None, "results.json not found"
    try:
        return json.loads(path.read_text(encoding="utf-8")), None
    except Exception as e:
        return None, f"JSON parse error: {e}"


def _load_memo():
    """Load bloat_memo.md."""
    path = WORKSPACE / "bloat_memo.md"
    if not path.is_file():
        return None, "bloat_memo.md not found"
    return path.read_text(encoding="utf-8"), None


def _parse_ratio(val):
    """Parse a bloat ratio string to float, accepting 0.2 = 0.20 = 0.200."""
    try:
        return float(str(val).strip())
    except (ValueError, TypeError):
        return None


def _prose_lines(memo):
    """Return non-table prose lines (skip markdown table rows with pipes)."""
    lines = []
    for line in memo.split("\n"):
        stripped = line.strip()
        if not stripped:
            continue
        # Skip markdown table rows / separators
        if stripped.startswith("|") or (stripped.count("|") >= 2):
            continue
        lines.append(stripped)
    return lines


def _normalize_finding_token(concept):
    """Return canonical finding code if concept is a finding token, else None."""
    c = concept.strip()
    cu = c.upper().replace(" ", "_").replace("-", "_")
    if cu in ("AUTOVACUUM_DISABLED", "BLOAT_THRESHOLD_EXCEEDED", "STALE_STATISTICS", "NONE"):
        return "none" if cu == "NONE" else cu
    # Exact uppercase BLOAT alias (not bare lowercase "bloat")
    if c == "BLOAT":
        return "BLOAT_THRESHOLD_EXCEEDED"
    if c == "STALE":
        return "STALE_STATISTICS"
    return None


def _is_substantive(concept):
    """True if concept is strong enough to count toward the 2-concept requirement."""
    if _normalize_finding_token(concept):
        return False
    low = concept.strip().lower()
    if low in _WEAK_CONCEPTS:
        return False
    # Very short bare tokens are not substantive on their own
    if len(low) <= 3 and not any(ch.isdigit() for ch in low):
        return False
    return True


# ============ CORE GATE TESTS (must pass for any reward) ============

def test_audit_exists():
    """bloat_audit.csv must exist."""
    rows, err = _load_csv()
    assert rows is not None, f"Core gate: {err}"


def test_memo_exists():
    """bloat_memo.md must exist."""
    memo, err = _load_memo()
    assert memo is not None, f"Core gate: {err}"


def test_results_exists():
    """results.json must exist."""
    data, err = _load_json()
    assert data is not None, f"Core gate: {err}"


def test_audit_header():
    """CSV must have exactly the required header."""
    rows, err = _load_csv()
    assert err is None, err
    # Header already validated in _load_csv via DictReader fieldnames check
    assert len(rows) > 0, "CSV has no data rows"


def test_audit_exact_row_count():
    """CSV must have exactly 40 data rows (no extra, no missing)."""
    rows, err = _load_csv()
    assert err is None, err
    assert len(rows) == 40, f"Expected 40 rows, got {len(rows)}"


def test_audit_no_duplicates():
    """Each table_name must appear exactly once."""
    rows, err = _load_csv()
    assert err is None, err
    names = [r.get("table_name", "").strip() for r in rows]
    counts = Counter(names)
    dupes = {k: v for k, v in counts.items() if v > 1}
    assert not dupes, f"Duplicate table_name entries: {dupes}"


def test_audit_all_tables_present():
    """All expected tables must be present."""
    rows, err = _load_csv()
    assert err is None, err
    actual = {r.get("table_name", "").strip() for r in rows}
    expected = set(EXPECTED_TABLES.keys())
    missing = expected - actual
    extra = actual - expected
    assert not missing, f"Missing tables: {missing}"
    assert not extra, f"Unexpected extra tables: {extra}"


def test_audit_valid_findings():
    """All findings must be valid finding codes."""
    rows, err = _load_csv()
    assert err is None, err
    for row in rows:
        finding = row.get("finding", "").strip()
        assert finding in VALID_FINDINGS, f"Invalid finding '{finding}' for {row.get('table_name')}"


# ============ PER-TABLE VALIDATION (field-level) ============

@pytest.mark.parametrize("table_id", sorted(EXPECTED_TABLES.keys()))
def test_table_finding(table_id):
    """Each table's finding must match the expected gold answer."""
    rows, err = _load_csv()
    assert err is None, err
    row = next((r for r in rows if r.get("table_name", "").strip() == table_id), None)
    assert row is not None, f"Table {table_id} not found in audit"
    expected = EXPECTED_TABLES[table_id]["finding"]
    actual = row.get("finding", "").strip()
    assert actual == expected, f"{table_id}: expected {expected}, got {actual}"


@pytest.mark.parametrize("table_id", sorted(EXPECTED_TABLES.keys()))
def test_table_size_class(table_id):
    """Each table's size_class must match the input data."""
    rows, err = _load_csv()
    assert err is None, err
    row = next((r for r in rows if r.get("table_name", "").strip() == table_id), None)
    assert row is not None, f"Table {table_id} not found"
    expected = EXPECTED_TABLES[table_id]["size_class"]
    actual = row.get("size_class", "").strip().lower()
    assert actual == expected, f"{table_id}: expected size_class={expected}, got {actual}"


@pytest.mark.parametrize("table_id", sorted(EXPECTED_TABLES.keys()))
def test_table_bloat_ratio(table_id):
    """Each table's bloat_ratio must match the input data (numeric equivalence)."""
    rows, err = _load_csv()
    assert err is None, err
    row = next((r for r in rows if r.get("table_name", "").strip() == table_id), None)
    assert row is not None, f"Table {table_id} not found"
    expected = EXPECTED_TABLES[table_id]["bloat_ratio"]
    actual = _parse_ratio(row.get("bloat_ratio"))
    assert actual is not None, f"{table_id}: cannot parse bloat_ratio '{row.get('bloat_ratio')}'"
    assert abs(actual - expected) < 1e-9, f"{table_id}: expected bloat_ratio={expected}, got {actual}"


# ============ RESULTS.JSON RECONCILIATION ============

def test_results_matches_expected():
    """Authoritative results.json reconciliation: gold keys + CSV-derived counts.

    Single test covers all five count keys so one wrong flagged_count fails once,
    not four redundant per-key tests.
    """
    rows, err = _load_csv()
    assert err is None, err
    data, jerr = _load_json()
    assert jerr is None, jerr

    missing = set(EXPECTED_RESULTS) - set(data)
    assert not missing, f"Missing keys in results.json: {missing}"

    csv_counts = {
        "flagged_count": sum(1 for r in rows if r.get("finding", "").strip() != "none"),
        "autovacuum_disabled_count": sum(
            1 for r in rows if r.get("finding", "").strip() == "AUTOVACUUM_DISABLED"
        ),
        "bloat_exceeded_count": sum(
            1 for r in rows if r.get("finding", "").strip() == "BLOAT_THRESHOLD_EXCEEDED"
        ),
        "stale_statistics_count": sum(
            1 for r in rows if r.get("finding", "").strip() == "STALE_STATISTICS"
        ),
        "compliant_count": sum(1 for r in rows if r.get("finding", "").strip() == "none"),
    }
    for key, expected in EXPECTED_RESULTS.items():
        actual = data.get(key)
        assert actual == expected, f"{key}: got {actual}, expected gold {expected}"
        assert actual == csv_counts[key], f"{key}: json={actual} != csv={csv_counts[key]}"

    assert (
        data.get("flagged_count", 0) + data.get("compliant_count", 0) == len(rows)
    ), "flagged_count + compliant_count must equal CSV row count"


# ============ MEMO SUBSTANTIVE CHECKS ============

def _concept_pattern(concept):
    """Build a regex for a disclosed evidence concept (allow fair paraphrases)."""
    c = concept.strip()
    low = c.lower()
    if low in {"compute", "computed", "computing"}:
        # Size-class computation stem disclosed in instruction
        return r"comput(?:e|ed|es|ing)"
    if low == "autovacuum":
        return r"autovacuum"
    if low == "reindex":
        return r"re-?index"
    if low == "stale":
        return r"stale"
    if low == "medium":
        return r"\bmedium\b"
    if re.fullmatch(r"\d+", c):
        # Plain digits without thousands separators (instruction-disclosed)
        return rf"(?<![\d,]){re.escape(c)}(?![\d])"
    return re.escape(c)


def _has_prose_sentence_structure(blob, table_id, finding):
    """Require table id + finding tied in prose, not a keyword bag.

    Accepts a contiguous prose window (newlines collapsed) of ≥10 words that
    contains the table id and finding keyword plus a prose connective/verb.
    Rejects pipe-table dumps and dense comma lists.
    """
    tid = re.escape(table_id)
    if finding == "BLOAT_THRESHOLD_EXCEEDED":
        find_pat = r"(?:BLOAT_THRESHOLD_EXCEEDED|\bBLOAT\b)"
    elif finding == "AUTOVACUUM_DISABLED":
        find_pat = r"AUTOVACUUM_DISABLED"
    elif finding == "STALE_STATISTICS":
        find_pat = r"STALE_STATISTICS"
    elif finding == "none":
        find_pat = r"(?:\bnone\b|\bcompliant\b)"
    else:
        find_pat = re.escape(finding) if finding else r"."

    # Drop obvious dump lines, then collapse remaining prose for multi-line bullets
    kept = []
    for line in blob.split("\n"):
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.count("|") >= 2 or stripped.count(",") >= 6:
            continue
        kept.append(stripped)
    if not kept:
        return False
    text = " ".join(kept)
    if len(text.split()) < 10:
        return False
    if not re.search(tid, text, re.I):
        return False
    if not re.search(find_pat, text, re.I):
        return False
    # Table id and finding must appear within a bounded prose span (not far-apart stuffing)
    span_ok = bool(re.search(
        rf"(?is)(?:{tid}.{{0,500}}{find_pat}|{find_pat}.{{0,500}}{tid})",
        text,
    ))
    if not span_ok:
        return False
    return bool(re.search(
        r"(?i)\b(?:is|are|has|have|was|were|because|since|with|over|under|"
        r"checked|overrides?|comput(?:e|ed|es|ing)|exceeds?|equals?|tightens?|"
        r"expired|approved|unapproved|disabled|stale|finding)\b",
        text,
    ))


def _memo_mentions(table_id, *concepts):
    """Check memo discusses a table in prose with finding + substantive concepts.

    Prefers non-table prose lines (skips markdown table rows with '|').
    Requires the gold finding token (normalized) AND at least 2 other substantive
    concepts when concepts are provided (AND logic, not OR-any).
    Also requires a short prose sentence structure (table id + finding + evidence
    in a ≥10-word sentence) so keyword-dense token bags cannot pass.
    Bare weak tokens like bloat/cap/none alone are not sufficient.
    """
    memo, err = _load_memo()
    if err:
        return False

    # Prefer prose-only text so MD summary tables cannot satisfy checks alone
    prose = "\n".join(_prose_lines(memo))
    search_text = prose if prose else memo

    if not table_id:
        concepts_alt = "|".join(re.escape(c) for c in concepts)
        return bool(re.search(rf"(?is)(?:{concepts_alt})", search_text))

    # Split concepts into finding token vs others
    finding = None
    other_concepts = []
    for c in concepts:
        ft = _normalize_finding_token(c)
        if ft and finding is None:
            finding = ft
        else:
            other_concepts.append(c)

    tid_pattern = re.escape(table_id)
    # Build windows around each table-id hit in prose (covers multi-line bullets)
    relevant = []
    for m in re.finditer(tid_pattern, search_text, re.I):
        start = max(0, m.start() - 120)
        end = min(len(search_text), m.end() + 420)
        relevant.append(search_text[start:end])
    if not relevant:
        return False

    blob = "\n".join(relevant)

    # Require finding token in the prose window
    if finding is not None:
        if finding == "BLOAT_THRESHOLD_EXCEEDED":
            finding_ok = bool(re.search(
                r"(?i)BLOAT_THRESHOLD_EXCEEDED|\bBLOAT\b", blob
            ))
        elif finding == "AUTOVACUUM_DISABLED":
            finding_ok = bool(re.search(r"(?i)AUTOVACUUM_DISABLED", blob))
        elif finding == "STALE_STATISTICS":
            finding_ok = bool(re.search(r"(?i)STALE_STATISTICS", blob))
        elif finding == "none":
            finding_ok = bool(re.search(r"(?i)\bnone\b|\bcompliant\b", blob))
        else:
            finding_ok = bool(re.search(re.escape(finding), blob, re.I))
        if not finding_ok:
            return False
        if not _has_prose_sentence_structure(blob, table_id, finding):
            return False

    # Require at least 2 substantive concepts (AND) when concepts provided
    substantive = [c for c in other_concepts if _is_substantive(c)]
    if concepts:
        needed = substantive if len(substantive) >= 2 else [
            c for c in other_concepts if c.strip().lower() not in _WEAK_CONCEPTS
            and not _normalize_finding_token(c)
        ]
        if len(needed) >= 2:
            matched = sum(
                1 for c in needed if re.search(_concept_pattern(c), blob, re.I)
            )
            if matched < 2:
                return False
        elif needed:
            if not re.search(_concept_pattern(needed[0]), blob, re.I):
                return False
        elif finding is not None:
            weak = [c for c in other_concepts if c.strip().lower() in _WEAK_CONCEPTS]
            weak_hits = sum(
                1 for c in weak if re.search(_concept_pattern(c), blob, re.I)
            )
            if weak_hits < 2:
                return False

    return True


def test_memo_explains_t02():
    """Memo must explain T-02 bloat exceeded."""
    assert _memo_mentions("T-02", "BLOAT_THRESHOLD_EXCEEDED", "0.35", "threshold", "large"), "Memo must explain T-02 bloat exceeded"


def test_memo_explains_t03():
    """Memo must explain T-03 autovacuum disabled."""
    assert _memo_mentions("T-03", "AUTOVACUUM_DISABLED", "autovacuum", "disabled", "override"), "Memo must explain T-03 autovacuum disabled"


def test_memo_explains_t04():
    """Memo must explain T-04 stale statistics."""
    assert _memo_mentions("T-04", "STALE_STATISTICS", "45", "stale", "statistics"), "Memo must explain T-04 stale statistics"


def test_memo_explains_t08():
    """Memo must explain T-08 bloat exceeded (computed large)."""
    assert _memo_mentions("T-08", "BLOAT_THRESHOLD_EXCEEDED", "0.45", "large", "1000"), "Memo must explain T-08 bloat exceeded"


def test_memo_explains_t10():
    """Memo must explain T-10 stale statistics (reindex doesn't exempt stats)."""
    assert _memo_mentions("T-10", "STALE_STATISTICS", "31", "reindex", "stale"), "Memo must explain T-10 stale statistics"


def test_memo_explains_t11():
    """Memo must explain T-11 autovacuum overrides bloat (computed large)."""
    assert _memo_mentions("T-11", "AUTOVACUUM_DISABLED", "autovacuum", "large", "1000"), "Memo must explain T-11 autovacuum overrides bloat"


def test_memo_explains_t13():
    """Memo must explain T-13 triple collision (autovacuum overrides bloat + stale)."""
    assert _memo_mentions("T-13", "AUTOVACUUM_DISABLED", "autovacuum", "override", "stale"), "Memo must explain T-13 triple collision"


def test_memo_explains_t18():
    """Memo must explain T-18: round-half-up makes 0.205 -> 0.21 (over large cap)."""
    assert _memo_mentions("T-18", "BLOAT_THRESHOLD_EXCEEDED", "0.21", "round", "0.205"), "Memo must explain T-18 rounding"


def test_memo_explains_t19():
    """Memo must explain T-19: round-half-up makes 0.405 -> 0.41 (over large cap)."""
    assert _memo_mentions("T-19", "BLOAT_THRESHOLD_EXCEEDED", "0.41", "large", "0.405"), "Memo must explain T-19 rounding"


def test_memo_explains_t20():
    """Memo must explain T-20: manual vacuum overrides autovacuum_enabled=True."""
    assert _memo_mentions("T-20", "AUTOVACUUM_DISABLED", "manual", "vacuum", "override"), "Memo must explain T-20 manual vacuum override"


def test_memo_explains_t21():
    """Memo must explain T-21: manual vacuum overrides everything (boundary + stale + autovacuum)."""
    assert _memo_mentions("T-21", "AUTOVACUUM_DISABLED", "manual", "vacuum", "override"), "Memo must explain T-21 manual vacuum override"


def test_memo_explains_t26():
    """Memo must explain T-26: stale stats tighten cap -> BLOAT not STALE."""
    assert _memo_mentions("T-26", "BLOAT_THRESHOLD_EXCEEDED", "tighten", "0.15", "0.18"), "Memo must explain T-26"


def test_memo_explains_t27():
    """Memo must explain T-27: stale stats tighten large cap 0.2->0.15 -> BLOAT."""
    assert _memo_mentions("T-27", "BLOAT_THRESHOLD_EXCEEDED", "tighten", "0.15", "0.38"), "Memo must explain T-27"


def test_memo_explains_t29():
    """Memo must explain T-29: approved reindex but EXPIRED -> NOT exempt -> BLOAT."""
    assert _memo_mentions("T-29", "BLOAT_THRESHOLD_EXCEEDED", "reindex", "expired", "valid_until"), "Memo must explain T-29"


def test_memo_explains_t30():
    """Memo must explain T-30: at original cap but stale tightens cap -> BLOAT not none."""
    assert _memo_mentions("T-30", "BLOAT_THRESHOLD_EXCEEDED", "tighten", "0.15", "effective"), "Memo must explain T-30"


def test_audit_date_sorted_order():
    """CSV rows must be sorted by last_analyzed date (ascending), then table_name."""
    import csv as csv_mod
    from datetime import datetime as dt
    path = WORKSPACE / "bloat_audit.csv"
    assert path.is_file(), "bloat_audit.csv not found"
    with open(path, encoding="utf-8", newline="") as f:
        rows = list(csv_mod.DictReader(f))

    # Read table_health.csv to get last_analyzed dates
    health_path = WORKSPACE / "input" / "table_health.csv"
    assert health_path.is_file(), "table_health.csv not found"
    last_analyzed_map = {}
    with open(health_path, encoding="utf-8", newline="") as f:
        for row in csv_mod.DictReader(f):
            last_analyzed_map[row["table_name"]] = row["last_analyzed"]

    # Check that audit rows are in date-sorted order
    prev_key = None
    for row in rows:
        tid = row.get("table_name", "").strip()
        la = last_analyzed_map.get(tid, "9999-12-31")
        key = (la, tid)
        if prev_key is not None:
            assert key >= prev_key, f"Row {tid} (last_analyzed={la}) is out of order: prev={prev_key}, current={key}"
        prev_key = key


def test_memo_discusses_maintenance():
    """Memo must discuss reindex/maintenance exemption."""
    memo, err = _load_memo()
    assert err is None, err
    assert re.search(r"(?i)re-?index|maintenance|exempt", memo), "Memo must discuss reindex/maintenance exemption"


def test_memo_explains_t17():
    """Memo must explain T-17: computed large + autovacuum disabled -> AUTOVACUUM_DISABLED."""
    assert _memo_mentions("T-17", "AUTOVACUUM_DISABLED", "autovacuum", "large", "1000"), "Memo must explain T-17"


def test_memo_size_trap_t06():
    """Memo must explain T-06 size_class column is wrong, computed as large."""
    assert _memo_mentions("T-06", "BLOAT_THRESHOLD_EXCEEDED", "compute", "1000", "large"), "Memo must explain T-06 size_class trap"


def test_memo_size_trap_t14():
    """Memo must explain T-14 size_class column says small but computed as large -> BLOAT."""
    assert _memo_mentions("T-14", "BLOAT_THRESHOLD_EXCEEDED", "1000", "large", "compute"), "Memo must explain T-14 size_class trap"


def test_memo_size_trap_t27():
    """Memo must explain T-27 size_class column says small but computed as large -> BLOAT."""
    assert _memo_mentions("T-27", "BLOAT_THRESHOLD_EXCEEDED", "1000", "large", "0.15"), "Memo must explain T-27 size_class trap"


def test_memo_reindex_expiry_t16():
    """Memo must explain T-16 reindex expired -> BLOAT not exempt."""
    assert _memo_mentions("T-16", "BLOAT_THRESHOLD_EXCEEDED", "reindex", "expired", "valid_until"), "Memo must explain T-16 reindex expiry"


def test_memo_unapproved_t05():
    """Memo must explain T-05 unapproved reindex -> BLOAT."""
    assert _memo_mentions("T-05", "BLOAT_THRESHOLD_EXCEEDED", "unapproved", "reindex", "approved"), "Memo must explain T-05 unapproved reindex"


def test_memo_discusses_size_class():
    """Memo must discuss size class caps."""
    memo, err = _load_memo()
    assert err is None, err
    assert re.search(r"(?i)size[\s-]?class|large|small|cap|0\.[24]", memo), "Memo must discuss size class caps"


def test_memo_explains_t35():
    """Memo must explain T-35: size_class field small but computed large, over cap -> BLOAT."""
    assert _memo_mentions("T-35", "BLOAT_THRESHOLD_EXCEEDED", "500", "large", "compute"), "Memo must explain T-35"


def test_memo_explains_t36():
    """Memo must explain T-36: stale cap tightening, 0.18 over tightened 0.15 -> BLOAT."""
    assert _memo_mentions("T-36", "BLOAT_THRESHOLD_EXCEEDED", "tighten", "0.15", "0.18"), "Memo must explain T-36"


def test_memo_explains_t37():
    """Memo must explain T-37: reindex expired (valid_until < audit_date) -> NOT exempt -> BLOAT."""
    assert _memo_mentions("T-37", "BLOAT_THRESHOLD_EXCEEDED", "reindex", "expired", "valid_until"), "Memo must explain T-37 expired reindex"


def test_memo_explains_t39():
    """Memo must explain T-39: manual vacuum overrides autovacuum_enabled=True -> AUTOVACUUM_DISABLED."""
    assert _memo_mentions("T-39", "AUTOVACUUM_DISABLED", "manual", "vacuum", "override"), "Memo must explain T-39 manual vacuum"


def test_memo_explains_t40():
    """Memo must explain T-40: days_since_analyze field wrong, actual 35 days -> STALE_STATISTICS."""
    assert _memo_mentions("T-40", "STALE_STATISTICS", "35", "days_since_analyze", "stale"), "Memo must explain T-40 days mismatch"


def test_memo_explains_t42():
    """Memo must explain T-42: at normal cap 0.2 but stale tightens to 0.15 -> BLOAT."""
    assert _memo_mentions("T-42", "BLOAT_THRESHOLD_EXCEEDED", "tighten", "0.15", "stale"), "Memo must explain T-42"


def test_memo_explains_t44():
    """Memo must explain T-44: size_class field says medium but computed large -> BLOAT."""
    assert _memo_mentions("T-44", "BLOAT_THRESHOLD_EXCEEDED", "medium", "large", "compute"), "Memo must explain T-44 medium trap"


def test_memo_has_prose():
    """Memo must contain at least 5 explanatory prose sentences that mention specific tables.
    
    A valid prose sentence:
    - Has 10+ words
    - Has fewer than 2 pipe characters (not a Markdown table row)
    - Has fewer than 3 commas (not a CSV row)
    - Mentions at least one table ID (T-XX) and at least one finding keyword
    
    Filler sentences without table references do not count.
    """
    memo, err = _load_memo()
    assert err is None, err
    
    valid_prose = 0
    mentioned_tables = set()
    for line in memo.split('\n'):
        words = line.split()
        if len(words) >= 10 and line.count('|') < 2 and line.count(',') < 3:
            # Check if this line mentions a table ID
            table_match = re.search(r'T-(\d+)', line)
            if table_match:
                mentioned_tables.add(table_match.group(0))
                # Check if it also mentions a finding keyword
                if re.search(r'(?:bloat|autovacuum|stale|exceed|cap|threshold|disabled|none|compliant|maintenance|reindex)', line, re.I):
                    valid_prose += 1
    
    assert valid_prose >= 5, f"Memo has only {valid_prose} valid prose sentences mentioning tables (need >= 5). Filler sentences without table references don't count."
