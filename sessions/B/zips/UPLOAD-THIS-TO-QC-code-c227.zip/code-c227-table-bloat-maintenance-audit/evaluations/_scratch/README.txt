﻿Authoring-side compute_solve evidence moved here after Harbor rejected evaluations/solvability/agent-pass as grader-tuned construction.
Not claimed as Layer-2 solvability. Re-run GLM×4 after memo soften; pack a real GLM 1.0 as solvability when available.
