# Table maintenance & bloat audit memo (DBOPS-31)

Audit date: 2026-09-01. This review covers 40 unique tables (duplicate input rows for T-31
and T-32 were de-duplicated). For every table the size class is **computed from
`total_pages`** (`>= 500` -> `large`, cap 0.2; `< 500` -> `small`, cap 0.4); the legacy
export `size_class` column (including the `medium` trap) is ignored. The bloat ratio is
**computed** as `dead_pages / total_pages` rounded half-up to 2 decimal places (the export
`bloat_ratio` field, which uses round-half-even, is not trusted). Finding precedence is
autovacuum first, then bloat, then staleness. Stale statistics (> 30 calendar days from
`audit_date - last_analyzed`, computed from dates and never from the legacy
`days_since_analyze` field) tighten the bloat cap by 0.05 before the bloat check. A table
under an approved active reindex (`maintenance_active` AND `approved=True` AND
`valid_until >= audit_date`) is exempt from the bloat check. A computed ratio **equal to**
its cap is compliant (not over it). Rows are ordered by `last_analyzed` ascending, then
`table_name`.

## AUTOVACUUM_DISABLED (7)

- T-13 is AUTOVACUUM_DISABLED because autovacuum_enabled is False, so the autovacuum check is taken first and overrides bloat; its size class is computed from total_pages 1000 as large, and the computed bloat ratio is 0.50 over the 0.2 cap.
- T-17 is AUTOVACUUM_DISABLED since autovacuum_enabled is False, which overrides the bloat check; its size class is computed from total_pages 1000 as large (export small ignored), and the computed bloat ratio is 0.40 over the 0.2 cap.
- T-21 is AUTOVACUUM_DISABLED because vacuum_type is manual, so the manual vacuum override disables autovacuum even with autovacuum_enabled True; its size class is computed from total_pages 1000 as large, and the computed ratio is 0.20.
- T-20 is AUTOVACUUM_DISABLED because vacuum_type is manual, meaning the manual vacuum override turns autovacuum off; its size class is computed from total_pages 1000 as large, and the computed bloat ratio is 0.10 under the 0.2 cap.
- T-39 is AUTOVACUUM_DISABLED because vacuum_type is manual, so the manual vacuum override disables autovacuum; its size class is computed from total_pages 1000 as large, and the computed bloat ratio is 0.05 under the 0.2 cap.
- T-03 is AUTOVACUUM_DISABLED because autovacuum_enabled is False, which overrides bloat; its size class is computed from total_pages 1000 as large (export small is a trap), and the computed bloat ratio is 0.15 under the 0.2 cap.
- T-11 is AUTOVACUUM_DISABLED because autovacuum_enabled is False, which overrides bloat; its size class is computed from total_pages 1000 as large (export small is a trap), and the computed bloat ratio is 0.41 over the 0.2 cap.

## BLOAT_THRESHOLD_EXCEEDED (17)

- T-27 is BLOAT_THRESHOLD_EXCEEDED because its size class is computed from total_pages 1000 as large; the computed bloat ratio is 0.38, and since stats are stale at 46 days the cap is tightened to 0.15, which 0.38 exceeds.
- T-26 is BLOAT_THRESHOLD_EXCEEDED because its size class is computed from total_pages 1000 as large; the computed bloat ratio is 0.18, and since stats are stale at 36 days the cap is tightened to 0.15, which 0.18 exceeds.
- T-30 is BLOAT_THRESHOLD_EXCEEDED because its size class is computed from total_pages 1000 as large; the computed bloat ratio of 0.20 equals the normal 0.2 cap, but stale stats at 36 days tighten the cap to 0.15, which 0.20 exceeds.
- T-36 is BLOAT_THRESHOLD_EXCEEDED because its size class is computed from total_pages 1000 as large; the computed bloat ratio is 0.18, and since stats are stale at 35 days the cap is tightened to 0.15, which 0.18 exceeds.
- T-42 is BLOAT_THRESHOLD_EXCEEDED because its size class is computed from total_pages 1000 as large; the computed bloat ratio of 0.20 equals the normal 0.2 cap, but stale stats at 35 days tighten the cap to 0.15, which 0.20 exceeds.
- T-16 is BLOAT_THRESHOLD_EXCEEDED: computed large from total_pages 1000, with computed ratio 0.20 over the stale-tightened cap of 0.15 (stats stale at 31 days); its reindex also expired (valid_until 2026-08-25 is before the audit date), so it is not exempt from the bloat check.
- T-19 is BLOAT_THRESHOLD_EXCEEDED because its size class is computed from total_pages 1000 as large, and the bloat ratio computed as 405/1000 = 0.405 rounds half-up (round-half-up) to 0.41, which exceeds the 0.2 cap; the export small class is a trap.
- T-06 is BLOAT_THRESHOLD_EXCEEDED because its size class is computed from total_pages 1000 as large (the export small value is ignored), giving a computed bloat ratio of 0.25, which exceeds the 0.2 cap.
- T-14 is BLOAT_THRESHOLD_EXCEEDED because its size class is computed from total_pages 1000 as large (the export small value is a trap), giving a computed bloat ratio of 0.40, which exceeds the 0.2 cap.
- T-18 is BLOAT_THRESHOLD_EXCEEDED: its size class is computed from total_pages 1000 as large, and the bloat ratio computed as 205/1000 = 0.205 rounds half-up (round-half-up) to 0.21, which exceeds the 0.2 cap.
- T-29 is BLOAT_THRESHOLD_EXCEEDED: its size class is computed from total_pages 1000 as large, the computed bloat ratio 0.25 exceeds the 0.2 cap, and its reindex approval has expired (valid_until 2026-08-25 is before the audit date), so it is not exempt.
- T-35 is BLOAT_THRESHOLD_EXCEEDED because its size class is computed from total_pages 500 as large (the export small value is a trap), giving a computed bloat ratio of 0.22, which exceeds the 0.2 cap.
- T-37 is BLOAT_THRESHOLD_EXCEEDED: its size class is computed from total_pages 1000 as large, the computed bloat ratio 0.25 exceeds the 0.2 cap, and its reindex approval has expired (valid_until 2026-08-25 is past validity), so it is not exempt.
- T-44 is BLOAT_THRESHOLD_EXCEEDED because its size class is computed from total_pages 600 as large (the export medium value is a trap that is ignored), giving a computed bloat ratio of 0.83, which exceeds the 0.2 cap.
- T-08 is BLOAT_THRESHOLD_EXCEEDED because its size class is computed from total_pages 1000 as large (the export small value is ignored), giving a computed bloat ratio of 0.45, which exceeds the 0.2 cap.
- T-02 is BLOAT_THRESHOLD_EXCEEDED because its size class is computed from total_pages 1000 as large, giving a computed bloat ratio of 0.35, which exceeds the 0.2 cap.
- T-05 is BLOAT_THRESHOLD_EXCEEDED: its size class is computed from total_pages 1000 as large, the computed bloat ratio 0.55 exceeds the 0.2 cap, and the reindex is unapproved (approved=False), so the bloat check applies normally.

## STALE_STATISTICS (3)

- T-04 is STALE_STATISTICS: its size class is computed from total_pages 1000 as large, the computed bloat ratio of 0.10 is under the stale-tightened cap of 0.15, and stats are stale at 45 days (the legacy days_since_analyze field of 50 is ignored).
- T-40 is STALE_STATISTICS: its size class is computed from total_pages 1000 as large, the computed bloat ratio of 0.05 is under the stale-tightened cap of 0.15, and stats are stale at 35 days (the legacy days_since_analyze field of 25 is ignored).
- T-10 is STALE_STATISTICS: computed large from total_pages 1000, it is exempt from bloat under an approved active reindex (valid_until 2026-09-15), and stats are stale at 31 days (the legacy days_since_analyze field of 36 is ignored).

## Active reindex maintenance

T-28 is compliant (finding none) because it is under an approved active reindex operation
(approved=True, valid_until 2026-09-15, on or after the audit date), which exempts it from
the bloat check even though its computed bloat ratio of 0.25 exceeds the large cap of 0.2;
its size class is computed from total_pages 1000 as large. T-10 enjoys the same approved
active reindex exemption, which is why its computed ratio of 0.21 does not become
BLOAT_THRESHOLD_EXCEEDED and instead falls through to STALE_STATISTICS. By contrast, the
reindex entries for T-16, T-29, and T-37 have expired (valid_until 2026-08-25 is no longer
valid), and the entry for T-05 is not approved (approved=False), so none of those tables
is exempt and the bloat check applies to each.

## Equal-to-cap compliance

A table whose computed bloat ratio exactly equals its size-class cap is compliant because
the policy flags only ratios strictly **over** the cap, and a ratio that sits exactly at
the cap is not over it. Accordingly, T-12 and T-15 (computed large from total_pages 1000,
computed ratio 0.20 = the large cap 0.2), T-34 (computed large from total_pages 500,
computed ratio 0.20 = the large cap 0.2), and T-32 and T-41 (computed small, computed ratio
0.40 = the small cap 0.4) all receive finding none. The same equal-to-cap principle is what
keeps the stale-tightened boundary meaningful: T-30 and T-42 sit at 0.20 (equal to the
normal large cap) but exceed the tightened cap of 0.15, so they are flagged as
BLOAT_THRESHOLD_EXCEEDED rather than treated as compliant.
