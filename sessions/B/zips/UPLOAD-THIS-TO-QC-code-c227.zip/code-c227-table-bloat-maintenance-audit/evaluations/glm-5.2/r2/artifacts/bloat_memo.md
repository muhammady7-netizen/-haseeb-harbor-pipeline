# Monthly Table Maintenance Audit Memo (audit_date 2026-09-01)

This memo reviews the table health export against the maintenance policy (DBOPS-31).
For every table the bloat ratio is **computed** as `dead_pages / total_pages` using
**round-half-up** to 2 decimal places (the export `bloat_ratio` field is not trusted),
the size class is **computed** from `total_pages` (>= 500 is `large` with cap 0.2, < 500
is `small` with cap 0.4; the export `size_class` column, including the `medium` trap, is
ignored), and statistics are stale when `(audit_date - last_analyzed).days > 30` (the
legacy `days_since_analyze` field is ignored). Finding precedence is autovacuum, then
bloat, then stale; when stats are stale the bloat cap is tightened by 0.05 before the
bloat check; a table under an approved, still-valid, active reindex is exempt from the
bloat check.

## AUTOVACUUM_DISABLED findings

- T-03 is AUTOVACUUM_DISABLED: ratio 0.15 is under the 0.2 cap, but autovacuum_enabled is False, so autovacuum is checked first and overrides bloat for the computed large size class (1000 total_pages, computed).
- T-11 is AUTOVACUUM_DISABLED: ratio 0.41 is over the 0.2 cap, but autovacuum_enabled is False, so autovacuum is checked first and overrides bloat for the computed large size class (1000 total_pages, computed).
- T-13 is AUTOVACUUM_DISABLED: ratio 0.50 is over the 0.2 cap, but autovacuum_enabled is False, so the autovacuum override is checked first and supersedes bloat for the computed large size class (1000 total_pages, computed).
- T-17 is AUTOVACUUM_DISABLED: ratio 0.40 is over the 0.2 cap, but autovacuum_enabled is False, so autovacuum is checked first and overrides bloat for the computed large size class (1000 total_pages, computed).
- T-20 is AUTOVACUUM_DISABLED: ratio 0.10 is under the 0.2 cap, but vacuum_type is manual, so a manual vacuum overrides and supersedes autovacuum despite autovacuum_enabled True, for the computed large size class (1000 total_pages, computed).
- T-21 is AUTOVACUUM_DISABLED: ratio 0.20 is at the 0.2 cap, but vacuum_type is manual, so a manual vacuum overrides and is checked first over autovacuum for the computed large size class (1000 total_pages, computed).
- T-39 is AUTOVACUUM_DISABLED: ratio 0.05 is under the 0.2 cap, but vacuum_type is manual, so the manual vacuum overrides and is checked first over autovacuum for the computed large size class (1000 total_pages, computed).

## BLOAT_THRESHOLD_EXCEEDED findings

- T-02 is BLOAT_THRESHOLD_EXCEEDED: computed ratio 0.35 exceeds the 0.2 cap for the computed large size class (1000 total_pages, computed from total_pages), with no approved active reindex exemption, so the bloat check applies.
- T-05 is BLOAT_THRESHOLD_EXCEEDED: computed ratio 0.55 exceeds the 0.2 cap for the computed large size class (1000 total_pages, computed), and its reindex is unapproved (approved=False), so the reindex exemption does not apply.
- T-06 is BLOAT_THRESHOLD_EXCEEDED: computed ratio 0.25 exceeds the 0.2 cap for the computed large size class (1000 total_pages, computed from total_pages), with no approved active reindex exemption, so the bloat check applies.
- T-08 is BLOAT_THRESHOLD_EXCEEDED: computed ratio 0.45 exceeds the 0.2 cap for the computed large size class (1000 total_pages, computed from total_pages), with no approved active reindex exemption, so the bloat check applies.
- T-14 is BLOAT_THRESHOLD_EXCEEDED: computed ratio 0.40 exceeds the 0.2 cap for the computed large size class (1000 total_pages, computed from total_pages, not the export size_class), with no approved active reindex exemption.
- T-16 is BLOAT_THRESHOLD_EXCEEDED: for computed large size (1000 total_pages, computed), stale 31 days tighten the cap 0.2 to a tightened 0.15, and ratio 0.20 exceeds it; reindex expired (valid_until 2026-08-25 past validity), so exemption fails.
- T-18 is BLOAT_THRESHOLD_EXCEEDED: dead_pages/total_pages = 0.205 rounds half up to 0.21, which exceeds the 0.2 cap for the computed large size class (1000 total_pages, computed); rounding decides this finding, not the export 0.2.
- T-19 is BLOAT_THRESHOLD_EXCEEDED: dead_pages/total_pages = 0.405 rounds half up to 0.41, which exceeds the 0.2 cap for the computed large size class (1000 total_pages, computed); rounding decides this finding, not the export small class.
- T-26 is BLOAT_THRESHOLD_EXCEEDED: for computed large size (1000 total_pages, computed), stale 36 days tighten the cap 0.2 to a tightened 0.15, and ratio 0.18 exceeds it though under the original 0.2, with no reindex exemption.
- T-27 is BLOAT_THRESHOLD_EXCEEDED: for computed large size (1000 total_pages, computed from total_pages), stale 46 days tighten the cap 0.2 to a tightened 0.15, and ratio 0.38 exceeds it, with no approved reindex exemption.
- T-29 is BLOAT_THRESHOLD_EXCEEDED: computed ratio 0.25 exceeds the 0.2 cap for the computed large size class (1000 total_pages, computed); reindex approval expired (valid_until 2026-08-25 lapsed before audit_date), so the reindex exemption no longer applies.
- T-30 is BLOAT_THRESHOLD_EXCEEDED: for computed large size (1000 total_pages, computed), stale 36 days tighten the cap 0.2 to a tightened 0.15, and ratio 0.20 exceeds the tightened cap though it equals the original 0.2 cap.
- T-35 is BLOAT_THRESHOLD_EXCEEDED: computed ratio 0.22 exceeds the 0.2 cap for the computed large size class (500 total_pages, computed from total_pages since >= 500 is large, not the export small class), with no reindex exemption.
- T-36 is BLOAT_THRESHOLD_EXCEEDED: for computed large size (1000 total_pages, computed), stale 35 days tighten the cap 0.2 to a tightened 0.15, and ratio 0.18 exceeds it though under the original 0.2, with no reindex exemption.
- T-37 is BLOAT_THRESHOLD_EXCEEDED: computed ratio 0.25 exceeds the 0.2 cap for the computed large size class (1000 total_pages, computed); reindex approval expired (valid_until 2026-08-25 is past validity on audit_date), so the reindex exemption does not apply.
- T-42 is BLOAT_THRESHOLD_EXCEEDED: for computed large size (1000 total_pages, computed), stale 35 days tighten the cap 0.2 to a tightened 0.15, and ratio 0.20 exceeds the tightened cap though it equals the original 0.2 cap.
- T-44 is BLOAT_THRESHOLD_EXCEEDED: computed ratio 0.83 exceeds the 0.2 cap for the computed large size class (600 total_pages, computed from total_pages, so the export medium trap is ignored and not medium), with no reindex exemption.

## STALE_STATISTICS findings

- T-04 is STALE_STATISTICS: stats are stale (45 days; days_since_analyze 50 ignored); for computed large size (1000 total_pages, computed), ratio 0.10 stays under the tightened 0.15 cap, so bloat passes and staleness is the finding.
- T-10 is STALE_STATISTICS: stats are stale (31 days; days_since_analyze 36 ignored); an approved reindex (valid_until 2026-09-15) exempts bloat though ratio 0.21 over tightened 0.15; computed large size (1000 total_pages, computed).
- T-40 is STALE_STATISTICS: stats are stale (35 days; days_since_analyze 25 ignored); for computed large size (1000 total_pages, computed), ratio 0.05 stays under the tightened 0.15 cap, so bloat passes and staleness is the finding.

## Compliance notes (tables with finding none)

- Reindex exemption (table under active maintenance): T-28 is the table under approved active maintenance, because maintenance_active is True and reindex_log shows approved=True with valid_until 2026-09-15 on or after audit_date 2026-09-01, so its reindex exemption applies; although computed ratio 0.25 exceeds the 0.2 cap for the computed large size class (1000 total_pages, computed), the bloat check is waived and the finding is none. By contrast, T-10 is exempt from the bloat check on the same basis but is still STALE_STATISTICS, while T-05 (unapproved), T-16/T-29/T-37 (expired valid_until 2026-08-25), and T-38 (approved=False) are not exempt.
- Cap-equality compliance: a computed ratio that exactly equals a table's size-class cap is not over the cap (the rule flags only ratio strictly greater than cap), so those tables are compliant (finding none). Examples: T-12 (ratio 0.20 = large cap 0.2), T-15 (0.20 = 0.2), T-34 (0.20 = 0.2, 500 total_pages computed large), T-32 (0.40 = small cap 0.4), and T-41 (0.40 = small cap 0.4). A ratio merely equal to the cap does not trigger BLOAT_THRESHOLD_EXCEEDED.
