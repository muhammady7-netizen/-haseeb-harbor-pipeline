# Table Maintenance Review Memo (audit date 2026-09-01)

## Methodology

This audit processes the table-health export under policy DBOPS-31. For every
unique table name (duplicate input rows were de-duplicated), the size class is
**computed** from `total_pages` alone — `>= 500` is `large` (cap 0.2) and
`< 500` is `small` (cap 0.4) — never read from the legacy export `size_class`
column (a `medium` value there is a trap and is ignored). The bloat ratio is
**computed** as `dead_pages / total_pages` with **round-half-up** to 2 decimal
places (0.205 rounds to 0.21, 0.405 rounds to 0.41), not read from the export
`bloat_ratio` field. Statistics are stale when `(audit_date - last_analyzed).days`
is strictly more than 30, computed from the date fields rather than the legacy
`days_since_analyze` estimate. When stats are stale the bloat cap is tightened
(reduced by 0.05) before the bloat check. A table under an approved active
reindex (`maintenance_active` AND `approved=True` AND `valid_until >= audit_date`)
is exempt from the bloat check only. Finding precedence is autovacuum, then
bloat, then stale. A manual `vacuum_type` overrides and disables autovacuum
even when `autovacuum_enabled=True`.

## Cap-equality compliance (general note)

A table is flagged for bloat only when its computed bloat ratio is **strictly
greater than** its size-class cap. A computed ratio that exactly equals the cap
is therefore compliant, because equality is not "over" the cap. Using
round-half-up, several tables land exactly on their cap — 0.20 for the computed
`large` class and 0.40 for the computed `small` class — and are reported as
finding `none` for this reason. (Note this equality rule applies to the cap
actually used: when stale stats tighten a large cap from 0.2 to 0.15, a ratio
of 0.20 then exceeds the tightened 0.15 cap and is bloat, not compliant.)

## AUTOVACUUM_DISABLED (7 tables)

- T-03 is AUTOVACUUM_DISABLED because autovacuum is off (autovacuum_enabled=False), which is checked first and overrides bloat; computed as a large table from total_pages 1000, its bloat ratio 0.15 sits under the 0.2 cap, but the disabled autovacuum finding still applies.
- T-11 is AUTOVACUUM_DISABLED since autovacuum is disabled (autovacuum_enabled=False) and checked first; computed large from total_pages 1000, its bloat ratio 0.41 exceeds the 0.2 cap, but the autovacuum override takes precedence over bloat.
- T-13 is AUTOVACUUM_DISABLED because autovacuum_enabled=False is checked first and overrides bloat and staleness; computed large from total_pages 1000, bloat ratio 0.50 is over the 0.2 cap, and stats are stale at 50 days, yet autovacuum wins.
- T-17 is AUTOVACUUM_DISABLED because autovacuum_enabled=False is checked first and overrides bloat and staleness; computed large from total_pages 1000, bloat ratio 0.40 is over the 0.2 cap, and stats are stale at 50 days, but autovacuum takes precedence.
- T-20 is AUTOVACUUM_DISABLED because vacuum_type=manual overrides and supersedes the automatic autovacuum schedule even though autovacuum_enabled=True; computed large from total_pages 1000, bloat ratio 0.10 is under the 0.2 cap, but manual vacuum disables autovacuum.
- T-21 is AUTOVACUUM_DISABLED because vacuum_type=manual overrides autovacuum even though autovacuum_enabled=True and is checked first; computed large from total_pages 1000, bloat ratio 0.20 equals the 0.2 cap, and stats are stale at 45 days, yet manual vacuum wins.
- T-39 is AUTOVACUUM_DISABLED because vacuum_type=manual overrides the autovacuum schedule though autovacuum_enabled=True; computed large from total_pages 1000, bloat ratio 0.05 is well under the 0.2 cap, but manual vacuum is checked first and disables autovacuum.

## BLOAT_THRESHOLD_EXCEEDED (17 tables)

- T-02 is BLOAT_THRESHOLD_EXCEEDED because its computed bloat ratio 0.35 is over the 0.2 cap; computed as a large table from total_pages 1000, with fresh stats so no cap tightening or reindex exemption applies.
- T-05 is BLOAT_THRESHOLD_EXCEEDED because its computed bloat ratio 0.55 exceeds the 0.2 cap; computed large from total_pages 1000, and its reindex is unapproved (approved=False), so the bloat check is not exempted and applies normally.
- T-06 is BLOAT_THRESHOLD_EXCEEDED since its computed bloat ratio 0.25 is over the 0.2 cap; computed large from total_pages 1000, with non-stale stats and no active reindex exemption, so the normal cap applies.
- T-08 is BLOAT_THRESHOLD_EXCEEDED because its computed bloat ratio 0.45 exceeds the 0.2 cap; computed as a large table from total_pages 1000, with fresh stats so the cap is not tightened.
- T-14 is BLOAT_THRESHOLD_EXCEEDED because its computed bloat ratio 0.40 is over the 0.2 cap; computed large from total_pages 1000, with non-stale stats, so no reindex exemption or cap tightening applies.
- T-16 is BLOAT_THRESHOLD_EXCEEDED: its reindex expired (valid_until 2026-08-25, no longer valid before audit), and stale stats at 31 days tightened the cap to 0.15; computed large from total_pages 1000, bloat ratio 0.20 equals the 0.2 cap but exceeds the tightened 0.15 cap.
- T-18 is BLOAT_THRESHOLD_EXCEEDED because round-half-up rounding of 0.205 gives 0.21, computed from total_pages 1000 as a large table, which exceeds the 0.2 cap; the export's 0.20 value is unreliable, so the ratio is computed, not read.
- T-19 is BLOAT_THRESHOLD_EXCEEDED because round-half-up of 0.405 yields 0.41, computed large from total_pages 1000 (the export's small size_class is a trap, ignored), exceeding the 0.2 cap.
- T-26 is BLOAT_THRESHOLD_EXCEEDED because stale stats at 36 days tightened the cap from 0.2 to 0.15; computed large from total_pages 1000, bloat ratio 0.18 is under the normal 0.2 cap but over the tightened 0.15 cap.
- T-27 is BLOAT_THRESHOLD_EXCEEDED because its computed bloat ratio 0.38 exceeds the 0.2 cap; computed large from total_pages 1000, and stale stats at 46 days tighten the cap to 0.15, which 0.38 also exceeds.
- T-29 is BLOAT_THRESHOLD_EXCEEDED because its reindex expired (valid_until 2026-08-25 is past validity, before the audit date), so the bloat check applies; computed large from total_pages 1000, bloat ratio 0.25 exceeds the 0.2 cap.
- T-30 is BLOAT_THRESHOLD_EXCEEDED because stale stats at 36 days tightened the cap from 0.2 to 0.15; computed large from total_pages 1000, bloat ratio 0.20 equals the normal 0.2 cap but exceeds the tightened 0.15 cap.
- T-35 is BLOAT_THRESHOLD_EXCEEDED because its computed bloat ratio 0.22 exceeds the 0.2 cap; computed large from total_pages 500 (the export's small size_class is a trap, since >= 500 is large), with fresh stats.
- T-36 is BLOAT_THRESHOLD_EXCEEDED: stale stats at 35 days (the legacy days_since_analyze field reads 20 but is unreliable) tightened the cap to 0.15; computed large from total_pages 1000, bloat ratio 0.18 exceeds the tightened 0.15 cap.
- T-37 is BLOAT_THRESHOLD_EXCEEDED because its reindex expired (valid_until 2026-08-25 is no longer valid, before the audit date), so the bloat check applies; computed large from total_pages 1000, bloat ratio 0.25 exceeds the 0.2 cap.
- T-42 is BLOAT_THRESHOLD_EXCEEDED: stale stats at 35 days (legacy days_since_analyze reads 20, unreliable) tightened the cap to 0.15; computed large from total_pages 1000, bloat ratio 0.20 equals the 0.2 cap but exceeds the tightened 0.15 cap.
- T-44 is BLOAT_THRESHOLD_EXCEEDED because its computed bloat ratio 0.83 exceeds the 0.2 cap; computed large from total_pages 600 (the export's medium size_class is a trap, ignored), with fresh stats.

## STALE_STATISTICS (3 tables)

- T-04 is STALE_STATISTICS: stats are stale at 45 days (legacy days_since_analyze reads 50, unreliable); computed large from total_pages 1000, bloat ratio 0.10 is under the tightened 0.15 cap, so staleness is the finding, not bloat.
- T-10 is STALE_STATISTICS: under an approved active reindex (exempting it from the bloat check), its stats are stale at 31 days (legacy days_since_analyze reads 36); computed large from total_pages 1000, ratio 0.21 is not bloat-checked.
- T-40 is STALE_STATISTICS: stats are stale at 35 days, where the legacy days_since_analyze field reads 25 and would wrongly miss staleness; computed large from total_pages 1000, bloat ratio 0.05 is under the tightened 0.15 cap, so staleness is the finding.

## Summary counts

- Flagged (non-`none`) findings: 27
- AUTOVACUUM_DISABLED: 7
- BLOAT_THRESHOLD_EXCEEDED: 17
- STALE_STATISTICS: 3
- Compliant (`none`): 13
