Densify T-45: solvability uses gold deliverables with real opencode trajectory shell (not compute_solve). Digests/verifier aligned at 1.0 on densified pack.
