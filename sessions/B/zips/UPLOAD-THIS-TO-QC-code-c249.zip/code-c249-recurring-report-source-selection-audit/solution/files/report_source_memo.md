# Recurring report source-selection audit — 15 runs + 1 missing job

15 logged runs checked against REPORTING-OPS-2, plus the required job roster.
9 rows are compliant, 6 runs carry a finding, and 1 required job is missing entirely.

| Run | Job | Run date | Source used | Reported rows | Finding |
|---|---|---|---|---|---|
| RUN-01 | weekly-journal-brief | 2026-06-29 | archive | 412 | none |
| RUN-02 | weekly-journal-brief | 2026-07-13 | live | 388 | ROW_COUNT_MISMATCH |
| RUN-03 | monthly-report | 2026-08-03 |  | 0 | MISSING_TAIL_MERGE |
| RUN-05 | weekly-journal-brief | 2026-07-06 | archive | 305 | none |
| RUN-07 | weekly-journal-brief | 2026-07-27 | live | 402 | none |
| RUN-08 | monthly-report | 2026-09-07 | live | 380 | none |
| RUN-10 | weekly-journal-brief | 2026-07-06 | live | 350 | SOURCE_MISMATCH |
| RUN-11 | monthly-report | 2026-07-06 | archive | 500 | none |
| RUN-13 | weekly-journal-brief | 2026-07-05 | live | 390 | SOURCE_MISMATCH |
| RUN-15 | monthly-report | 2026-10-05 | live | 395 | none |
| RUN-17 | weekly-journal-brief | 2026-07-07 | archive | 360 | SOURCE_MISMATCH |
| RUN-18 | weekly-journal-brief | 2026-07-07 | live | 370 | none |
| RUN-19 | monthly-report | 2026-11-02 | live | 410 | ROW_COUNT_MISMATCH |
| RUN-20 | weekly-journal-brief | 2026-08-17 | live | 375 | none |
| RUN-21 | monthly-report | 2026-07-06 | live | 450 | none |
| (missing) | week-ahead-briefing |  |  |  | MISSING_JOB |

## The cutover date is inclusive — runs on 2026-07-06

RUN-05 ran on 2026-07-06, the cutover date itself, and used the archive source. That
looks premature if you assume the switch to live happens starting on the cutover date.
But the standard's cutover rule is inclusive: a run dated **on or before** 2026-07-06 uses
archive, and only a run dated **after** 2026-07-06 switches to live. RUN-05 is correct with
archive. RUN-11, a monthly report on the cutover date, also correctly used archive. The
finding for both is `none`.

## RUN-10 — premature switch to live on the cutover date

RUN-10 ran on 2026-07-06, the cutover date, but used the live source. Because the
cutover rule is inclusive of the cutover date, archive is correct for any run on or
before 2026-07-06. RUN-10's live source is a premature switch: `SOURCE_MISMATCH`.
Its row-count snapshot matches (350 = 350), but the source is wrong for the run date.

## RUN-13 — live one day before the cutover

RUN-13 ran on 2026-07-05, the day before the cutover, but used the live source. Because
the cutover rule says archive for any run on or before 2026-07-06, RUN-13 should have
used archive. Its row-count snapshot matches (390 = 390), but the source is wrong for
the run date: `SOURCE_MISMATCH`.

## RUN-17 and RUN-18 — same date, opposite sources

RUN-17 and RUN-18 both ran on 2026-07-07, the day after the cutover. RUN-17 used
archive, which is wrong because the cutover rule says live for any run after
2026-07-06: `SOURCE_MISMATCH`. RUN-18 correctly used live: `none`. The row-count
snapshots match for both. The difference is entirely in the source selection for the
run date.

## RUN-20 — no row-count snapshot, no row-count check

RUN-20 ran on 2026-08-17, well after the cutover, and correctly used the live source.
Its source_row_count_snapshot is empty (absent). The standard's row-count rule says
"Where this snapshot is present (non-empty), the run's reported_row_count must equal
the snapshot's count." Because the snapshot is absent, the row-count rule does not
apply. The finding is `none`.

## RUN-21 — monthly report on cutover date with live source

RUN-21 ran on 2026-07-06, the cutover date, as a monthly report using the live source.
The cutover rule applies only to weekly-journal-brief and week-ahead-briefing runs, not
to monthly reports. The tail-merge rule applies only to the first post-cutover monthly
report (RUN-03), not to a monthly report on the cutover date itself. The row-count
snapshot matches (450 = 450). The finding is `none`.

## RUN-03 — first post-cutover monthly report with no tail merge

RUN-03, the first monthly report generated after the cutover (dated 2026-08-03), has
an empty source and zero reported rows. The standard requires the first post-cutover
monthly report to merge in the archive source's tail days before synthesizing the
month's weekly briefs. The empty source and zero rows show this tail merge was
skipped: `MISSING_TAIL_MERGE`.

## RUN-08 and RUN-15 — later monthly reports, no tail merge needed

RUN-08 (2026-09-07) and RUN-15 (2026-10-05) are monthly reports that also fall after
the cutover. They both use the live source and their row-count snapshots match.
Because they are not the first post-cutover monthly report, the tail-merge rule does
not apply. The finding for both is `none`.

## Row-count mismatches

RUN-02 correctly used the live source after the cutover, but its reported row count
(388) does not match the pipeline's own live-source snapshot (395):
`ROW_COUNT_MISMATCH`. RUN-19 also correctly used live, but its reported count (410)
does not match its snapshot (405): `ROW_COUNT_MISMATCH`.

## Missing required job — week-ahead-briefing

The required recurring roster lists three jobs: weekly-journal-brief,
week-ahead-briefing, and monthly-report. The run log contains weekly-journal-brief
and monthly-report runs but no week-ahead-briefing run at all. A job with no run
logged is `MISSING_JOB`.

## Source mismaches

RUN-10 ran on the cutover date but used live, which is premature because the cutover
date itself is still archive: `SOURCE_MISMATCH`. RUN-13 ran the day before the cutover
using live, which is too early: `SOURCE_MISMATCH`. RUN-17 ran the day after the
cutover using archive, which is too late to still be on archive:
`SOURCE_MISMATCH`.
