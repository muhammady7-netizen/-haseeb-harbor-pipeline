# Task

Audit this recurring reporting pipeline's logged runs against our source-selection standard. For every run, apply the weekly source-cutover rule, the row-count-consistency rule and the monthly tail-merge rule, and separately confirm every required recurring job has at least one run logged. Save `report_source_audit.csv` with one row per run (plus any missing required job) carrying the run's identifying columns from the log (`run_id`, `job_name`, `run_date`, `source_used`, `reported_row_count`) and a final `finding` column using the standard's finding names, `none` where compliant. Then write `report_source_memo.md` explaining every finding, citing the run ID and the specific reason for each finding (for source mismatches, what source was used and what should have been used; for row-count mismatches, the reported count and the snapshot count).

---
Delivery conventions for this run (added by the eval harness; the request above is unchanged):
- The attachments are provided read-only at: `input/report_source_standard.md`; `input/report_run_log.csv`. Read them there.
- Save your deliverables into your current working directory using exactly these filenames:
    - `report_source_audit.csv` — Per-run source-selection audit
    - `report_source_memo.md` — Markdown source-selection audit memo
    - `results.json` — a JSON object with the keys `flagged_count`, `source_mismatch_count`, `row_count_mismatch_count`, `missing_tail_merge_count`, `missing_job_count`
- Writing those files is the required deliverable and must be your final action; confirm each one exists before you answer.

---

## Working environment

- Your current working directory is `/app`, and it is writable.
- The read-only attachments referred to as `input/` are at `/app/input`.
- Write every deliverable into `/app`, at the exact filenames listed above.
