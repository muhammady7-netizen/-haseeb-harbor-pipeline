# code-c249-recurring-report-source-selection-audit

Non-connector Harbor task. Audit a recurring reporting pipeline's logged runs against the source-selection standard (REPORTING-OPS-2).

## Deliverables

- `report_source_audit.csv` — one row per run plus any missing required job, with a `finding` column
- `report_source_memo.md` — markdown memo explaining every finding
- `results.json` — `flagged_count`, `source_mismatch_count`, `row_count_mismatch_count`, `missing_tail_merge_count`, `missing_job_count`

## Inputs

- `input/report_source_standard.md` — the binding standard (cutover, row-count, tail-merge, required-jobs rules)
- `input/report_run_log.csv` — 15 logged runs with `source_row_count_snapshot` column

## Verifier

32 deterministic checks: 3 file-existence, 15 end-anchored per-row audit checks, 1 missing-job check, 8 memo checks, 5 results.json equals checks. Fractional reward.
