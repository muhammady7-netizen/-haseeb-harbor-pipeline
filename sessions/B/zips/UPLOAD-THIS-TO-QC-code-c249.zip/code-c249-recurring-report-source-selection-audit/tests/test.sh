#!/bin/bash
mkdir -p /logs/verifier
cd /app || exit 1
python3 -m pytest --ctrf /logs/verifier/ctrf.json /tests/test_outputs.py -rA
status=$?
if [ $status -eq 0 ]; then
    echo 1 > /logs/verifier/reward.txt
else
    python3 -c "
import json
try:
    with open('/logs/verifier/ctrf.json') as f:
        data = json.load(f)
    results = data.get('results', {}).get('tests', [])
    passed = sum(1 for t in results if t.get('status') == 'passed')
    total = len(results) if results else 1
    print(f'{passed/total:.4f}' if total > 0 else '0.0', end='')
except Exception:
    print('0.0', end='')
" > /logs/verifier/reward.txt
fi
exit 0
