# Report source-selection audit (computed from run log)

The input log has 36 physical rows. After collapsing duplicate `run_id` values with finding-precedence (non-`none` over `none`, then `live` over `archive`), there are 32 unique runs plus 1 `MISSING_JOB` roster row(s) (33 audit rows). 17 rows are `none`; 16 are flagged.

## Duplicate collapse for RUN-29

RUN-29 appears twice in the log for 2026-06-20. Finding-precedence keeps the live row because it used live instead of the archive source required on or before the cutover -- that is `SOURCE_MISMATCH`. The compliant archive duplicate is dropped.

## Duplicate collapse for RUN-35

RUN-35 appears twice on 2026-07-20. The archive duplicate used archive but should have used live after the cutover -- `SOURCE_MISMATCH` -- while the live duplicate is `none`. Ordered finding-precedence keeps the archive/`SOURCE_MISMATCH` row because a non-`none` finding beats `none` before live-over-archive applies.

## Duplicate collapse for RUN-37

RUN-37 appears twice on 2026-07-14. Archive carries `SOURCE_MISMATCH` and live reported 456 against snapshot 455 (`ROW_COUNT_MISMATCH`). Both findings are non-`none`, so the live row is kept -- `ROW_COUNT_MISMATCH`.

## Duplicate collapse for RUN-38

RUN-38 appears twice on 2026-06-22. Archive reported 301 against snapshot 300 (`ROW_COUNT_MISMATCH`) while live used live instead of archive required on or before the cutover (`SOURCE_MISMATCH`). Both findings are non-`none`, so ordered precedence keeps the live/`SOURCE_MISMATCH` row rather than ranking findings by severity.

## Flagged findings

- Required recurring job `week-ahead-briefing` has no run logged on the roster (weekly-journal-brief, week-ahead-briefing, monthly-report), but week-ahead-briefing is absent from the log -- `MISSING_JOB`.

- RUN-29 (weekly-journal-brief on 2026-06-20) used live but should have used archive under the weekly cutover rule (archive on/before 2026-07-06, live after) -- `SOURCE_MISMATCH`.

- RUN-38 (weekly-journal-brief on 2026-06-22) used live but should have used archive under the weekly cutover rule (archive on/before 2026-07-06, live after) -- `SOURCE_MISMATCH`.

- RUN-13 (weekly-journal-brief on 2026-07-05) used live but should have used archive under the weekly cutover rule (archive on/before 2026-07-06, live after) -- `SOURCE_MISMATCH`.

- RUN-24 (weekly-journal-brief on 2026-07-05) used live but should have used archive under the weekly cutover rule (archive on/before 2026-07-06, live after) -- `SOURCE_MISMATCH`.

- RUN-10 (weekly-journal-brief on 2026-07-06) used live but should have used archive under the weekly cutover rule (archive on/before 2026-07-06, live after) -- `SOURCE_MISMATCH`.

- RUN-17 (weekly-journal-brief on 2026-07-07) used archive but should have used live under the weekly cutover rule (archive on/before 2026-07-06, live after) -- `SOURCE_MISMATCH`.

- RUN-23 (weekly-journal-brief on 2026-07-07) used archive but should have used live under the weekly cutover rule (archive on/before 2026-07-06, live after) -- `SOURCE_MISMATCH`.

- RUN-33 (weekly-journal-brief on 2026-07-08) used archive but should have used live under the weekly cutover rule (archive on/before 2026-07-06, live after) -- `SOURCE_MISMATCH`.

- RUN-02 used live correctly for its date, but reported 388 against snapshot 395 -- `ROW_COUNT_MISMATCH`.

- RUN-37 used live correctly for its date, but reported 456 against snapshot 455 -- `ROW_COUNT_MISMATCH`.

- RUN-35 (weekly-journal-brief on 2026-07-20) used archive but should have used live under the weekly cutover rule (archive on/before 2026-07-06, live after) -- `SOURCE_MISMATCH`.

- RUN-03 is the first monthly-report after the 2026-07-06 cutover; source is empty and reported rows are 0 because the archive tail merge was skipped -- `MISSING_TAIL_MERGE`.

- RUN-25 used live correctly for its date, but reported 500 against snapshot 450 -- `ROW_COUNT_MISMATCH`.

- RUN-36 used live correctly for its date, but reported 441 against snapshot 440 -- `ROW_COUNT_MISMATCH`.

- RUN-19 used live correctly for its date, but reported 410 against snapshot 405 -- `ROW_COUNT_MISMATCH`.

## Compliant edge notes (not flagged)

Inclusive cutover: weekly jobs dated exactly 2026-07-06 that used archive are `none` (e.g. RUN-05, RUN-22). Monthly-report jobs are outside the weekly cutover rule; RUN-21 on the cutover date using live remains `none`. Empty-snapshot weekly runs after cutover (RUN-20, RUN-30) skip the row-count rule and stay `none`. Later monthly reports after the first post-cutover month need no tail merge.
