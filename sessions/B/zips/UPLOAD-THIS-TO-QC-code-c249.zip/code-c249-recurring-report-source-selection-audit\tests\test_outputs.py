"""Replays the harness `file_check` spec against the task workspace.

One pytest per graded assertion, so Harbor's per-test grid (and the CTRF report)
names exactly which deliverable check failed. The spec in `verifier.json` and the
engine in `rl_world_verifiers/` are copies of what the task harness runs, so a
result here means the same thing it means there.

Extra field-level checks below close the Harbor gap where middle audit columns
(job_name, run_date, source_used, reported_row_count) were ungraded.
"""

from __future__ import annotations

import csv
import os
import re
import sys
from datetime import date
from pathlib import Path

import pytest

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR))

from rl_world_verifiers.models import VerifierSpec, effective_weights  # noqa: E402
from rl_world_verifiers.sources.registry import SourceRegistry  # noqa: E402
from rl_world_verifiers.verifiers import verify_definition  # noqa: E402

WORKSPACE = Path(os.environ.get("HARBOR_TASK_WORKSPACE", "/app"))
SPEC = VerifierSpec.model_validate_json(
    (TESTS_DIR / "verifier.json").read_text(encoding="utf-8")
)
WEIGHTS = effective_weights(SPEC.verifiers)
REGISTRY = SourceRegistry(WORKSPACE)

CUTOVER = date(2026, 7, 6)
WEEKLY_JOBS = {"weekly-journal-brief", "week-ahead-briefing"}
REQUIRED_JOBS = ("weekly-journal-brief", "week-ahead-briefing", "monthly-report")
AUDIT_FIELDS = ("run_id", "job_name", "run_date", "source_used", "reported_row_count", "finding")


@pytest.mark.parametrize(
    "definition",
    SPEC.verifiers,
    ids=[definition.name for definition in SPEC.verifiers],
)
def test_deliverable(definition):
    outcome = verify_definition(
        definition,
        REGISTRY,
        WEIGHTS[definition.name],
        config=SPEC.config,
        completion_fn=None,
    )["result"]
    detail = outcome.get("error") or outcome.get("reason") or "assertion failed"
    assert outcome["success"], f"{definition.name}: {detail}"


def _input_log_path() -> Path:
    for candidate in (
        WORKSPACE / "input" / "report_run_log.csv",
        TESTS_DIR.parent / "environment" / "input" / "report_run_log.csv",
    ):
        if candidate.is_file():
            return candidate
    raise FileNotFoundError("report_run_log.csv not found under workspace or pack input/")


def _read_dict_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as f:
        return [{k: (v or "").strip() for k, v in row.items()} for row in csv.DictReader(f)]


def _compute_finding(row: dict[str, str], first_post_cutover_monthly: str | None) -> str:
    job = row.get("job_name", "")
    run_date_s = row.get("run_date", "")
    source = row.get("source_used", "")
    reported = row.get("reported_row_count", "")
    snapshot = row.get("source_row_count_snapshot", "")

    if job == "monthly-report" and row.get("run_id") == first_post_cutover_monthly:
        # Gold / standard signal: skipped archive tail merge → empty source + zero rows.
        if source == "" and reported in {"", "0"}:
            return "MISSING_TAIL_MERGE"

    if job in WEEKLY_JOBS and run_date_s:
        d = date.fromisoformat(run_date_s)
        expected = "archive" if d <= CUTOVER else "live"
        if source and source != expected:
            return "SOURCE_MISMATCH"

    if snapshot != "" and reported != snapshot:
        return "ROW_COUNT_MISMATCH"

    return "none"


def _finding_rank(finding: str) -> int:
    # Prefer non-none over none for de-dupe.
    return 0 if finding == "none" else 1


def _source_rank(source: str) -> int:
    # Prefer live over archive when otherwise competing.
    if source == "live":
        return 2
    if source == "archive":
        return 1
    return 0


def _expected_audit_rows() -> list[dict[str, str]]:
    """Build gold-shaped audit rows from the run log + standard (quote-tolerant)."""
    log_rows = _read_dict_rows(_input_log_path())

    monthly_after = []
    for row in log_rows:
        if row.get("job_name") != "monthly-report":
            continue
        rd = row.get("run_date") or ""
        if not rd:
            continue
        if date.fromisoformat(rd) > CUTOVER:
            monthly_after.append(row)
    monthly_after.sort(key=lambda r: r["run_date"])
    first_post = monthly_after[0]["run_id"] if monthly_after else None

    scored: list[dict[str, str]] = []
    for row in log_rows:
        finding = _compute_finding(row, first_post)
        scored.append(
            {
                "run_id": row["run_id"],
                "job_name": row["job_name"],
                "run_date": row["run_date"],
                "source_used": row["source_used"],
                "reported_row_count": row["reported_row_count"],
                "finding": finding,
                "_src_rank": str(_source_rank(row["source_used"])),
                "_find_rank": str(_finding_rank(finding)),
            }
        )

    by_id: dict[str, dict[str, str]] = {}
    for row in scored:
        rid = row["run_id"]
        prev = by_id.get(rid)
        if prev is None:
            by_id[rid] = row
            continue
        key = (int(row["_find_rank"]), int(row["_src_rank"]))
        prev_key = (int(prev["_find_rank"]), int(prev["_src_rank"]))
        if key > prev_key:
            by_id[rid] = row

    jobs_present = {r["job_name"] for r in by_id.values()}
    out = []
    for rid, row in by_id.items():
        out.append(
            {
                "run_id": row["run_id"],
                "job_name": row["job_name"],
                "run_date": row["run_date"],
                "source_used": row["source_used"],
                "reported_row_count": row["reported_row_count"],
                "finding": row["finding"],
            }
        )
    for job in REQUIRED_JOBS:
        if job not in jobs_present:
            out.append(
                {
                    "run_id": "",
                    "job_name": job,
                    "run_date": "",
                    "source_used": "",
                    "reported_row_count": "0",
                    "finding": "MISSING_JOB",
                }
            )
    return out


def _load_audit_rows() -> list[dict[str, str]]:
    path = WORKSPACE / "report_source_audit.csv"
    assert path.is_file(), "report_source_audit.csv missing"
    rows = _read_dict_rows(path)
    assert rows, "report_source_audit.csv has no data rows"
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        assert reader.fieldnames is not None
        assert list(reader.fieldnames) == list(AUDIT_FIELDS), (
            f"audit header {reader.fieldnames!r} != {list(AUDIT_FIELDS)!r}"
        )
    return rows


def test_audit_identifying_columns_match_log():
    """Every non-MISSING_JOB audit row must carry log identifying columns after de-dupe."""
    expected = {
        r["run_id"]: r
        for r in _expected_audit_rows()
        if r["finding"] != "MISSING_JOB"
    }
    audit = _load_audit_rows()
    run_rows = [r for r in audit if (r.get("finding") or "") != "MISSING_JOB"]
    assert len(run_rows) == len(expected), (
        f"expected {len(expected)} run rows after de-dupe, got {len(run_rows)}"
    )
    for row in run_rows:
        rid = row.get("run_id") or ""
        assert rid in expected, f"unexpected run_id {rid!r}"
        gold = expected[rid]
        for col in ("job_name", "run_date", "source_used", "reported_row_count"):
            assert (row.get(col) or "") == gold[col], (
                f"{rid} {col}: audit={row.get(col)!r} expected_from_log={gold[col]!r}"
            )



# Memo fairness: evidence + connective co-located with run id; real prose, not token soup.
_MEMO_CONNECTIVE_WINDOW = 450
_MEMO_EVIDENCE_WINDOW = 600
_MEMO_CONNECTIVES = re.compile(
    r"(?i)\b(?:because|used|uses|using|should|instead|expected|required|"
    r"premature|reported|against|vs\.?|versus|although|while|whereas|over|"
    r"rather|pulled|kept|chose|selected|skipped|missing|empty)\b"
)
_MEMO_PROSE_GLUE = re.compile(
    r"(?i)\b(?:the|a|an|of|for|from|with|that|this|was|were|is|are|on|to|by|"
    r"as|into|than|then|but|and|or|its|their|which|when|where|who|whom)\b"
)
_MEMO_PUNCT = re.compile(r"[,.:;!?()\[\]\—\–\-`]")

_DUMP_VOCAB = {
    "run", "source", "mismatch", "row", "count", "missing", "tail", "merge",
    "job", "live", "archive", "archived", "archives", "none", "finding",
    "because", "used", "uses", "using", "should", "instead", "expected",
    "required", "premature", "reported", "against", "vs", "versus",
    "although", "while", "whereas", "over", "rather", "pulled", "kept",
    "chose", "selected", "snapshot", "cutover", "weekly", "monthly",
    "journal", "brief", "ahead", "briefing", "report", "and", "or", "the",
}


def _load_memo_text() -> str:
    path = WORKSPACE / "report_source_memo.md"
    assert path.is_file(), "report_source_memo.md missing"
    return path.read_text(encoding="utf-8")


def _run_id_spans(memo: str, run_id: str) -> list[tuple[int, int]]:
    n = int(run_id.split("-", 1)[1])
    pat = re.compile(rf"(?i)RUN[-*_]*\s*0?{n}\b")
    return [(m.start(), m.end()) for m in pat.finditer(memo)]


def _window_around(memo: str, start: int, end: int, radius: int) -> str:
    lo = max(0, start - radius)
    hi = min(len(memo), end + radius)
    return memo[lo:hi]


def _has_prose_structure(window: str) -> bool:
    """Reject space-separated token soup; require punctuation + grammatical glue."""
    words = re.findall(r"[A-Za-z0-9']+", window)
    if len(words) < 8:
        return False
    if not _MEMO_PUNCT.search(window):
        return False
    glue = sum(1 for w in words if _MEMO_PROSE_GLUE.fullmatch(w))
    if glue < 2:
        return False
    contentish = [
        w
        for w in words
        if w.lower() not in _DUMP_VOCAB
        and not w.isdigit()
        and not re.fullmatch(r"(?i)run-?\d+", w)
    ]
    if len(contentish) < 3:
        return False
    return True


def _evidence_and_connective_near_run(
    memo: str,
    run_id: str,
    evidence_patterns: list[str],
) -> bool:
    """True if some run-id hit has evidence + connective + prose in the local window."""
    spans = _run_id_spans(memo, run_id)
    if not spans:
        return False
    for start, end in spans:
        forward = memo[start : min(len(memo), start + _MEMO_CONNECTIVE_WINDOW + 80)]
        broad = memo[start : min(len(memo), start + _MEMO_EVIDENCE_WINDOW + 80)]
        if not all(re.search(p, broad, re.I | re.S) for p in evidence_patterns):
            continue
        if not _MEMO_CONNECTIVES.search(forward):
            continue
        local = _window_around(memo, start, end, _MEMO_CONNECTIVE_WINDOW)
        if not _has_prose_structure(local):
            continue
        return True
    return False



def test_missing_job_row_empty_identifying_fields():
    """MISSING_JOB row: empty run_id/run_date/source_used, reported_row_count=0."""
    audit = _load_audit_rows()
    missing = [r for r in audit if (r.get("finding") or "") == "MISSING_JOB"]
    assert len(missing) == 1, f"expected exactly one MISSING_JOB row, got {len(missing)}"
    row = missing[0]
    assert (row.get("run_id") or "") == ""
    assert (row.get("run_date") or "") == ""
    assert (row.get("source_used") or "") == ""
    assert (row.get("reported_row_count") or "") == "0"
    assert (row.get("job_name") or "") == "week-ahead-briefing"
    assert (row.get("finding") or "") == "MISSING_JOB"


# Flagged-finding memo windows (shared with verifier proximity intent).
_FLAGGED_MEMO_CASES = [
    ("RUN-10", [r"\blive\b", r"\b(?:archive|archived|archives)\b"]),
    ("RUN-13", [r"\blive\b", r"\b(?:archive|archived|archives)\b"]),
    ("RUN-17", [r"\b(?:archive|archived|archives)\b", r"\blive\b"]),
    ("RUN-23", [r"\b(?:archive|archived|archives)\b", r"\blive\b"]),
    ("RUN-24", [r"\blive\b", r"\b(?:archive|archived|archives)\b"]),
    ("RUN-29", [r"\blive\b", r"\b(?:archive|archived|archives)\b"]),
    ("RUN-33", [r"\b(?:archive|archived|archives)\b", r"\blive\b"]),
    ("RUN-35", [r"\b(?:archive|archived|archives)\b", r"\blive\b"]),
    ("RUN-38", [r"\blive\b", r"\b(?:archive|archived|archives)\b"]),
    ("RUN-02", [r"\b388\b", r"\b395\b"]),
    ("RUN-19", [r"\b410\b", r"\b405\b"]),
    ("RUN-25", [r"\b500\b", r"\b450\b"]),
    ("RUN-36", [r"\b441\b", r"\b440\b"]),
    ("RUN-37", [r"\b456\b", r"\b455\b"]),
    ("RUN-03", [r"(?i)tail", r"(?i)(?:merge|MISSING_TAIL_MERGE)"]),
]


def test_memo_flagged_findings_local_prose():
    """Each flagged run must have evidence+connective in a prose window near the run id.

    Strengthens verifier.json proximity regexes: rejects content-free whitelist token
    dumps even when connective tokens are present. Gold natural prose must still pass.
    """
    memo = _load_memo_text()
    failures = []
    for run_id, patterns in _FLAGGED_MEMO_CASES:
        if not _evidence_and_connective_near_run(memo, run_id, patterns):
            failures.append(run_id)
    # Missing job: job name + paraphrase + connective + prose
    miss_ok = False
    for m in re.finditer(r"(?i)week[\s-]ahead[\s-]briefing", memo):
        start, end = m.start(), m.end()
        broad = memo[start : min(len(memo), start + _MEMO_EVIDENCE_WINDOW + 80)]
        forward = memo[start : min(len(memo), start + _MEMO_CONNECTIVE_WINDOW + 80)]
        if not re.search(
            r"(?i)(?:missing|MISSING_JOB|no\s+run|not\s+logged|absent|roster|required\s+recurring)",
            broad,
        ):
            continue
        if not re.search(
            r"(?i)\b(?:because|but|logged|roster|required|absent|although|while|"
            r"whereas|rather|kept|chose|selected)\b",
            forward,
        ):
            continue
        local = _window_around(memo, start, end, _MEMO_CONNECTIVE_WINDOW)
        if _has_prose_structure(local):
            miss_ok = True
            break
    if not miss_ok:
        failures.append("week-ahead-briefing")
    assert not failures, (
        "memo lacks local evidence+connective prose for: " + ", ".join(failures)
    )

