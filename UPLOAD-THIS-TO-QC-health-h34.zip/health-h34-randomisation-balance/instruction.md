# Task

Audit the attached randomisation list and amendment ledger for study AR-118 against the trial's randomisation charter before the monitoring report goes out. Save `stratum_balance.csv` with the columns `factor,level,subjects,active,control,active_pct,out_of_sequence,status`, with a row for the study overall (`factor=overall`, `level=all`) and a row for each level of each stratification factor. Use factor labels `site` (levels `S1`, `S2`, `S3`) and `severity` (levels `mild`, `severe`) — not longer synonyms. `status` is `within_tolerance` or `outside_tolerance`, and `out_of_sequence` carries the sequence findings for the levels the charter tests them at. Save `block_balance.csv` with the columns `stratum,block_id,subjects,active,control,block_status`, one row per block, where `block_status` is `within_tolerance`, `outside_tolerance` or `not_assessed`. Then write `randomisation_findings.md` on the overall drift, which stratification levels are outside tolerance, which blocks deviate and which do not, any subject allocated out of sequence, and that the amendment ledger was reconciled/applied before the tests.

---



## Deliverables

Save these files in your working directory:
- `block_balance.csv`
- `stratum_balance.csv`
- `randomisation_findings.md`
- `results.json` — a JSON object with keys: `strata_outside_tolerance`, `blocks_assessed`, `blocks_outside_tolerance`, `out_of_sequence_allocations`
